/*   �2022 Zebra Technologies LLC. All rights reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *   bug_me: ems.support@zebra.com  
 */

#include "util.h"

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <map>
#include <iostream>
#include <CsUserDefs.h>
#include "scanner.h"
#include "pugixml.hpp"
#include "debug.h"


static char buffer[1024];

std::string int2str(int iValue)
{
    sprintf(buffer, "%d", iValue);
    return buffer;
}

std::map<std::pair<int,int>,std::string> g_barCodeMap ;


void barcodeMapInit()
{
    debug_print("start function");
    g_barCodeMap[std::make_pair(0,(int)SCANNER_TYPE_SNAPI)] = "Unknown" ;   
    g_barCodeMap[std::make_pair(0,(int)SCANNER_TYPE_IBMHID)] = "Unknown" ;
    g_barCodeMap[std::make_pair(0,(int)SCANNER_TYPE_IBMTT)] = "Unknown" ;
    
    g_barCodeMap[std::make_pair(1,(int)SCANNER_TYPE_SNAPI)] = "Code 39" ;   
    g_barCodeMap[std::make_pair(1,(int)SCANNER_TYPE_IBMHID)] = "Code 39" ;
    g_barCodeMap[std::make_pair(1,(int)SCANNER_TYPE_IBMTT)] = "Code 39" ;

    g_barCodeMap[std::make_pair(2,(int)SCANNER_TYPE_SNAPI)] = "Codabar";
    g_barCodeMap[std::make_pair(2,(int)SCANNER_TYPE_IBMHID)] = "Codabar";
    g_barCodeMap[std::make_pair(2,(int)SCANNER_TYPE_IBMTT)] = "Codabar";

    g_barCodeMap[std::make_pair(3,(int)SCANNER_TYPE_SNAPI)] = "Code 128" ;
    g_barCodeMap[std::make_pair(3,(int)SCANNER_TYPE_IBMHID)] = "Code 128" ;
    g_barCodeMap[std::make_pair(3,(int)SCANNER_TYPE_IBMTT)] = "Code 128";

    g_barCodeMap[std::make_pair(4,(int)SCANNER_TYPE_SNAPI)] = "Discrete (Standard) 2 of 5";
    g_barCodeMap[std::make_pair(4,(int)SCANNER_TYPE_IBMHID)] ="Discrete (Standard) 2 of 5";
    g_barCodeMap[std::make_pair(4,(int)SCANNER_TYPE_IBMTT)]=  "Discrete (Standard) 2 of 5";

    g_barCodeMap[std::make_pair(5,(int)SCANNER_TYPE_SNAPI)] = "ITIA";
    g_barCodeMap[std::make_pair(5,(int)SCANNER_TYPE_IBMHID)] = "ITIA";
    g_barCodeMap[std::make_pair(5,(int)SCANNER_TYPE_IBMTT)] = "ITIA";

    g_barCodeMap[std::make_pair(6,(int)SCANNER_TYPE_SNAPI)] =  "Interleaved 2 of 5";
    g_barCodeMap[std::make_pair(6,(int)SCANNER_TYPE_IBMHID)] = "Interleaved 2 of 5";
    g_barCodeMap[std::make_pair(6,(int)SCANNER_TYPE_IBMTT)] =  "Interleaved 2 of 5";

    g_barCodeMap[std::make_pair(7,(int)SCANNER_TYPE_SNAPI)] = "Code 93";
    g_barCodeMap[std::make_pair(7,(int)SCANNER_TYPE_IBMHID)] ="Code 93";
    g_barCodeMap[std::make_pair(7,(int)SCANNER_TYPE_IBMTT)]=  "Code 93";

    g_barCodeMap[std::make_pair(8,(int)SCANNER_TYPE_SNAPI)] = "UPC-A";
    g_barCodeMap[std::make_pair(8,(int)SCANNER_TYPE_IBMHID)] ="UPC-A";
    g_barCodeMap[std::make_pair(8,(int)SCANNER_TYPE_IBMTT)] = "UPC-A" ;

    g_barCodeMap[std::make_pair(9,(int)SCANNER_TYPE_SNAPI)] = "UPC-E0";
    g_barCodeMap[std::make_pair(9,(int)SCANNER_TYPE_IBMHID)] ="UPC-E0";
    g_barCodeMap[std::make_pair(9,(int)SCANNER_TYPE_IBMTT)] = "UPC-E0";

    g_barCodeMap[std::make_pair(10,(int)SCANNER_TYPE_SNAPI)] = "EAN-8";
    g_barCodeMap[std::make_pair(10,(int)SCANNER_TYPE_IBMHID)] ="EAN-8";
    g_barCodeMap[std::make_pair(10,(int)SCANNER_TYPE_IBMTT)] = "EAN-8";

    g_barCodeMap[std::make_pair(11,(int)SCANNER_TYPE_SNAPI)] = "EAN-13";
    g_barCodeMap[std::make_pair(11,(int)SCANNER_TYPE_IBMHID)] ="EAN-13";
    g_barCodeMap[std::make_pair(11,(int)SCANNER_TYPE_IBMTT)] = "EAN-13";

    g_barCodeMap[std::make_pair(12,(int)SCANNER_TYPE_SNAPI)] = "Code 11";
    g_barCodeMap[std::make_pair(12,(int)SCANNER_TYPE_IBMHID)] = "Code 11";
    g_barCodeMap[std::make_pair(12,(int)SCANNER_TYPE_IBMTT)] = "Code 11";

    g_barCodeMap[std::make_pair(13,(int)SCANNER_TYPE_SNAPI)] = "Code 49";
    g_barCodeMap[std::make_pair(13,(int)SCANNER_TYPE_IBMHID)] ="Code 49";
    g_barCodeMap[std::make_pair(13,(int)SCANNER_TYPE_IBMTT)] = "Code 49";

    g_barCodeMap[std::make_pair(14,(int)SCANNER_TYPE_SNAPI)] = "MSI";
    g_barCodeMap[std::make_pair(14,(int)SCANNER_TYPE_IBMHID)] = "MSI";
    g_barCodeMap[std::make_pair(14,(int)SCANNER_TYPE_IBMTT)] = "MSI";

    g_barCodeMap[std::make_pair(15,(int)SCANNER_TYPE_SNAPI)] = "EAN-128";
    g_barCodeMap[std::make_pair(15,(int)SCANNER_TYPE_IBMHID)] ="EAN-128";
    g_barCodeMap[std::make_pair(15,(int)SCANNER_TYPE_IBMTT)] = "EAN-128";

    g_barCodeMap[std::make_pair(16,(int)SCANNER_TYPE_SNAPI)] = "UPC-E1";
    g_barCodeMap[std::make_pair(16,(int)SCANNER_TYPE_IBMHID)] = "UPC-E1";
    g_barCodeMap[std::make_pair(16,(int)SCANNER_TYPE_IBMTT)] = "UPC-E1";

    g_barCodeMap[std::make_pair(17,(int)SCANNER_TYPE_SNAPI)] = "PDF-417";
    g_barCodeMap[std::make_pair(17,(int)SCANNER_TYPE_IBMHID)] ="PDF-417";
    g_barCodeMap[std::make_pair(17,(int)SCANNER_TYPE_IBMTT)] = "PDF-417";

    g_barCodeMap[std::make_pair(18,(int)SCANNER_TYPE_SNAPI)] = "Code 16K";
    g_barCodeMap[std::make_pair(18,(int)SCANNER_TYPE_IBMHID)] = "Code 16K";
    g_barCodeMap[std::make_pair(18,(int)SCANNER_TYPE_IBMTT)] = "Code 16K";

    g_barCodeMap[std::make_pair(19,(int)SCANNER_TYPE_SNAPI)] = "Code 39 Full ASCII";
    g_barCodeMap[std::make_pair(19,(int)SCANNER_TYPE_IBMHID)] = "Code 39 Full ASCII";
    g_barCodeMap[std::make_pair(19,(int)SCANNER_TYPE_IBMTT)] = "Code 39 Full ASCII";

    g_barCodeMap[std::make_pair(20,(int)SCANNER_TYPE_SNAPI)] = "UPC-D";
    g_barCodeMap[std::make_pair(20,(int)SCANNER_TYPE_IBMHID)] = "UPC-D";
    g_barCodeMap[std::make_pair(20,(int)SCANNER_TYPE_IBMTT)] = "UPC-D";

    g_barCodeMap[std::make_pair(21,(int)SCANNER_TYPE_SNAPI)] = "Code 39 Trioptic";
    g_barCodeMap[std::make_pair(21,(int)SCANNER_TYPE_IBMHID)] = "Code 39 Trioptic";
    g_barCodeMap[std::make_pair(21,(int)SCANNER_TYPE_IBMTT)] = "Code 39 Trioptic";

    g_barCodeMap[std::make_pair(22,(int)SCANNER_TYPE_SNAPI)] = "Bookland";
    g_barCodeMap[std::make_pair(22,(int)SCANNER_TYPE_IBMHID)] = "Bookland";
    g_barCodeMap[std::make_pair(22,(int)SCANNER_TYPE_IBMTT)] = "Bookland";

    g_barCodeMap[std::make_pair(23,(int)SCANNER_TYPE_SNAPI)] = "Coupon Code";
    g_barCodeMap[std::make_pair(23,(int)SCANNER_TYPE_IBMHID)] = "Coupon Code";
    g_barCodeMap[std::make_pair(23,(int)SCANNER_TYPE_IBMTT)] = "Coupon Code";

    g_barCodeMap[std::make_pair(24,(int)SCANNER_TYPE_SNAPI)] = "NW-7";
    g_barCodeMap[std::make_pair(24,(int)SCANNER_TYPE_IBMHID)] = "NW-7";
    g_barCodeMap[std::make_pair(24,(int)SCANNER_TYPE_IBMTT)] = "NW-7";

    g_barCodeMap[std::make_pair(25,(int)SCANNER_TYPE_SNAPI)] = "ISBT-128";
    g_barCodeMap[std::make_pair(25,(int)SCANNER_TYPE_IBMHID)] = "ISBT-128";
    g_barCodeMap[std::make_pair(25,(int)SCANNER_TYPE_IBMTT)] = "ISBT-128";

    g_barCodeMap[std::make_pair(26,(int)SCANNER_TYPE_SNAPI)] = "Micro PDF";
    g_barCodeMap[std::make_pair(26,(int)SCANNER_TYPE_IBMHID)] = "Micro PDF";
    g_barCodeMap[std::make_pair(26,(int)SCANNER_TYPE_IBMTT)] = "Micro PDF";

    g_barCodeMap[std::make_pair(27,(int)SCANNER_TYPE_SNAPI)] = "DataMatrix";
    g_barCodeMap[std::make_pair(27,(int)SCANNER_TYPE_IBMHID)]= "DataMatrix";
    g_barCodeMap[std::make_pair(27,(int)SCANNER_TYPE_IBMTT)] = "DataMatrix";

    g_barCodeMap[std::make_pair(28,(int)SCANNER_TYPE_SNAPI)] = "QR Code";
    g_barCodeMap[std::make_pair(28,(int)SCANNER_TYPE_IBMHID)] = "QR Code";
    g_barCodeMap[std::make_pair(28,(int)SCANNER_TYPE_IBMTT)] =  "QR Code";

    g_barCodeMap[std::make_pair(29,(int)SCANNER_TYPE_SNAPI)] = "Micro PDF CCA";
    g_barCodeMap[std::make_pair(29,(int)SCANNER_TYPE_IBMHID)] = "Micro PDF CCA";
    g_barCodeMap[std::make_pair(29,(int)SCANNER_TYPE_IBMTT)] = "Micro PDF CCA";

    g_barCodeMap[std::make_pair(30,(int)SCANNER_TYPE_SNAPI)] = "PostNet US";
    g_barCodeMap[std::make_pair(30,(int)SCANNER_TYPE_IBMHID)] = "PostNet US";
    g_barCodeMap[std::make_pair(30,(int)SCANNER_TYPE_IBMTT)] = "PostNet US";

    g_barCodeMap[std::make_pair(31,(int)SCANNER_TYPE_SNAPI)] = "Planet Code";
    g_barCodeMap[std::make_pair(31,(int)SCANNER_TYPE_IBMHID)] = "Planet Code";
    g_barCodeMap[std::make_pair(31,(int)SCANNER_TYPE_IBMTT)] = "Planet Code";

    g_barCodeMap[std::make_pair(32,(int)SCANNER_TYPE_SNAPI)] = "Code 32";
    g_barCodeMap[std::make_pair(32,(int)SCANNER_TYPE_IBMHID)] = "Code 32";
    g_barCodeMap[std::make_pair(32,(int)SCANNER_TYPE_IBMTT)] = "Code 32";

    g_barCodeMap[std::make_pair(33,(int)SCANNER_TYPE_SNAPI)] = "ISBT-128 Con";
    g_barCodeMap[std::make_pair(33,(int)SCANNER_TYPE_IBMHID)] = "ISBT-128 Con";
    g_barCodeMap[std::make_pair(33,(int)SCANNER_TYPE_IBMTT)] = "ISBT-128 Con";

    g_barCodeMap[std::make_pair(34,(int)SCANNER_TYPE_SNAPI)] = "Japan Postal";
    g_barCodeMap[std::make_pair(34,(int)SCANNER_TYPE_IBMHID)] = "Japan Postal";
    g_barCodeMap[std::make_pair(34,(int)SCANNER_TYPE_IBMTT)] = "Japan Postal";

    g_barCodeMap[std::make_pair(35,(int)SCANNER_TYPE_SNAPI)] = "Australian Postal";
    g_barCodeMap[std::make_pair(35,(int)SCANNER_TYPE_IBMHID)] = "Australian Postal";
    g_barCodeMap[std::make_pair(35,(int)SCANNER_TYPE_IBMTT)] = "Australian Postal";

    g_barCodeMap[std::make_pair(36,(int)SCANNER_TYPE_SNAPI)] = "Duch Postal";
    g_barCodeMap[std::make_pair(36,(int)SCANNER_TYPE_IBMHID)] = "Duch Postal";
    g_barCodeMap[std::make_pair(36,(int)SCANNER_TYPE_IBMTT)] = "Duch Postal";

    g_barCodeMap[std::make_pair(37,(int)SCANNER_TYPE_SNAPI)] = "MaxiCode";
    g_barCodeMap[std::make_pair(37,(int)SCANNER_TYPE_IBMHID)] = "MaxiCode";
    g_barCodeMap[std::make_pair(37,(int)SCANNER_TYPE_IBMTT)] = "MaxiCode";

    g_barCodeMap[std::make_pair(38,(int)SCANNER_TYPE_SNAPI)] = "Canadian Postal";
    g_barCodeMap[std::make_pair(38,(int)SCANNER_TYPE_IBMHID)] = "Canadian Postal";
    g_barCodeMap[std::make_pair(38,(int)SCANNER_TYPE_IBMTT)] = "Canadian Postal";

    g_barCodeMap[std::make_pair(39,(int)SCANNER_TYPE_SNAPI)] = "UK Postal";
    g_barCodeMap[std::make_pair(39,(int)SCANNER_TYPE_IBMHID)] = "UK Postal";
    g_barCodeMap[std::make_pair(39,(int)SCANNER_TYPE_IBMTT)] = "UK Postal";

    g_barCodeMap[std::make_pair(40,(int)SCANNER_TYPE_SNAPI)] = "Macro PDF";
    g_barCodeMap[std::make_pair(40,(int)SCANNER_TYPE_IBMHID)] = "Macro PDF";
    g_barCodeMap[std::make_pair(40,(int)SCANNER_TYPE_IBMTT)] = "Macro PDF";

    g_barCodeMap[std::make_pair(44,(int)SCANNER_TYPE_SNAPI)] = "Micro QR code";
    g_barCodeMap[std::make_pair(44,(int)SCANNER_TYPE_IBMHID)] ="Micro QR code";
    g_barCodeMap[std::make_pair(44,(int)SCANNER_TYPE_IBMTT)] = "Micro QR code";

    g_barCodeMap[std::make_pair(45,(int)SCANNER_TYPE_SNAPI)] = "Aztec";
    g_barCodeMap[std::make_pair(45,(int)SCANNER_TYPE_IBMHID)] ="Aztec";
    g_barCodeMap[std::make_pair(45,(int)SCANNER_TYPE_IBMTT)] = "Aztec";

    g_barCodeMap[std::make_pair(48,(int)SCANNER_TYPE_SNAPI)] = "GS1 Databar (RSS-14)";
    g_barCodeMap[std::make_pair(48,(int)SCANNER_TYPE_IBMHID)] ="GS1 Databar (RSS-14)";
    g_barCodeMap[std::make_pair(48,(int)SCANNER_TYPE_IBMTT)] = "GS1 Databar (RSS-14)";

    g_barCodeMap[std::make_pair(49,(int)SCANNER_TYPE_SNAPI)] = "RSS Limited";
    g_barCodeMap[std::make_pair(49,(int)SCANNER_TYPE_IBMHID)] = "RSS Limited";
    g_barCodeMap[std::make_pair(49,(int)SCANNER_TYPE_IBMTT)] = "RSS Limited";

    g_barCodeMap[std::make_pair(50,(int)SCANNER_TYPE_SNAPI)] ="GS1 Databar Expanded (RSS Expanded)";
    g_barCodeMap[std::make_pair(50,(int)SCANNER_TYPE_IBMHID)]="GS1 Databar Expanded (RSS Expanded)";
    g_barCodeMap[std::make_pair(50,(int)SCANNER_TYPE_IBMTT)] ="GS1 Databar Expanded (RSS Expanded)";

    g_barCodeMap[std::make_pair(55,(int)SCANNER_TYPE_SNAPI)] = "Scanlet";
    g_barCodeMap[std::make_pair(55,(int)SCANNER_TYPE_IBMHID)] = "Scanlet";
    g_barCodeMap[std::make_pair(55,(int)SCANNER_TYPE_IBMTT)] = "Scanlet";

    g_barCodeMap[std::make_pair(72,(int)SCANNER_TYPE_SNAPI)] = "UPC-A+2 Supplemental";
    g_barCodeMap[std::make_pair(72,(int)SCANNER_TYPE_IBMHID)] ="UPC-A+2 Supplemental";
    g_barCodeMap[std::make_pair(72,(int)SCANNER_TYPE_IBMTT)] = "UPC-A+2 Supplemental";

    g_barCodeMap[std::make_pair(73,(int)SCANNER_TYPE_SNAPI)] = "UPC-E0 +2 Supplemental";
    g_barCodeMap[std::make_pair(73,(int)SCANNER_TYPE_IBMHID)] ="UPC-E0 +2 Supplemental";
    g_barCodeMap[std::make_pair(73,(int)SCANNER_TYPE_IBMTT)] = "UPC-E0 +2 Supplemental";

    g_barCodeMap[std::make_pair(74,(int)SCANNER_TYPE_SNAPI)] = "EAN-8 +2 Supplemental";
    g_barCodeMap[std::make_pair(74,(int)SCANNER_TYPE_IBMHID)] ="EAN-8 +2 Supplemental";
    g_barCodeMap[std::make_pair(74,(int)SCANNER_TYPE_IBMTT)] = "EAN-8 +2 Supplemental";

    g_barCodeMap[std::make_pair(75,(int)SCANNER_TYPE_SNAPI)] = "EAN-13 +2 Supplemetal";
    g_barCodeMap[std::make_pair(75,(int)SCANNER_TYPE_IBMHID)]= "EAN-13 +2 Supplemental";
    g_barCodeMap[std::make_pair(75,(int)SCANNER_TYPE_IBMTT)] = "EAN-13 +2 Supplemental" ;

    g_barCodeMap[std::make_pair(80,(int)SCANNER_TYPE_SNAPI)] = "UPCE1 +s Supplemental";
    g_barCodeMap[std::make_pair(80,(int)SCANNER_TYPE_IBMHID)] = "UPCE1 +s Supplemental";
    g_barCodeMap[std::make_pair(80,(int)SCANNER_TYPE_IBMTT)] = "UPCE1 +s Supplemental";

    g_barCodeMap[std::make_pair(81,(int)SCANNER_TYPE_SNAPI)] = "CCA EAN-128";
    g_barCodeMap[std::make_pair(81,(int)SCANNER_TYPE_IBMHID)] = "CCA EAN-128";
    g_barCodeMap[std::make_pair(81,(int)SCANNER_TYPE_IBMTT)] = "CCA EAN-128";

    g_barCodeMap[std::make_pair(82,(int)SCANNER_TYPE_SNAPI)] = "CCA EAN-13";
    g_barCodeMap[std::make_pair(82,(int)SCANNER_TYPE_IBMHID)] = "CCA EAN-13";
    g_barCodeMap[std::make_pair(82,(int)SCANNER_TYPE_IBMTT)] = "CCA EAN-13";

    g_barCodeMap[std::make_pair(83,(int)SCANNER_TYPE_SNAPI)] = "CCA EAN-8";
    g_barCodeMap[std::make_pair(83,(int)SCANNER_TYPE_IBMHID)] = "CCA EAN-8";
    g_barCodeMap[std::make_pair(83,(int)SCANNER_TYPE_IBMTT)] = "CCA EAN-8";

    g_barCodeMap[std::make_pair(84,(int)SCANNER_TYPE_SNAPI)] = "CAA RSS Expanded";
    g_barCodeMap[std::make_pair(84,(int)SCANNER_TYPE_IBMHID)] = "CAA RSS Expanded";
    g_barCodeMap[std::make_pair(84,(int)SCANNER_TYPE_IBMTT)] = "CAA RSS Expanded";

    g_barCodeMap[std::make_pair(85,(int)SCANNER_TYPE_SNAPI)] = "CCA RSS Limited";
    g_barCodeMap[std::make_pair(85,(int)SCANNER_TYPE_IBMHID)] = "CCA RSS Limited";
    g_barCodeMap[std::make_pair(85,(int)SCANNER_TYPE_IBMTT)] = "CCA RSS Limited";

    g_barCodeMap[std::make_pair(86,(int)SCANNER_TYPE_SNAPI)] = "CAA RSS-14";
    g_barCodeMap[std::make_pair(86,(int)SCANNER_TYPE_IBMHID)] = "CAA RSS-14";
    g_barCodeMap[std::make_pair(86,(int)SCANNER_TYPE_IBMTT)] = "CAA RSS-14";

    g_barCodeMap[std::make_pair(87,(int)SCANNER_TYPE_SNAPI)] = "CCA UPC-A";
    g_barCodeMap[std::make_pair(87,(int)SCANNER_TYPE_IBMHID)] = "CCA UPC-A";
    g_barCodeMap[std::make_pair(87,(int)SCANNER_TYPE_IBMTT)] = "CCA UPC-A";

    g_barCodeMap[std::make_pair(88,(int)SCANNER_TYPE_SNAPI)] = "CCA UPC-E";
    g_barCodeMap[std::make_pair(88,(int)SCANNER_TYPE_IBMHID)] = "CCA UPC-E";
    g_barCodeMap[std::make_pair(88,(int)SCANNER_TYPE_IBMTT)] = "CCA UPC-E";

    g_barCodeMap[std::make_pair(89,(int)SCANNER_TYPE_SNAPI)]=  "CCC EAN-128";
    g_barCodeMap[std::make_pair(89,(int)SCANNER_TYPE_IBMHID)]=  "CCC EAN-128";
    g_barCodeMap[std::make_pair(89,(int)SCANNER_TYPE_IBMTT)]=  "CCC EAN-128";

    g_barCodeMap[std::make_pair(90,(int)SCANNER_TYPE_SNAPI)] = "TLC-39";
    g_barCodeMap[std::make_pair(90,(int)SCANNER_TYPE_IBMHID)] = "TLC-39";
    g_barCodeMap[std::make_pair(90,(int)SCANNER_TYPE_IBMTT)] = "TLC-39";

    g_barCodeMap[std::make_pair(97,(int)SCANNER_TYPE_SNAPI)] = "CCB EAN-128";
    g_barCodeMap[std::make_pair(97,(int)SCANNER_TYPE_IBMHID)] = "CCB EAN-128";
    g_barCodeMap[std::make_pair(97,(int)SCANNER_TYPE_IBMTT)] = "CCB EAN-128";

    g_barCodeMap[std::make_pair(98,(int)SCANNER_TYPE_SNAPI)] = "CCB EAN-13";
    g_barCodeMap[std::make_pair(98,(int)SCANNER_TYPE_IBMHID)] = "CCB EAN-13";
    g_barCodeMap[std::make_pair(98,(int)SCANNER_TYPE_IBMTT)] = "CCB EAN-13";

    g_barCodeMap[std::make_pair(99,(int)SCANNER_TYPE_SNAPI)] = "CCB EAN-8";
    g_barCodeMap[std::make_pair(99,(int)SCANNER_TYPE_IBMHID)] = "CCB EAN-8";
    g_barCodeMap[std::make_pair(99,(int)SCANNER_TYPE_IBMTT)] = "CCB EAN-8";

    g_barCodeMap[std::make_pair(100,(int)SCANNER_TYPE_SNAPI)] = "CCB RSS Expanded";
    g_barCodeMap[std::make_pair(100,(int)SCANNER_TYPE_IBMHID)] = "CCB RSS Expanded";
    g_barCodeMap[std::make_pair(100,(int)SCANNER_TYPE_IBMTT)] = "CCB RSS Expanded";

    g_barCodeMap[std::make_pair(101,(int)SCANNER_TYPE_SNAPI)] = "CCB RSS Limited";
    g_barCodeMap[std::make_pair(101,(int)SCANNER_TYPE_IBMHID)] = "CCB RSS Limited";
    g_barCodeMap[std::make_pair(101,(int)SCANNER_TYPE_IBMTT)] = "CCB RSS Limited";

    g_barCodeMap[std::make_pair(102,(int)SCANNER_TYPE_SNAPI)] = "CCB RSS-14";
    g_barCodeMap[std::make_pair(102,(int)SCANNER_TYPE_IBMHID)] = "CCB RSS-14";
    g_barCodeMap[std::make_pair(102,(int)SCANNER_TYPE_IBMTT)] = "CCB RSS-14";

    g_barCodeMap[std::make_pair(103,(int)SCANNER_TYPE_SNAPI)] = "CCB UPC-A";
    g_barCodeMap[std::make_pair(103,(int)SCANNER_TYPE_IBMHID)] = "CCB UPC-A";
    g_barCodeMap[std::make_pair(103,(int)SCANNER_TYPE_IBMTT)] = "CCB UPC-A";

    g_barCodeMap[std::make_pair(104,(int)SCANNER_TYPE_SNAPI)] = "CCB UPC-E";
    g_barCodeMap[std::make_pair(104,(int)SCANNER_TYPE_IBMHID)] = "CCB UPC-E";
    g_barCodeMap[std::make_pair(104,(int)SCANNER_TYPE_IBMTT)] = "CCB UPC-E";

    g_barCodeMap[std::make_pair(105,(int)SCANNER_TYPE_SNAPI)] = "Signature Capture";
    g_barCodeMap[std::make_pair(105,(int)SCANNER_TYPE_IBMHID)] = "Signature Capture";
    g_barCodeMap[std::make_pair(105,(int)SCANNER_TYPE_IBMTT)] = "Signature Capture";

    g_barCodeMap[std::make_pair(113,(int)SCANNER_TYPE_SNAPI)] = "Matrix 2 of 5";
    g_barCodeMap[std::make_pair(113,(int)SCANNER_TYPE_IBMHID)] = "Matrix 2 of 5";
    g_barCodeMap[std::make_pair(113,(int)SCANNER_TYPE_IBMTT)] = "Matrix 2 of 5";

    g_barCodeMap[std::make_pair(114,(int)SCANNER_TYPE_SNAPI)] = "Chinese 2 of 5";
    g_barCodeMap[std::make_pair(114,(int)SCANNER_TYPE_IBMHID)] = "Chinese 2 of 5";
    g_barCodeMap[std::make_pair(114,(int)SCANNER_TYPE_IBMTT)] = "Chinese 2 of 5";

    g_barCodeMap[std::make_pair(136,(int)SCANNER_TYPE_SNAPI)] = "UPC-A+5 Supplemental";
    g_barCodeMap[std::make_pair(136,(int)SCANNER_TYPE_IBMHID)] ="UPC-A+5 Supplemental";
    g_barCodeMap[std::make_pair(136,(int)SCANNER_TYPE_IBMTT)] = "UPC-A+5 Supplemental";

    g_barCodeMap[std::make_pair(137,(int)SCANNER_TYPE_SNAPI)] = "UPC-E0 + 5 Supplemental";
    g_barCodeMap[std::make_pair(137,(int)SCANNER_TYPE_IBMHID)] ="UPC-E0 + 5 Supplemental";
    g_barCodeMap[std::make_pair(137,(int)SCANNER_TYPE_IBMTT)] = "UPC-E0 + 5 Supplemental";

    g_barCodeMap[std::make_pair(138,(int)SCANNER_TYPE_SNAPI)] = "EAN-8 +5 Supplemental";
    g_barCodeMap[std::make_pair(138,(int)SCANNER_TYPE_IBMHID)] ="EAN-8 +5 Supplemental";
    g_barCodeMap[std::make_pair(138,(int)SCANNER_TYPE_IBMTT)] = "EAN-8 +5 Supplemental";

    g_barCodeMap[std::make_pair(139,(int)SCANNER_TYPE_SNAPI)] = "EAN-13 + 5 Supplemental";
    g_barCodeMap[std::make_pair(139,(int)SCANNER_TYPE_IBMHID)] ="EAN-13 + 5 Supplemental";
    g_barCodeMap[std::make_pair(139,(int)SCANNER_TYPE_IBMTT)] = "EAN-13 + 5 Supplemental";

    g_barCodeMap[std::make_pair(144,(int)SCANNER_TYPE_SNAPI)] = "UPC-E1 + 5 Supplemental";
    g_barCodeMap[std::make_pair(144,(int)SCANNER_TYPE_IBMHID)] = "UPC-E1 + 5 Supplemental";
    g_barCodeMap[std::make_pair(144,(int)SCANNER_TYPE_IBMTT)] = "UPC-E1 + 5 Supplemental";

    g_barCodeMap[std::make_pair(154,(int)SCANNER_TYPE_SNAPI)] = "Macro Micro PDF";
    g_barCodeMap[std::make_pair(154,(int)SCANNER_TYPE_IBMHID)] = "Macro Micro PDF";
    g_barCodeMap[std::make_pair(154,(int)SCANNER_TYPE_IBMTT)] = "Macro Micro PDF";
    
    g_barCodeMap[std::make_pair(183,(int)SCANNER_TYPE_SNAPI)] = "Han Xin";
    g_barCodeMap[std::make_pair(183,(int)SCANNER_TYPE_IBMHID)] = "Han Xin";
    g_barCodeMap[std::make_pair(183,(int)SCANNER_TYPE_IBMTT)] = "Han Xin";

    g_barCodeMap[std::make_pair(193,(int)SCANNER_TYPE_SNAPI)] = "GS1 DATA MATRIX";
    g_barCodeMap[std::make_pair(193,(int)SCANNER_TYPE_IBMHID)] ="GS1 DATA MATRIX";
    g_barCodeMap[std::make_pair(193,(int)SCANNER_TYPE_IBMTT)] = "GS1 DATA MATRIX";

    g_barCodeMap[std::make_pair(196,(int)SCANNER_TYPE_SNAPI)] = "DotCode";
    g_barCodeMap[std::make_pair(196,(int)SCANNER_TYPE_IBMHID)] = "DotCode";
    g_barCodeMap[std::make_pair(196,(int)SCANNER_TYPE_IBMTT)] = "DotCode";

    g_barCodeMap[std::make_pair(200,(int)SCANNER_TYPE_SNAPI)] = "Grid Matrix";
    g_barCodeMap[std::make_pair(200,(int)SCANNER_TYPE_IBMHID)] = "Grid Matrix";
    g_barCodeMap[std::make_pair(200,(int)SCANNER_TYPE_IBMTT)] = "Grid Matrix";

    g_barCodeMap[std::make_pair(209,(int)SCANNER_TYPE_SNAPI)] = "Rectangular Micro QR Code";
    g_barCodeMap[std::make_pair(209,(int)SCANNER_TYPE_IBMHID)] = "Rectangular Micro QR Code";
    g_barCodeMap[std::make_pair(209,(int)SCANNER_TYPE_IBMTT)] = "Rectangular Micro QR Code";


	debug_print("end function");
}

std::string symbologyTypeToStr(int iSymbologyType, ScannerType iScannerType)
{
    debug_print(" function start ");
    std::string _return = g_barCodeMap[std::make_pair(iSymbologyType,(int)iScannerType)] ;
    debug_print( "function end");
    return _return;
}



// tokernize string for a given delimiter //
static char tokernize_buffer[ 256];
std::vector<std::string> stringTokernize(std::string inStr,char cDelim )
{
    debug_print("function start");    
    std::vector<std::string> _return;

    int iLength = inStr.size();
    int iCurrentIndex = 0;
    int iCurrentOutputIndex =0;
    while ( iCurrentIndex < iLength ){
        char cCurrentChar = inStr[iCurrentIndex++];
        if (cDelim == cCurrentChar  ){
            if ( iCurrentOutputIndex == 0 )
            {
                // just ignore//
            }else {
                tokernize_buffer[iCurrentOutputIndex] =0;
                _return .push_back( tokernize_buffer);
                iCurrentOutputIndex= 0;
            }
        }else{
            tokernize_buffer[iCurrentOutputIndex++] = (char)cCurrentChar;
        }
    }
    
    if ( iCurrentOutputIndex > 0){
        tokernize_buffer[iCurrentOutputIndex] = 0;
        _return.push_back(tokernize_buffer);
    }
    
    debug_print("function end");
    return _return;
}

std::string scannerType2str(ScannerType scannerType )
{
    if ( scannerType == SCANNER_TYPE_SNAPI )
        return "SNAPI";
    if ( scannerType == SCANNER_TYPE_IBMHID )
        return "IBMHID";
    if ( scannerType == SCANNER_TYPE_IBMTT )
        return "IBMTT";
    if ( scannerType == SCANNER_TYPE_HIDKB )
        return "HIDKB";
    else
        return "";
}

ScannerType string2scannertype( std::string strScannerType )
{
    if ( strScannerType.compare("SNAPI") ==0 ) {
        return SCANNER_TYPE_SNAPI;
    } else if ( strScannerType.compare("IBMHID") == 0 ) {
        return SCANNER_TYPE_IBMHID;
    } else if ( strScannerType.compare("IBMTT")==0 ) {
        return SCANNER_TYPE_IBMTT;
    } else if ( strScannerType.compare("HIDKB")== 0 ) {
        return SCANNER_TYPE_HIDKB;
    } 

    debug_print("Scanner type is not valid.");
    return SCANNER_TYPE_INVALID;
   
}

std::vector<Scanner>  parseGetScannersOutXml(std::string outXml){    
    debug_print("function start");
    std::vector<Scanner> _return ;
    pugi::xml_document doc;
    pugi::xml_parse_result result=  doc.load_string( outXml.c_str() );
    if ( result.status != pugi::status_ok ){
        debug_print("parsing outxml failed." );
        return _return ;
    }    
    
    pugi::xml_node nodeCurrentScanner = doc.child("scanners").child("scanner");
    if ( ! nodeCurrentScanner )
    {
        debug_print("no scanners found");
        // :FLOW THROUGH: //
    }
    
    for ( ; nodeCurrentScanner ; nodeCurrentScanner = nodeCurrentScanner.next_sibling() )
    {
        int iCurrentScannerId = atoi( nodeCurrentScanner.child("scannerID").child_value());
        pugi::xml_attribute attributeScannerType = nodeCurrentScanner.attribute("type");
        if ( ! attributeScannerType )
            debug_print("attribute type does not found in scanner node");
        
        std::string strScannerType = attributeScannerType.value();
        ScannerType currentScannerType = string2scannertype( strScannerType);
        
        Scanner scannerObj;
        scannerObj.scannerType = currentScannerType;
        scannerObj.iScannerId = iCurrentScannerId;
        scannerObj.strComInterface = scannerType2str(currentScannerType);
        scannerObj.strModel = nodeCurrentScanner.child("modelnumber").child_value();
        scannerObj.strSerialOrPort = nodeCurrentScanner.child("serialnumber").child_value();
        scannerObj.strFirmware = nodeCurrentScanner.child("firmware").child_value();
        scannerObj.strBuild = nodeCurrentScanner.child("DoM").child_value();
        scannerObj.strGUID = nodeCurrentScanner.child("GUID").child_value();
        _return.push_back(scannerObj);
    }
       
    return _return;
}

int  get_scanner_count(std::vector<Scanner> vecScanners, ScannerType scannerType )
{
    debug_print("function start");
    int i_return=0;
    std::vector<Scanner>::iterator itr ;
    
    for( itr = vecScanners.begin() ; itr != vecScanners.end() ; itr++ )
    {
        if( (*itr).scannerType == scannerType  )
            i_return++;
    }
    
    debug_print("function end");
    return i_return;
}


int get_symbology_type( std::string outXml )
{
    debug_print("function start");
    pugi::xml_document doc ;
    pugi::xml_parse_result parse_result = doc.load_string(outXml.c_str());
    if ( pugi::status_ok != parse_result.status)
    {
        debug_print("loading outXml to pugi failed.");
        return 0;
    }
    
    pugi::xml_node nodeDataType = doc.child("outArgs").child("arg-xml").
            child("scandata").child("datatype");
    int iDataType = atoi( nodeDataType.child_value() );
    
    debug_print("function end");
    return iDataType;
}


static char buffer_decode_data [ 1024*256] ; // hope we don't have barcodes beyond 256 KB of length. //
std::string get_decode_data(std::string outXml){
    debug_print("function start");
    // :TODO: 
    pugi::xml_document doc;
    pugi::xml_parse_result parse_result = doc.load_string( outXml.c_str());
    if ( pugi::status_ok != parse_result.status)
    {
        debug_print("loading outXml to pugi failed.");
        return "";
    }
    
    pugi::xml_node nodeDataLabel = doc.child("outArgs").child("arg-xml").
            child("scandata").child("datalabel");
    const char * cstrDataLabel = nodeDataLabel.child_value();
    int iLength = strlen( cstrDataLabel);
    
    if (iLength < 1)
    {
        debug_print("get_decode_data :: outXml->datalabel has no data");
    }
    
    std::vector<std::string> vecStrTokernized = stringTokernize(cstrDataLabel, ' ');
    std::vector<std::string>::iterator itr;
    int iIndexOutput = 0;
    int cCurrentChar ;
    for( itr = vecStrTokernized.begin(); itr != vecStrTokernized.end();itr++){
        std::string strCurrentToken = *itr;
        int iRet = sscanf( strCurrentToken.c_str(), "%x" , &cCurrentChar);
        if ( iRet == 0){
            sscanf( strCurrentToken.c_str() , "%x" , &cCurrentChar);
        }
        buffer_decode_data[iIndexOutput++] = (char) cCurrentChar;
    }
    
    buffer_decode_data[iIndexOutput] = 0;
    
    debug_print("function end");
    
    return buffer_decode_data;
}

ScannerType getScaannerTypeFromId(std::vector<Scanner> vecScanners , int id)
{
    debug_print("function start");
    ScannerType _return = SCANNER_TYPE_INVALID;
    std::vector<Scanner>::iterator itr;
    for( itr = vecScanners.begin() ; itr != vecScanners.end() ; itr++)
    {
        if ( (*itr).iScannerId == id)
            _return = (*itr).scannerType ;
    }
    
    debug_print("function end");
    return _return;
}

int getScannerIdFromBarcodeData (std::string strBarcodeData)
{
    debug_print("function start");
    int _ret;
    pugi::xml_document doc;
    pugi::xml_parse_result parse_result = doc.load_string( strBarcodeData.c_str());
    if ( pugi::status_ok != parse_result.status)
    {
        debug_print("loading outXml to pugi failed.");
        return 0;
    }    
    
    pugi::xml_node nodeScannerId = doc.child("outArgs").child("scannerID");
    _ret = atoi( nodeScannerId.child_value() );
   
    debug_print("function end");
    return _ret;
}



std::string GetErrorMessage(StatusID eStatus) {
    std::string error = "";
    switch(eStatus)
    {
        case STATUS_ERROR:
            error = "CoreScanner error";
            break;
        case STATUS_ERROR_PARTIAL_SUCCESS:
            error = "Partial success";
            break;
        case STATUS_ERROR_DEVICE_NOT_AVAILABLE:
            error = "Device not available";
            break;
        case STATUS_ERROR_COMMAND_RESPONSE_TIMED_OUT:
            error = "Command response timeout";
            break;
        case STATUS_ERROR_COMMLIB_UNAVAILABLE:
            error = "Required Comm Lib is unavailable to support the requested Type";
            break;
        case STATUS_ERROR_INCORRECT_BUFFER_SIZE:
            error = "When registering for events, inXml event count is not equal to actual no. of events";
            break;
        case STATUS_ERROR_INVALID_ARG:
            error = "Invalid argument";
            break;
        case STATUS_ERROR_INVALID_SCANNERID:
            error = "Invalid scanner ID";
            break;
        case STATUS_ERROR_INCORRECT_NUMBER_OF_EVENTS:
            error = "Incorrect value for number of Event IDs";
            break;
        case STATUS_ERROR_DUPLICATE_EVENTID:
            error = "Event IDs are duplicated";
            break;
        case STATUS_ERROR_INVALID_EVENTID:
            error = "Invalid value for Event ID";
            break;
        case STATUS_ERROR_DEVICE_UNAVAILABLE:
            error = "Required device is unavailable";
            break;
        case STATUS_ERROR_INVALID_OPCODE:
            error = "Opcode is invalid";
            break;
        case STATUS_ERROR_INVALID_TYPE:
            error = "Invalid value for Type";
            break;
        case STATUS_ERROR_ASYNC_NOT_SUPPORTED:
            error = "Opcode does not support asynchronous method";
            break;
        case STATUS_ERROR_OPCODE_NOT_SUPPORTED:
            error = "Device does not support the Opcode";
            break;
        case STATUS_ERROR_OPERATION_FAILED:
            error = "Operation failed in device";
            break;
        case STATUS_ERROR_REQUEST_FAILED:
            error = "Request failed in CoreScanner";
            break;
        case STATUS_ERROR_DEVICE_BUSY:
            error = "Device Busy. Applications should retry command";
            break;
        case STATUS_ERROR_CDC_SCANNERS_NOT_FOUND:
            error = "No CDC scanners found in the system";
            break;
        case STATUS_ERROR_UNABLE_TO_OPEN_CDC_COM_PORT:
            error = "Unable to open CDC port";
            break;
        case STATUS_ERROR_ALREADY_OPENED:
            error = "CoreScanner is already opened";
            break;
        case STATUS_ERROR_ALREADY_CLOSED:
            error = "CoreScanner is already closed";
            break;
        case STATUS_ERROR_CLOSED:
            error = "CoreScanner is closed";
            break;
        case STATUS_ERROR_INVALID_INXML:
            error = "Invalid in-XML";
            break;
        case ERROR_FW_INVALID_DATFILE:
            error = "Invalid firmware file";
            break;
        case ERROR_FW_UPDATE_FAILED_IN_SCN:
            error = "FW Update failed in scanner";
            break;
        case ERROR_FW_READ_FAILED_DATFILE:
            error = "Failed to read DAT file";
            break;
        case ERROR_FW_UPDATE_INPROGRESS:
            error = "A firmware Update is in progress";
            break;
        case ERROR_FW_UPDATE_ALREADY_ABORTED:
            error = "Firmware update is already aborted";
            break;
        case ERROR_FW_UPDATE_ABORTED:
            error = "FW Update aborted";
            break;
        case ERROR_FW_SCN_DETTACHED:
            error = "Scanner is disconnected while updating firmware";
            break;
        case STATUS_FW_SWCOMP_RESIDENT:
            error = "The software component is already resident in the scanner";
            break;
        case STATUS_ERROR_INVALID_CONFIG_FILE:
            error = "Invalid configuration file";
            break;
        case STATUS_ERROR_INCOMPATIBLE_CONFIG_FILE:
            error = "Incompatible configuration file";
            break;
        case STATUS_ERROR_CONFIG_FILE_SYNTAX_VALIDATION_FAILED:
            error = "Syntax error detected in configuration file";
            break;            
        default:
            error = "Error message is not available for the CoreScanner error";
            break;
    }
    
    return error;
}