/*   (c)2016 Zebra Technologies LLC. All rights reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *    
 *   bug_me: ems.support@zebra.com 
 */


// local includes //
#include "debug.h"
#include "scanner.h"
#include "util.h"
#include "xml_formatter.h"
#include "pugiconfig.hpp"
#include "pugixml.hpp"

// system includes //
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <string>
#include <boost/thread/mutex.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/numeric/conversion/cast.hpp>
#include <gtk/gtk.h>
#include <string.h>
#include <queue>
#include <sstream>
// Zebra Scanner Linux SDK include files //
#include <CsUserDefs.h>
#include <CsBarcodeTypes.h>
#include <Cslibcorescanner_xml.h>
#include <boost/thread/pthread/recursive_mutex.hpp>
#include <math.h> 

#include <boost/thread/thread.hpp>

// Mode attribute property defines - bit definitions
#define ATT_READ       0x01
#define ATT_WRITE      0x02
#define ATT_PERSISTENT 0x04

// USER mode properties - lower nibble
#define ATT_UM_RO      (ATT_READ)
#define ATT_UM_RW      (ATT_WRITE | ATT_READ)
#define ATT_UM_PRW     (ATT_PERSISTENT | ATT_WRITE | ATT_READ)
#define ATT_UM_WO      (ATT_WRITE)

int iCurrentlySelectedScannerId =0;
int g_iSNAPIScannerCount =0;
int g_iIBMTTScannerCount =0;
int g_iIBMHIDScannerCount = 0;
int g_iHIDKBScannerCount = 0;

#define RETURN_WEIGHT_LEN 12
#define READ_WEIGHT_LEN 8

// data which could be modified by two different threads //
boost::recursive_mutex g_access_mutex;
bool   g_bScheduleUpdateScannerList;
bool   g_bScheduleUpdateStatusbar ;
bool   g_bScheduleNewLogMessage;
bool   g_bScheduleNewXmlMessage;
std::vector<std::string> g_vecStringStatusBarMessages;
std::vector<std::string> g_vecStringNewLogMsg;
std::vector<std::string> g_vecStringNewXmlMsg;
bool g_bScheduleUpdateBarcode ;
std::string g_strBarcodeOutXml;
std::vector<Scanner> g_vecScanners;
#define MAX_IMAGEVIDEO_DATA_SIZE 1024*1024*5 // 5MB 
bool g_bScheduleUpdateImage ;
int g_iImageSize;
char g_ImageVideoData[MAX_IMAGEVIDEO_DATA_SIZE];
bool g_isImageJpeg;
bool g_isImageTiff;
bool g_isImageBmp;
bool g_bScheduleScrollDown ;
bool g_bScheduleNotification;
bool g_bUpdateInProgress;

typedef struct tag_rmd_event_notification
{
    int iNotificationType ;
    int iCurrentRecord;
    int iCurrentSessInfoStatus;
} queue_rmd_event_notification ;

struct RTAEvent {
    std::string id;
    std::string stat;
    std::string onlimit;
    std::string offlimit;
};
 
 
struct RTAEventStatus {
    
    int id;
    int stat;
    int scope;
    bool registered;
    bool reported;
    bool initialized;
    bool measuring;
 
};

std::queue<queue_rmd_event_notification> g_queueNotifications;

boost::thread* configuration_update_thread_;
bool configuration_update_in_progress_;
std::string configuration_file_path_;
std::string str_default_value = "10";

int g_iNotificationType ;
int g_iFullRecordCount;
int g_iCurrentRecord;
int g_iCurrentSessInfoStatus;
int g_iMaxCountNumberConfiguration;
GtkBuilder * g_gtk_builder;
GtkWidget * g_main_window ;
GtkWidget * g_button_discover_scanners;
GtkWidget * g_combo_box_select_scanner;
GtkWidget * g_tree_view_scanners ;
GtkWidget * g_button_pull_trigger;
GtkWidget * g_button_release_trigger;
GtkWidget*  g_text_view_event_log;
GtkWidget*  g_text_view_xml_log;
GtkWidget * g_status_bar_main;
GtkWidget* g_button_clear_event_log;
GtkWidget* g_button_clear_xml_log;
GtkWidget* g_text_view_barcode_data;
GtkWidget* g_entry_decode_barcode;
GtkWidget* g_entry_symbology;
GtkWidget* g_button_clear_barcode;
GtkWidget* g_button_image_mode;
GtkWidget* g_button_video_mode;
GtkWidget* g_button_barcode_mode;
GtkWidget* g_image;
GtkWidget* g_checkbutton_disable_scanner;
GtkWidget* g_button_reboot_scanner;
GtkWidget* g_button_get_supported_rta_events;
GtkWidget* g_button_get_rta_event_status;
GtkWidget* g_button_clear_all_rta;
GtkWidget* g_combo_box_led_on_off;
GtkWidget* g_button_led_on;
GtkWidget* g_button_led_off;
GtkWidget* g_button_aim_on;
GtkWidget* g_button_aim_off;
GtkWidget* g_button_beep;
GtkWidget* g_combo_box_select_beep;
GtkWidget* g_combo_box_switch_host_variant ;
GtkWidget* g_check_button_silent_switch_host_mode;
GtkWidget* g_check_button_permanent_switch_host_mode;
GtkWidget* g_button_switch_host_mode;
GtkWidget* g_tree_view_rsm ;
GtkWidget* g_button_get_all_ids;
GtkWidget* g_button_next_value;
GtkWidget* g_button_store;
GtkWidget* g_button_get_value ;
GtkWidget* g_button_set_value;
GtkWidget* g_button_select_all;
GtkWidget* g_button_clear_all;
GtkWidget* g_button_firmware_browse;
GtkWidget* g_button_configuration_browse;
GtkWidget* g_checkbutton_firmware_bulk_update;
GtkWidget* g_text_entry_firmware;
GtkWidget* g_text_entry_configuration;
GtkWidget* g_button_firmware_update;
GtkWidget* g_button_configuration_update;
GtkWidget* g_button_firmware_launch;
GtkWidget* g_button_firmware_abort;
GtkWidget* g_progressbar_firmware;
GtkWidget* g_progressbar_configuration;
GtkWidget* g_button_save_image;
GtkWidget* g_check_button_image_jpg;
GtkWidget* g_check_button_image_tiff;
GtkWidget* g_check_button_image_bmp;
GtkWidget* g_label_firmware_progress;
GtkWidget* g_label_configuration_progress;
GtkWidget* g_check_button_enable_view_finder;
GtkWidget* g_button_read_weight;
GtkWidget* g_button_zero_scale;
GtkWidget* g_button_reset_scale;
GtkWidget* g_entry_weight_measured;
GtkWidget* g_entry_weight_unit;
GtkWidget* g_label_scale_status;
GtkWidget* g_button_pager_motor_start;
GtkWidget* g_entry_duration;
GtkWidget* g_frame_scale_tab_buttons;
GtkWidget* g_frame_scale_tab_entries;
GtkWidget* g_check_button_enable_keyboard_emulation;

GtkWidget* g_rta_config_settings;

static GtkListStore *current_store = NULL; 

static void connect_corescanner();
static void initialize_widgets();
static void initialize_tree_view_scanners();
static void initialize_combo_box_select_scanner();
static void app_initialize();

static void populate_tree_view_scanenrs(std::vector<Scanner> vecScanners);
static void button_discover_scanners_clicked(GtkWidget* button, gpointer data);
static void run_modal_message_box( std::string  strMessage , std::string strTitle);
static void combo_box_select_scanner_populate(std::vector<Scanner> vecScanners);
static void update_scanner_list();
static  gboolean update_poll_function(gpointer data);
static void combo_box_select_scanner_changed( GtkComboBox* widget,gpointer user_data);
static void tree_view_scanners_row_activated( GtkTreeView * tree_view, GtkTreePath *path, \
                                        GtkTreeViewColumn * column, gpointer user_data);
static void update_status_bar();
static void write_status_bar(std::string strMessage);
static void append_new_event_log_msg(const char *fmt,...);
static void append_new_xml_log(std::string strMessage);
static void update_event_log();
static void update_xml_log();
static void button_clear_event_log_clicked(GtkWidget* button, gpointer data);
static void button_clear_xml_log_clicked(GtkWidget* button, gpointer data);
static void app_deinitialize();
static void main_window_close_button_clicked();
static void update_barcode_data();
static void tree_view_scanners_cursor_changed( GtkTreeView* tree_view, \
        GtkTreePath *path, GtkTreeViewColumn* column ,\
        gpointer user_data);

static void button_clear_barcode_clicked(GtkWidget* widget, gpointer data);

static void valid_scanner_selected();
static void scanners_unselected();
static void initialize_combo_box_switch_host_mode();
static void button_pull_trigger_clicked(GtkWidget* , gpointer);
static void button_release_trigger_clicked(GtkWidget* , gpointer);

static void button_video_mode_clicked(GtkWidget* , gpointer);
static void button_image_mode_clicked(GtkWidget* , gpointer);
static void button_barcode_mode_clicked(GtkWidget* , gpointer);
static void set_image_empty();
static void set_new_image_from_data();
static void scroll_log_text_view();
static void disable_scanner_check_button_toggled(GtkToggleButton* togglebutton,
        gpointer user_data);
static void button_reboot_scanner_clicked(GtkWidget* , gpointer);
static void button_supported_rta_events_clicked(GtkWidget* , gpointer);
static void button_get_rta_event_status_clicked(GtkWidget* , gpointer);
static void button_clear_all_rta_clicked(GtkWidget* widget, gpointer user_data);
static void on_checkbox_toggled(GtkCellRendererToggle *cell_renderer, gchar *path, gpointer user_data);
static void initialize_led_on_off_combo_box();
static void button_led_on_clicked( GtkWidget* , gpointer );
static void button_led_off_clicked( GtkWidget* , gpointer );

static void button_aim_on_clicked( GtkWidget* , gpointer);
static void button_aim_off_clicked(GtkWidget* ,gpointer);
static void button_beep_clicked(GtkWidget* , gpointer );
static void button_pager_motor_start_clicked(GtkWidget*, gpointer);

static void initialize_combo_box_beep();
static void button_beep_clicked( GtkWidget* , gpointer );
static void button_switch_host_mode_clicked( GtkWidget* , gpointer );
static void button_get_all_ids_clicked(GtkWidget* , gpointer);
static void button_next_value_clicked(GtkWidget* , gpointer);
static void button_store_clicked(GtkWidget*,gpointer);
static void button_get_value_clicked(GtkWidget*,gpointer);
static void button_set_value_clicked(GtkWidget* , gpointer);
static void button_select_all_clicked(GtkWidget*, gpointer);
static void button_clear_all_clicked(GtkWidget* , gpointer);
static void initialize_tree_view_rsm();
void rsm_tree_view_cell_edited_callback(GtkCellRendererText * cell,\
        gchar *path_string,\
        gchar *new_text ,\
        gpointer user_data);

static void button_firmware_browse_clicked(GtkWidget* , gpointer);
static void button_configuration_browse_clicked(GtkWidget* , gpointer);
static void button_firmware_update_clicked(GtkWidget* , gpointer);
static void button_configuration_update_clicked(GtkWidget* , gpointer);
static void button_firmware_launch_clicked(GtkWidget* , gpointer);
static void button_firmware_abort_clicked(GtkWidget* , gpointer);
static void button_save_image_clicked( GtkWidget* , gpointer);
static void set_image_type_toggle_button_clicked( GtkToggleButton *togglebutton , gpointer userData);
static void check_button_enable_view_finder_toggled(GtkToggleButton * togglebutton, gpointer user_data);
static void update_status_check_button_enable_view_finder();
static void check_button_enable_keyboard_emulation_toggled(GtkWidget* , gpointer);
static void update_hidkb_emulation_setting();

void write_scanner_status_to_status_bar(int errorId);


static void button_read_weight_clicked(GtkWidget* , gpointer);
static void button_zero_scale_clicked(GtkWidget* , gpointer);
static void button_reset_scale_clicked(GtkWidget* , gpointer);

// event listener
class SampleEventListener : public IEventListenerXml
{
public:
	explicit SampleEventListener();
	virtual ~SampleEventListener();

    virtual void OnBinaryDataEvent(short eventType,int size,short imageFormat,unsigned char* sfbinaryData,std::string& pScannerData );
    virtual void OnImageEvent(short eventType,int size,short imageFormat,char* sfimageData,int dataLength,std::string& pScannerData );
    virtual void OnVideoEvent(short eventType,int size,char* sfvideoData,int dataLength, std::string& pScannerData );
    virtual void OnBarcodeEvent( short eventType, std::string& pscanData);
    virtual void OnPNPEvent(short eventType, std::string ppnpData);
    virtual void OnCommandResponseEvent( short status, std::string& prspData);
    virtual void OnScannerNotification(short notificationType, std::string& pScannerData);
    virtual void OnIOEvent(short type, unsigned char data);
    virtual void OnScanRMDEvent(short eventType, std::string& prmdData);
    virtual void OnDisconnect();
} g_event_listener;


SampleEventListener::SampleEventListener(){
    debug_print(" start ");

    
    debug_print(" end ");
}

SampleEventListener::~SampleEventListener()
{
    debug_print(" start ");
    
    
    debug_print(" end ");
}

void SampleEventListener::OnImageEvent(short eventType, int size, short imageFormat, char* sfimageData, int dataLength, std::string& pScannerData)
{
    debug_print(" start ");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleUpdateImage = true;
    memcpy(g_ImageVideoData,sfimageData,dataLength);
        
    if ( eventType == IMAGE_COMPLETE )
    {
        write_status_bar("New Image Event Received.");
        append_new_event_log_msg("Image Event");
    }else{
        write_status_bar("Incomplete Image Transfer.");
        append_new_event_log_msg("video transfer incomplete");
    }
        
    g_iImageSize = size ;
    
    if ( imageFormat == JPEG_FILE_SECTION )
    {
        g_isImageJpeg = true;
        g_isImageBmp = false;
        g_isImageTiff = false ;
    }else if ( imageFormat == TIFF_FILE_SECTION ){
        g_isImageJpeg = false;
        g_isImageBmp = false;
        g_isImageTiff = true ;
    }
    else {
        g_isImageJpeg = false;
        g_isImageBmp = true;
        g_isImageTiff = false;
    }
    
    append_new_xml_log(pScannerData);
    debug_print (" end ");
}

void SampleEventListener::OnBinaryDataEvent(short eventType, int size, short imageFormat, unsigned char* sfbinaryData, std::string& pScannerData)
{
    debug_print(" start ");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleUpdateImage = true;
    memcpy(g_ImageVideoData,sfbinaryData,size);
        
    if ( eventType == IMAGE_COMPLETE )
    {
        write_status_bar("New BinaryData Event Received.");
        append_new_event_log_msg("BinaryData Event");
    }else{
        write_status_bar("Incomplete BinaryData Transfer.");
        append_new_event_log_msg("BinaryData transfer incomplete");
    }
        
    g_iImageSize = size ;
    
    if ( imageFormat == JPEG_FILE_SECTION )
    {
        g_isImageJpeg = true;
        g_isImageBmp = false;
        g_isImageTiff = false ;
    }else if ( imageFormat == TIFF_FILE_SECTION ){
        g_isImageJpeg = false;
        g_isImageBmp = false;
        g_isImageTiff = true ;
    }
    else {
        g_isImageJpeg = false;
        g_isImageBmp = true;
        g_isImageTiff = false;
    }
    
    append_new_xml_log(pScannerData);
    debug_print (" end ");
}

void SampleEventListener::OnVideoEvent(short eventType, int size, char* sfvideoData, int dataLength, std::string& pScannerData)
{
    debug_print( " start ");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleUpdateImage = true;
    memcpy(g_ImageVideoData,sfvideoData,dataLength);
    
    
    if ( eventType == IMAGE_COMPLETE )
    {
        write_status_bar("New Video event received");
        append_new_event_log_msg("Video Event");
    }else
    {
        write_status_bar("Incomplete video transfer status " );
        append_new_event_log_msg("Video transfer incomplete");
    }
    
    g_iImageSize = dataLength;
    append_new_xml_log(pScannerData);

    debug_print("size :%d " , dataLength);
    g_isImageJpeg = true;

    debug_print ( " end " );
}

void SampleEventListener::OnBarcodeEvent(short eventType, std::string& pscanData)
{
    debug_print( " start ");
    
    boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex);
    g_bScheduleUpdateBarcode = true;
    g_strBarcodeOutXml = pscanData;
    
    append_new_event_log_msg("Data event received.");
    append_new_xml_log(pscanData);

    debug_print( " end ");
}

void SampleEventListener::OnPNPEvent(short eventType, std::string ppnpData)
{
    debug_print (" start ");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleUpdateScannerList = true;  
    
    append_new_event_log_msg("OnPNPEvent");
    append_new_xml_log(ppnpData);
    
    debug_print( " end " );
}

void SampleEventListener::OnCommandResponseEvent(short status, std::string& prspData) {
    debug_print (" start ");
    
    debug_print (" end ");
}


void SampleEventListener::OnScannerNotification(short notificationType, std::string& pScannerData) {
    debug_print("  start ");
    
    switch ( notificationType ){
        
        case SCANNER_NOTIFICATION_DECODE_MODE:
            write_status_bar("Scanner Notification : Barcode Mode");
            append_new_event_log_msg("Scanner Notification : Barcode Mode");
            append_new_xml_log(pScannerData);
            break;
         
        case SCANNER_NOTIFICATION_SNAPSHOT_MODE:
            write_status_bar("Scanner Notification : Image Mode");
            append_new_event_log_msg("Scanner Notification : Image Mode");
            append_new_xml_log(pScannerData);
            break;
        case SCANNER_NOTIFICATION_VIDEO_MODE:
            write_status_bar("Scanner Notification : Video Mode");
            append_new_event_log_msg("Scanner Notification : Video Mode");
            append_new_xml_log(pScannerData);
            break;
 	case SCANNER_NOTIFICATION_NO_DECODE_EVENT: //**Added this for testing purpose
            write_status_bar("Scanner Notification : No-Decode Event");
            append_new_event_log_msg("Scanner Notification : No-Decode Event");
            append_new_xml_log(pScannerData);
            break;
        default:
            append_new_event_log_msg("Unknown OnScanner notification.");
            break;
        
    }
   
    debug_print( " end ");
}

void SampleEventListener::OnIOEvent(short type, unsigned char data) {
    debug_print("  start ");
    
    debug_print( "   end ");
}

void SampleEventListener::OnScanRMDEvent(short eventType, std::string& prmdData)
{
    debug_print("  start ");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleNotification = true ;
    g_iNotificationType = 0;
    
    pugi::xml_document doc ;
    pugi::xml_parse_result result = doc.load_string( prmdData.c_str() );
    if ( result.status != pugi::status_ok )
    {
        debug_print("OnScanRMDEvent invalid scanner info found");
        write_status_bar("onScanRMDEvent invalid scanner info received.");
        return ;
    }
    
    //pugi::xml_node nodeScannerId = doc.child("outArgs").child("scannerID");
    if(eventType==SCANNER_UF_SESS_START )
    {
        pugi::xml_node node_sess_start = doc.child("outArgs").child("arg-xml").child("sess_start");
        if ( node_sess_start != NULL )
        {
            debug_print("session_start");
            //g_iNotificationType = SCANNER_UF_SESS_START ;
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UF_SESS_START;
            g_queueNotifications.push(currentNotification);        
            pugi::xml_node node_max_count = node_sess_start.child("maxcount");
            g_iFullRecordCount = atoi( node_max_count.child_value() );
            g_iCurrentRecord =0;
            append_new_event_log_msg("SCANNER_UF_SESS_START");
            append_new_xml_log(prmdData);
         }
    }
    else if (eventType==SCANNER_UF_DL_START)
    {
              
        pugi::xml_node node_dl_start = doc.child("outArgs").child("arg-xml").child("dl_start");
        if(node_dl_start != NULL )
        {
            debug_print("dl_start");
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UF_DL_START;
            g_queueNotifications.push( currentNotification);
            append_new_event_log_msg("SCANNER_UF_DL_START");
            append_new_xml_log(prmdData);
        }
    }
    else if (eventType==SCANNER_UF_DL_PROGRESS)
    {
         
    
        pugi::xml_node node_dl_progress = doc.child("outArgs").child("arg-xml").child("dl_progress");
        if( node_dl_progress )
        {
            debug_print("dl_progress");
            queue_rmd_event_notification currentNotification;
            pugi::xml_node node_progress = node_dl_progress.child("progress");
            currentNotification.iCurrentRecord = atoi(node_progress.child_value()); 
            currentNotification.iNotificationType = SCANNER_UF_DL_PROGRESS;
            g_queueNotifications.push( currentNotification);

            debug_print("Progress :%d" , g_iCurrentRecord);
            append_new_event_log_msg("SCANNER_UF_DL_PROGRESS");
            append_new_xml_log(prmdData);
        }
    }
    else if (eventType==SCANNER_UF_DL_END)
    {    
        pugi::xml_node node_dl_end = doc.child("outArgs").child("arg-xml").child("dl_end");
        if(node_dl_end != NULL )
        {
            debug_print("dl_end");
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UF_DL_END;
            g_queueNotifications.push( currentNotification );
            append_new_event_log_msg("SCANNER_UF_DL_END");
            append_new_xml_log(prmdData);
        }
    }        
    else if (eventType==SCANNER_UF_SESS_END)
    {        
    
        pugi::xml_node node_sess_end = doc.child("outArgs").child("arg-xml").child("sess_end");
        if ( node_sess_end )
        {
            debug_print("sess_end");
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UF_SESS_END;
            g_queueNotifications.push( currentNotification );
            append_new_event_log_msg("SCANNER_UF_SESS_END");
            append_new_xml_log(prmdData);
        }
        
    }
    else if (eventType==SCANNER_UC_SESS_START)
    {
        pugi::xml_node node_sess_start = doc.child("outArgs").child("arg-xml").child("uc_sess_start");
        if ( node_sess_start )
        {
            debug_print("uc_sess_start");
            std::stringstream stream;
            std::string max_count= doc.child("outArgs").child("arg-xml").child("uc_sess_start").child("maxcount").child_value();
            
            stream.clear();
            stream.str(max_count); 
            stream>>g_iMaxCountNumberConfiguration;        
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UC_SESS_START;
            currentNotification.iCurrentRecord =0 ;
            g_queueNotifications.push( currentNotification );
            append_new_event_log_msg("SCANNER_UC_SESS_START");
            append_new_xml_log(prmdData);
        }
    }
    else if (eventType==SCANNER_UC_PROGRESS)
    {
        pugi::xml_node node_sess_progress = doc.child("outArgs").child("arg-xml").child("uc_progress");
        if ( node_sess_progress )
        {
            debug_print("uc_progress");
            int progress; 
            std::stringstream stream_progress;         
            
            std::string progress_str=doc.child("outArgs").child("arg-xml").child("uc_progress").child("progress").child_value();
            
            stream_progress.clear();
            stream_progress.str(progress_str); 
            stream_progress>>progress; 
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UC_PROGRESS;
            currentNotification.iCurrentRecord = progress;
            g_queueNotifications.push( currentNotification );
            append_new_event_log_msg("SCANNER_UC_PROGRESS");
            append_new_xml_log(prmdData);
        }
    }
    else if (eventType==SCANNER_UC_SESS_END)
    {
        pugi::xml_node node_sess_end = doc.child("outArgs").child("arg-xml").child("uc_sess_end");
        if ( node_sess_end )
        {
            debug_print("uc_sess_end");
            queue_rmd_event_notification currentNotification;
            currentNotification.iNotificationType = SCANNER_UC_SESS_END;
            g_queueNotifications.push( currentNotification );
            append_new_event_log_msg("SCANNER_UC_SESS_END");
            append_new_xml_log(prmdData);
        }
    }
    
    
    pugi::xml_node node_uf_status = doc.child("outArgs").child("arg-xml").child("sess_info");
    if( node_uf_status )
    {
        debug_print("sess_info");
        queue_rmd_event_notification currentNotification;
        currentNotification.iNotificationType = SCANNER_UF_STATUS;
        pugi::xml_node node_status = node_uf_status.child("status");
        debug_print("Progress :%s" , node_status.child_value());
        currentNotification.iCurrentSessInfoStatus  = atoi( node_status.child_value() );
        g_queueNotifications.push( currentNotification );    
        append_new_event_log_msg("SCANNER_UF_STATUS Status = %s",node_status.child_value());
        append_new_xml_log(prmdData);
    }
    debug_print("  end ");
}

void SampleEventListener::OnDisconnect()
{
    debug_print(" start ");
    
    debug_print( " end ");
}



std::string strBinaryDirectory ;

/* main method */
int main(int argc, char ** argv)
{
    debug_print("starting the progra main()");
    gtk_init(&argc, &argv );    
    
    g_gtk_builder = gtk_builder_new();
    
    GError * error =NULL ;
        
    // get the folder to this executable //
    std::string argv_str(argv[0]);
    std::string base_str = argv_str.substr(0,argv_str.find_last_of("/"));
    strBinaryDirectory = base_str.c_str();

    base_str = base_str +"/../gui.xml" ;
    if( ! gtk_builder_add_from_file( g_gtk_builder ,base_str.c_str(), &error ) )
    {
        debug_print( "gtk builder load error: %s", error->message );
        g_free(error);
        return(-1);
    }
    
    g_main_window = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "main_window"));
    
    initialize_widgets();
    app_initialize();
    
    gtk_widget_show(g_main_window);
    
    
    gtk_main();
    
    debug_print("end gtk_application end main()");
    return 0;
}


 static void ShowMessage(const char* message)
 {
    std::cerr << message << std::endl;
    GtkWidget* dialog = gtk_message_dialog_new (NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Error");
    gtk_message_dialog_format_secondary_text (GTK_MESSAGE_DIALOG (dialog), "%s", message);
    gtk_dialog_run(GTK_DIALOG (dialog));
    gtk_widget_destroy(GTK_WIDGET(dialog));
 }
 
static void connect_corescanner()
{
    debug_print("connect_corescanner startp");
    
    int iScannerType = SCANNER_TYPE_ALL;
    StatusID eStatus ;
    
    Open(&g_event_listener, iScannerType , &eStatus );
    if ( eStatus != STATUS_OK )
    {
        debug_print("can't connect to the corescanner. ");       
        ShowMessage("Corescanner service is not Active.");
        exit(0);
    }
   
  
    // register for all events //
    std::string inXml;
    std::ostringstream oss;
    oss << "<inArgs>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-int>6</arg-int>" << std::endl;
    oss << "        <arg-int>1,2,4,8,16,32</arg-int>" << std::endl;
    oss << "    </cmdArgs>" << std::endl;
    oss << "</inArgs>" ;
    inXml = oss.str();
  
    std::string outXml;
    ExecCommand( CMD_REGISTER_FOR_EVENTS , inXml, outXml, &eStatus); 
    
    if( eStatus != STATUS_OK ){
        debug_print("unable to register for events");
        Close(0,&eStatus);
        exit(-1);
    }
    
    debug_print("subscribe to events successful.");
    
    debug_print("connect_corescanner endp\n");
}


static void initialize_widgets()
{
    debug_print(" start function");
    
    // :TODO: initialize select_scanners combo box //
    g_tree_view_scanners = GTK_WIDGET(gtk_builder_get_object( g_gtk_builder, "tree_view_connected_scanners"));
    g_combo_box_select_scanner = GTK_WIDGET(gtk_builder_get_object( g_gtk_builder, "combo_box_selected_scanner"));
    g_status_bar_main = GTK_WIDGET ( gtk_builder_get_object( g_gtk_builder, "status_bar_main"));
    g_text_view_event_log = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder,"text_view_event_log"));
    g_text_view_xml_log = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "text_view_xml_log"));
    g_button_clear_event_log = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_clear_event_log"));
    g_text_view_barcode_data = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder,"text_view_barcode"));
    g_button_clear_xml_log = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_clear_xml_log"));
    g_entry_decode_barcode = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "entry_decode_barcode"));
    g_entry_symbology = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "entry_symbology_type"));
    g_button_clear_barcode = GTK_WIDGET(gtk_builder_get_object( g_gtk_builder, "button_clear_barcode"));
    g_button_pull_trigger = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_pull_trigger"));
    g_button_release_trigger  = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder , "button_release_trigger"));
    g_button_image_mode = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_image_mode"));
    g_button_video_mode = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_video_mode"));
    g_button_barcode_mode = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_barcode_mode"));
    g_image = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "image"));
    g_button_save_image = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_save_image"));
    set_image_empty();
    g_checkbutton_disable_scanner = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "check_box_enable_disable_scanner"));
    g_button_reboot_scanner = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_reboot_scanner"));
    g_button_get_supported_rta_events = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_get_supported_rta_events"));
    g_button_get_rta_event_status = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_get_rta_event_status"));
    
    g_button_clear_all_rta = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_clear_all_rta"));
    
    g_check_button_image_bmp = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"check_button_image_bmp"));
    g_check_button_image_jpg = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "check_button_image_jpg"));
    g_check_button_image_tiff = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"check_button_image_tiff"));
    g_check_button_enable_view_finder = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "checkbutton_enable_view_finder"));
    g_check_button_enable_keyboard_emulation =  GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "check_box_enable_emulation"));
    initialize_tree_view_scanners();
    initialize_combo_box_select_scanner();
    
    g_combo_box_led_on_off = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"combo_box_select_led" ));
    initialize_led_on_off_combo_box();
    g_button_led_on = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_led_on"));
    g_button_led_off = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_led_off"));
    g_button_pager_motor_start = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_pager_motor_start"));
    g_entry_duration = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "entry_duration"));
    g_frame_scale_tab_buttons = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "frame22"));
    g_frame_scale_tab_entries = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "frame21"));
    
    g_button_aim_on = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_aim_on"));
    g_button_aim_off =GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_aim_off"));
    g_button_beep = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_beep"));
    g_combo_box_select_beep = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"combo_box_beep"));
    initialize_combo_box_beep();
    
    g_combo_box_switch_host_variant = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "combo_box_switch_host_variant"));
    g_check_button_silent_switch_host_mode = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "checkbutton_silient_switch_host"));
    g_check_button_permanent_switch_host_mode = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "checkbutton_permanent_change")) ;
    g_button_switch_host_mode = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_switch_host_mode"));
    g_tree_view_rsm = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"tree_view_rsm"));
    initialize_tree_view_rsm();
    
    g_button_get_all_ids = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_get_all_ids"));
    g_button_next_value = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_next_value"));
    g_button_store = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"button_store"));
    g_button_get_value = GTK_WIDGET(gtk_builder_get_object(g_gtk_builder,"button_get_value"));
    g_button_set_value = GTK_WIDGET(gtk_builder_get_object(g_gtk_builder,"button_set_value"));
    g_button_select_all = GTK_WIDGET(gtk_builder_get_object(g_gtk_builder,"button_select_all"));
    g_button_clear_all = GTK_WIDGET(gtk_builder_get_object(g_gtk_builder,"button_clear_all"));
    // :TODO: connect signal :TODO: more signals to connect. //
    // button discover scanners //
    g_button_discover_scanners = GTK_WIDGET ( gtk_builder_get_object ( g_gtk_builder,"button_discover_scanners"));
    initialize_combo_box_switch_host_mode();
    
    g_text_entry_firmware = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "text_entry_firmware"));
    g_text_entry_configuration = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "text_entry_configuration"));
    g_button_firmware_browse = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_firmware_browse"));
    g_button_configuration_browse = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "button_configuration_browse"));
    g_checkbutton_firmware_bulk_update = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder,"checkbutton_bulk_update"));
    g_button_firmware_update = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_firmware_update"));
    g_button_configuration_update = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_configuration_update"));
    g_button_firmware_launch = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_firmware_launch"));
    g_button_firmware_abort = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder,"button_firmware_abort"));
    g_progressbar_firmware = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "progressbar_firmware"));
    g_progressbar_configuration = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "progressbar_configuration"));
    g_label_firmware_progress = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "label_firmware_progress") );
    g_label_configuration_progress = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "label_configuration_progress") );
    g_button_read_weight = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_read_weight"));
    g_button_zero_scale = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_zero_scale"));
    g_button_reset_scale = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "button_reset_scale"));
    g_entry_weight_measured = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "entry_weight_measured"));
    g_entry_weight_unit = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder, "entry_weight_unit"));
    g_label_scale_status = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder,"label_scale_status")); 
    g_rta_config_settings = GTK_WIDGET( gtk_builder_get_object( g_gtk_builder,"label_rta_config_settings1")); 
    g_signal_connect( G_OBJECT(g_button_discover_scanners), "clicked" , \
        G_CALLBACK(button_discover_scanners_clicked), NULL );
    
    // connect "changed" signal on combo box "select scanner"
    g_signal_connect ( G_OBJECT(g_combo_box_select_scanner), "changed", \
        G_CALLBACK(combo_box_select_scanner_changed),NULL);
    
    // connect "row-activated" signal on "scanners" tree view.
    g_signal_connect ( G_OBJECT(g_tree_view_scanners), "row-activated",\
        G_CALLBACK(tree_view_scanners_row_activated),NULL);
    
    // connect "cursor-changed" signal on "scanners" tree view//
    g_signal_connect ( G_OBJECT( g_tree_view_scanners), "cursor-changed" , \
         G_CALLBACK(tree_view_scanners_cursor_changed), NULL);
    
    // connect clear event log button  //
    g_signal_connect ( G_OBJECT( g_button_clear_event_log), "clicked" ,\
         G_CALLBACK(button_clear_event_log_clicked), NULL);
    
    // connect clear xml log button //
    g_signal_connect ( G_OBJECT( g_button_clear_xml_log) , "clicked", \
        G_CALLBACK(button_clear_xml_log_clicked), NULL);
    
    // main application close button //
    g_signal_connect ( G_OBJECT(g_main_window),"destroy",\
        G_CALLBACK(main_window_close_button_clicked),NULL);
    
    // buttons in the "Barcode" tab. //
    g_signal_connect( G_OBJECT( g_button_clear_barcode), "clicked", \
        G_CALLBACK( button_clear_barcode_clicked), NULL);
   
    g_signal_connect( G_OBJECT ( g_button_pull_trigger), "clicked",\
        G_CALLBACK( button_pull_trigger_clicked),NULL);
    
    g_signal_connect( G_OBJECT ( g_button_release_trigger) , "clicked" ,\
        G_CALLBACK( button_release_trigger_clicked),NULL  );
    
    // button video mode //
    g_signal_connect( G_OBJECT ( g_button_video_mode), "clicked",
        G_CALLBACK( button_video_mode_clicked ) , NULL);
    g_signal_connect( G_OBJECT ( g_button_image_mode), "clicked",
        G_CALLBACK( button_image_mode_clicked), NULL);
    g_signal_connect( G_OBJECT( g_button_barcode_mode), "clicked",\
        G_CALLBACK( button_barcode_mode_clicked) , NULL);
    g_signal_connect( G_OBJECT( g_checkbutton_disable_scanner) ,"toggled" ,\
        G_CALLBACK(disable_scanner_check_button_toggled), NULL);
    g_signal_connect( G_OBJECT(g_button_reboot_scanner), "clicked", \
        G_CALLBACK(button_reboot_scanner_clicked),NULL);
    g_signal_connect( G_OBJECT(g_button_get_supported_rta_events), "clicked", \
        G_CALLBACK(button_supported_rta_events_clicked),NULL);    
    g_signal_connect( G_OBJECT(g_button_get_rta_event_status), "clicked", \
        G_CALLBACK(button_get_rta_event_status_clicked),NULL);        
 
    g_signal_connect(g_button_clear_all_rta, "clicked", G_CALLBACK(button_clear_all_rta_clicked), current_store); 

    g_signal_connect(G_OBJECT(g_button_led_on), "clicked",\
        G_CALLBACK(button_led_on_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_led_off),"clicked",\
        G_CALLBACK(button_led_off_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_pager_motor_start),"clicked",\
         G_CALLBACK(button_pager_motor_start_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_aim_off),"clicked",\
        G_CALLBACK(button_aim_off_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_aim_on),"clicked",\
        G_CALLBACK(button_aim_on_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_beep), "clicked",\
        G_CALLBACK(button_beep_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_switch_host_mode), "clicked",\
        G_CALLBACK(button_switch_host_mode_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_get_all_ids), "clicked",\
         G_CALLBACK(button_get_all_ids_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_next_value), "clicked", \
         G_CALLBACK(button_next_value_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_store), "clicked",\
         G_CALLBACK(button_store_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_get_value), "clicked",\
         G_CALLBACK(button_get_value_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_set_value), "clicked",\
         G_CALLBACK(button_set_value_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_select_all), "clicked",\
         G_CALLBACK(button_select_all_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_clear_all), "clicked",\
         G_CALLBACK(button_clear_all_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_firmware_browse), "clicked" , \
        G_CALLBACK(button_firmware_browse_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_configuration_browse), "clicked" , \
        G_CALLBACK(button_configuration_browse_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_firmware_update), "clicked", \
        G_CALLBACK(button_firmware_update_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_configuration_update), "clicked", \
        G_CALLBACK(button_configuration_update_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_firmware_launch), "clicked", \
        G_CALLBACK(button_firmware_launch_clicked), NULL);
    g_signal_connect(G_OBJECT(g_button_firmware_abort), "clicked", \
        G_CALLBACK(button_firmware_abort_clicked),NULL);
    g_signal_connect(G_OBJECT(g_button_save_image), "clicked",\
        G_CALLBACK(button_save_image_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_image_bmp), "toggled", \
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_image_tiff),"toggled",\
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_image_jpg),"toggled",\
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_enable_view_finder), "toggled" ,\
        G_CALLBACK(check_button_enable_view_finder_toggled), NULL);
    g_signal_connect(G_OBJECT(g_check_button_enable_keyboard_emulation), "toggled" ,\
        G_CALLBACK(check_button_enable_keyboard_emulation_toggled), NULL);
    //buttons in Scale tab. //
    g_signal_connect( G_OBJECT ( g_button_read_weight), "clicked",
        G_CALLBACK( button_read_weight_clicked ) , NULL);
    
    g_signal_connect( G_OBJECT ( g_button_zero_scale), "clicked",
        G_CALLBACK( button_zero_scale_clicked ) , NULL);

    g_signal_connect( G_OBJECT ( g_button_reset_scale), "clicked",
        G_CALLBACK( button_reset_scale_clicked ) , NULL);

    debug_print(" end function");
}


static void initialize_tree_view_scanners()
{
    debug_print(" start function ");
    GtkListStore* list_store = gtk_list_store_new(7, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,\
                                                     G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,\
                                                     G_TYPE_STRING);
    gtk_tree_view_set_model( GTK_TREE_VIEW (g_tree_view_scanners) ,\
                             GTK_TREE_MODEL(list_store) );

    GtkCellRenderer* cell_renderer_column_1 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_2 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_3 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_4 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_5 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_6 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_7 = gtk_cell_renderer_text_new();
    
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
            -1, "#" , cell_renderer_column_1 , "text", 0,NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
            -1, "Comm Interface", cell_renderer_column_2, "text", 1, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
            -1, "Model #", cell_renderer_column_3, "text", 2, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
            -1, "Firmware", cell_renderer_column_4 , "text", 3, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
             -1, "Built",   cell_renderer_column_5, "text", 4, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
             -1, "Serial # or Port", cell_renderer_column_6 , "text",5, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_scanners),\
             -1, "GUID", cell_renderer_column_7,"text", 6, NULL);
    
   
    GtkTreeViewColumn* tree_view_column_1 = gtk_tree_view_get_column( GTK_TREE_VIEW( g_tree_view_scanners),\
            0);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_1) , true);
    
    GtkTreeViewColumn* tree_view_column_2 = gtk_tree_view_get_column( GTK_TREE_VIEW( g_tree_view_scanners),\
              1);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_2), true);
    
    GtkTreeViewColumn* tree_view_column_3 = gtk_tree_view_get_column( GTK_TREE_VIEW( g_tree_view_scanners),\
                  2);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_3), true);
    
    GtkTreeViewColumn* tree_view_column_4 =gtk_tree_view_get_column( GTK_TREE_VIEW(g_tree_view_scanners),\
        3);
    gtk_tree_view_column_set_resizable(GTK_TREE_VIEW_COLUMN(tree_view_column_4), true);

    GtkTreeViewColumn* tree_view_column_5 = gtk_tree_view_get_column( GTK_TREE_VIEW(g_tree_view_scanners),\
        4);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_5), true);

    GtkTreeViewColumn* tree_view_column_6 = gtk_tree_view_get_column( GTK_TREE_VIEW(g_tree_view_scanners),\
        5);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_6) , true);
     
    GtkTreeViewColumn* tree_view_column_7 =gtk_tree_view_get_column(GTK_TREE_VIEW(g_tree_view_scanners),\
       6);
    gtk_tree_view_column_set_resizable( GTK_TREE_VIEW_COLUMN(tree_view_column_7), true);

 
    debug_print(" end function ");
}

static void app_initialize()
{
    
    debug_print("app_initialize start function");
    connect_corescanner();
    
    // GetScannerscall //
    unsigned short count ;
    std::vector<unsigned int> list;
    std::string outXml;
    std::string inXml;
    StatusID eStatus;
    GetScanners(&count,&list,outXml,&eStatus);
    if ( eStatus != STATUS_OK )
    {
        debug_print("GetScanners call failed.");
        append_new_event_log_msg("GetScanners call failed");
        
    }else{
        append_new_event_log_msg("GetScanners call success");
        append_new_xml_log(outXml);
    }

    g_vecScanners = parseGetScannersOutXml(outXml);
    populate_tree_view_scanenrs(g_vecScanners);
    
    g_iSNAPIScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_SNAPI);
    g_iIBMTTScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_IBMTT);
    g_iIBMHIDScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_IBMHID);
    g_iHIDKBScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_HIDKB);    
    
    write_status_bar("GetScanners success");

    combo_box_select_scanner_populate(g_vecScanners);
    debug_print("app_initialize end function.");
    
    update_hidkb_emulation_setting();
    
    iCurrentlySelectedScannerId = 0;
    scanners_unselected();
    // set the poll function //
    g_timeout_add(50,GSourceFunc(update_poll_function),NULL);
   
    barcodeMapInit();
    
}

static void populate_tree_view_scanenrs(std::vector<Scanner> vecScanners){
    debug_print(" start function");
    GtkTreeModel* tree_model = gtk_tree_view_get_model(GTK_TREE_VIEW(g_tree_view_scanners));
    GtkListStore* list_store = GTK_LIST_STORE(tree_model);
   
    gtk_list_store_clear( list_store );
    
    std::vector<Scanner>::iterator itr  = vecScanners.begin();
    for (; vecScanners.end() != itr ; itr++)
    {
        Scanner currentScanner = *itr;
        
        std::string strScannerId = int2str(currentScanner.iScannerId);
        std::string strScannerType = scannerType2str(currentScanner.scannerType);
        
        GtkTreeIter gtkTreeIter;
        gtk_list_store_insert( list_store, &gtkTreeIter,1000000);
        gtk_list_store_set(list_store,&gtkTreeIter, 0,strScannerId.c_str() ,\
                                             1,strScannerType.c_str(),\
                                             2,currentScanner.strModel.c_str(),\
                                             3,currentScanner.strFirmware.c_str(),\
                                             4,currentScanner.strBuild.c_str(),\
                                             5,currentScanner.strSerialOrPort.c_str(),\
                                             6,currentScanner.strGUID.c_str(), -1);
    }
    
    gtk_tree_view_set_model( GTK_TREE_VIEW( g_tree_view_scanners), \
                                            GTK_TREE_MODEL(list_store));
    
    
    GtkTreeSelection * treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(g_tree_view_scanners));
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        // unselect if any scanner is selected 
        gtk_tree_selection_unselect_all(treeSelection);
    }else{
        // select the scanner id //
        debug_print("selecting the scanner id which is not zero");
        GValue value = {0,} ;
        GtkTreeIter treeIter;
        bool bRet =gtk_tree_model_get_iter_first(tree_model,&treeIter);
        if ( ! bRet )
            return ;
        
        bool isFoundIter = false;
        while ( !isFoundIter ){
            gtk_tree_model_get_value(tree_model,&treeIter,0,&value);
            int iCurrentId = atoi(g_value_get_string(&value));
            if ( iCurrentId == iCurrentlySelectedScannerId )
            {
                debug_print("found selected id to be selected.");
                debug_print("scanner id is :%d" , iCurrentId );
                isFoundIter = true;
            }else{
                bool bFoundNext = gtk_tree_model_iter_next( tree_model, &treeIter);
                if ( ! bFoundNext )
                {
                    debug_print(" next element on the list not found.");
                    return ;
                }
            }
            
        }
        gtk_tree_selection_select_iter(treeSelection,&treeIter);
    }
    debug_print(" end function");
}


static void button_discover_scanners_clicked(GtkWidget* button, gpointer data)
{
    debug_print(" function start ");
    
    // GetScannerscall //
    unsigned short count ;
    std::vector<unsigned int> list;
    std::string outXml;
    std::string inXml;
    StatusID eStatus;
    GetScanners(&count,&list,outXml,&eStatus);
    if ( eStatus != STATUS_OK )
    {
        debug_print("GetScanners call failed.");
        append_new_event_log_msg(("GetScanners Call failed"));
        run_modal_message_box("GetScanners Call failed", "Failure");        
    }else{
        debug_print("GetScanners call success");
        append_new_event_log_msg("GetScanners call success");
        append_new_xml_log(outXml);
        //run_modal_message_box("GetScanners call success "   ,"Success");
    }
    
    
    std::vector<Scanner> vecScanners = parseGetScannersOutXml(outXml);
    populate_tree_view_scanenrs(vecScanners);

    debug_print(" function end");
}


static void run_modal_message_box( std::string  strMessage , std::string strTitle)
{
    debug_print(" function start ");
    GtkWidget* dialogMessageBox = gtk_message_dialog_new( GTK_WINDOW( g_main_window),\
                                      GTK_DIALOG_DESTROY_WITH_PARENT,\
                                      GTK_MESSAGE_INFO,\
                                      GTK_BUTTONS_OK,\
                                      "%s" ,strMessage.c_str());
    gtk_window_set_title(GTK_WINDOW(dialogMessageBox), strTitle.c_str());
    
    gtk_window_set_modal( GTK_WINDOW( dialogMessageBox), true);
    gtk_dialog_run( GTK_DIALOG(dialogMessageBox));
    gtk_widget_destroy( dialogMessageBox );
    debug_print( "function end ");
}


static void initialize_combo_box_select_scanner(){
    debug_print(" function start ");
    g_combo_box_select_scanner = GTK_WIDGET( gtk_builder_get_object(g_gtk_builder, "combo_box_selected_scanner"));
    
    GtkListStore* list_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
    GtkCellRenderer* cell_renderer_id = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_model = gtk_cell_renderer_text_new();
    gtk_cell_layout_pack_start( GTK_CELL_LAYOUT(g_combo_box_select_scanner), cell_renderer_id, TRUE);
    gtk_cell_layout_pack_start( GTK_CELL_LAYOUT(g_combo_box_select_scanner), cell_renderer_model, TRUE);
    gtk_cell_layout_set_attributes(GTK_CELL_LAYOUT(g_combo_box_select_scanner),cell_renderer_id, "text",0,\
                                                   NULL);
    gtk_cell_layout_set_attributes(GTK_CELL_LAYOUT(g_combo_box_select_scanner), cell_renderer_model, "text",1,\
                                                   NULL);
    gtk_combo_box_set_model(GTK_COMBO_BOX(g_combo_box_select_scanner), GTK_TREE_MODEL(list_store));
    debug_print(" function end");
}

static void combo_box_select_scanner_populate(std::vector<Scanner> vecScanners)
{
    debug_print("function start");
    GtkListStore* list_store = GTK_LIST_STORE( gtk_combo_box_get_model( \
                                GTK_COMBO_BOX(g_combo_box_select_scanner)) );
    gtk_signal_disconnect_by_func(GTK_OBJECT(g_combo_box_select_scanner), G_CALLBACK(combo_box_select_scanner_changed) ,(gpointer)NULL);
    gtk_list_store_clear(list_store);
    
    debug_print("scanner list is populating");
    std::vector<Scanner>::iterator itr ;
    for ( itr = vecScanners.begin() ; itr != vecScanners.end() ; itr++)
    {
        Scanner currentScanner = *itr;
        GtkTreeIter iter;
        gtk_list_store_insert(list_store,&iter,100000);
        gtk_list_store_set(list_store,&iter, 0,currentScanner.iScannerId, 1, currentScanner.strModel.c_str(),-1);
    }
    debug_print("scanner list is populated");
    
    // connect "changed" signal on combo box "select scanner"
    g_signal_connect ( G_OBJECT(g_combo_box_select_scanner), "changed", \
        G_CALLBACK(combo_box_select_scanner_changed),(gpointer)NULL);
    
    gtk_combo_box_set_model(GTK_COMBO_BOX(g_combo_box_select_scanner),GTK_TREE_MODEL(list_store));
    
    // select the currently selected scanner id //
    //GtkTreeSelection* treeSelection = gtk_combo_box_get(g_combo_box_select_scanner);
    if ( iCurrentlySelectedScannerId == 0 ){
        //gtk_tree_selection_unselect_all(treeSelection);
        gtk_combo_box_set_active(GTK_COMBO_BOX(g_combo_box_select_scanner),-1);
    }else{
        GtkTreeIter treeIter;
        GtkTreeModel * treeModel = gtk_combo_box_get_model(GTK_COMBO_BOX(g_combo_box_select_scanner));
        bool bRet = gtk_tree_model_get_iter_first(treeModel,&treeIter);
        if( !bRet)
        {
            debug_print("list is empty");
            iCurrentlySelectedScannerId = 0;
            return;
        }
        bool isFoundIter = false;
        
        
        
        
        while( !isFoundIter ){
            GValue value = {0,};
            gtk_tree_model_get_value(treeModel,&treeIter,0,&value);
            int iScannerId = g_value_get_int(&value);
            if ( iScannerId == iCurrentlySelectedScannerId)
            {
                debug_print("found scanner id i: %d ", iScannerId );
                isFoundIter = true;
            }else{
                debug_print("not found scanner id");
                bool bFoundNext = gtk_tree_model_iter_next(treeModel,&treeIter);
                if ( ! bFoundNext )
                {
                    debug_print( " next item does not found in the list store ");
                    return;
                }
            }
        }
        gtk_combo_box_set_active_iter(GTK_COMBO_BOX(g_combo_box_select_scanner),&treeIter);
    }
    debug_print("function end");
}

static void update_scanner_list()
{
    debug_print(" function start ");
    
    // GetScannerscall //
    unsigned short count ;
    std::vector<unsigned int> list;
    std::string outXml;
    std::string inXml;
    StatusID eStatus;
    GetScanners(&count,&list,outXml,&eStatus);
    if ( eStatus != STATUS_OK )
    {
        debug_print("GetScanners call failed.");
        append_new_event_log_msg("GetScanners call failed");
    }else {
        debug_print("GetScanners call success");
        append_new_event_log_msg("GetScanners call success");
        append_new_xml_log(outXml);
    }
    
    g_vecScanners = parseGetScannersOutXml(outXml);


    g_iSNAPIScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_SNAPI);
    g_iIBMTTScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_IBMTT);
    g_iIBMHIDScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_IBMHID);
    g_iHIDKBScannerCount = get_scanner_count(g_vecScanners, SCANNER_TYPE_HIDKB);
    
    populate_tree_view_scanenrs(g_vecScanners);

    combo_box_select_scanner_populate(g_vecScanners);
    write_status_bar("GetScanners call success");
    
    // check whether currently selected scanner ID is still there. 
    std::vector<Scanner>::iterator itr ;
    bool bFound = false;
    for( itr = g_vecScanners.begin(); itr != g_vecScanners.end(); itr++)
    {
        if( ( *itr ).iScannerId == iCurrentlySelectedScannerId)
        {
            bFound = true;
            break;
        }
    }
    if (! bFound ){
        iCurrentlySelectedScannerId = 0;
        
        // If scanner detached update the progress bar UI status.
        if(NULL != g_progressbar_configuration && NULL != g_label_configuration_progress) {
            gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),0);      
            gtk_label_set_text( GTK_LABEL(g_label_configuration_progress), "");
        }
    }
    
    if ( iCurrentlySelectedScannerId != 0 )
        valid_scanner_selected();
    else
        scanners_unselected();
    
    debug_print(" function end ");  
}

static  gboolean update_poll_function(gpointer data){

    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    
    if ( g_bScheduleUpdateScannerList )
    {
        update_scanner_list();
        g_bScheduleUpdateScannerList = false;
    }
    
    if ( g_bScheduleUpdateStatusbar )
    {
        update_status_bar();
    }
    
    if ( g_bScheduleNewLogMessage ){
        update_event_log();
        g_bScheduleNewLogMessage = false;
    }
    
static bool g_bScheduleNewXmlMessageFired = false;
    if ( g_bScheduleNewXmlMessage )
    {
        update_xml_log();
        g_bScheduleNewXmlMessage = false;
        g_bScheduleNewXmlMessageFired = true;
    }    

    if ( g_bScheduleUpdateBarcode )
    {
        update_barcode_data();
        g_bScheduleUpdateBarcode = false;
    }
    
    if ( g_bScheduleUpdateImage){
        set_new_image_from_data();
        g_bScheduleUpdateImage = false;
    }
    
    if ( g_bScheduleScrollDown )
    {   
        if ( ! g_bScheduleNewXmlMessageFired )
        {
            scroll_log_text_view();
            g_bScheduleScrollDown = false;
        }else
        {
            g_bScheduleNewXmlMessageFired = false;
        }
    }
    
    if ( g_bScheduleNotification )
    {

        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        
        while( ! g_queueNotifications.empty() )
        {
            queue_rmd_event_notification currentNotification = g_queueNotifications.front();
            g_queueNotifications.pop();

            int iCurrentFirmwareDownloadProgress = 0;    
            debug_print("Update firmware notification");
            static char bufferFirmwareProgress[1024];
            switch( currentNotification.iNotificationType )
            {
                case SCANNER_UF_SESS_START:
                {
                    debug_print("received SCANNER_UF_SESS_START");
                    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
                    g_bUpdateInProgress = true ;
                    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_firmware),\
                            0);
                    iCurrentFirmwareDownloadProgress =0;
                    break;    
                }
            
                case SCANNER_UF_DL_START:
                    break ;
                case SCANNER_UF_DL_END:
                    break ; 
                case SCANNER_UF_DL_PROGRESS:
                {
                    debug_print("received SCANNER_UF_DL_PROGRESS");
                    if ( SCANNER_UF_DL_PROGRESS  ==  currentNotification.iNotificationType )
                        gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_firmware), \
                                ((double) currentNotification.iCurrentRecord) / ((double)g_iFullRecordCount));
                    iCurrentFirmwareDownloadProgress = (  currentNotification.iCurrentRecord * 100  ) /g_iFullRecordCount;
                    break ;
                }
            
                case SCANNER_UF_SESS_END:
                {
                    debug_print("received SCANNER_UF_SESS_END");
                    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_firmware),\
                          1);
                    g_bUpdateInProgress = false;
                    iCurrentFirmwareDownloadProgress = 100;
                    break;
                }
                case SCANNER_UC_SESS_START:
                {
                    debug_print("received SCANNER_UC_SESS_START");
                    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),\
                          0);
                    configuration_update_in_progress_ = true;  
                    
                    break;
                }
                case SCANNER_UC_PROGRESS:
                {
                    debug_print("received SCANNER_UC_SESS_PROGRESS");                
                    
                    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),\
                          ((double) currentNotification.iCurrentRecord) / ((double)g_iMaxCountNumberConfiguration));
                    
                    break;
                }
                case SCANNER_UC_SESS_END:
                {
                    debug_print("received SCANNER_UC_SESS_END");
                    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),1);
                    if ( (configuration_update_thread_ != NULL ) && (configuration_update_thread_->joinable() ) ) {
                        configuration_update_thread_->timed_join(boost::posix_time::seconds(2));
                        delete configuration_update_thread_;
                    } else {
                        debug_print("Error occurred while joining the configuration update thread.");
                    }
                    configuration_update_in_progress_ = false;
                    break;
                }
                case SCANNER_UF_STATUS:
                {
                    debug_print("received SCANNER_UF_STATUS"); 
                    switch ( currentNotification.iCurrentSessInfoStatus )
                    {
                        case ERROR_FW_INVALID_DATFILE:
                        case ERROR_FW_READ_FAILED_DATFILE:
                        case ERROR_FW_UPDATE_FAILED_IN_SCN:
                        case ERROR_FW_UPDATE_ABORTED:
                            gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_firmware),0);
                            sprintf(bufferFirmwareProgress , "%d%%" , 0);
                            gtk_label_set_text(GTK_LABEL(g_label_firmware_progress ), bufferFirmwareProgress);
                            g_bUpdateInProgress = false;
                            g_iCurrentRecord = 0;
                            iCurrentFirmwareDownloadProgress = 0;
                            write_scanner_status_to_status_bar(currentNotification.iCurrentSessInfoStatus);
                            break;
                        case ERROR_FW_SCN_DETTACHED:
                            // Scanner detached during FW Update do this
                            if(g_bUpdateInProgress) {
                                gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_firmware),0);
                                sprintf(bufferFirmwareProgress , "%d%%" , 0);
                                gtk_label_set_text(GTK_LABEL(g_label_firmware_progress ), bufferFirmwareProgress);
                                g_bUpdateInProgress = false;
                                g_iCurrentRecord = 0;
                                iCurrentFirmwareDownloadProgress = 0;
                                write_scanner_status_to_status_bar(currentNotification.iCurrentSessInfoStatus);
                            }
                            // Scanner detached during Configuration Update do this
                            if (configuration_update_in_progress_) {
                                gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),0);      
                                gtk_label_set_text( GTK_LABEL(g_label_configuration_progress), "");
                                configuration_update_in_progress_ = false;
                                if ( (configuration_update_thread_ != NULL ) && (configuration_update_thread_->joinable() ) ) {
                                    configuration_update_thread_->join();
                                    delete configuration_update_thread_;
                                } else {
                                    debug_print("Error occurred while joining the configuration update thread.");
                                }
                            }
                            break;
                        case STATUS_ERROR_INVALID_CONFIG_FILE:
                        case STATUS_ERROR_INCOMPATIBLE_CONFIG_FILE:
                        case STATUS_ERROR_CONFIG_FILE_SYNTAX_VALIDATION_FAILED:
                            gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),0);      
                            gtk_label_set_text( GTK_LABEL(g_label_configuration_progress), "");
                            configuration_update_in_progress_ = false;
                            if ( (configuration_update_thread_ != NULL ) && (configuration_update_thread_->joinable() ) ) {
                                configuration_update_thread_->join();
                                delete configuration_update_thread_;
                            } else {
                                debug_print("Error occurred while joining the configuration update thread.");
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                }
                default:
                    break ;
            }

            if ( g_bUpdateInProgress) {
                if ( SCANNER_UF_DL_PROGRESS == currentNotification.iNotificationType || \
                     SCANNER_UF_SESS_START == currentNotification.iNotificationType     )
                {
                    sprintf(bufferFirmwareProgress, "%d%%" , iCurrentFirmwareDownloadProgress);
                    gtk_label_set_text( GTK_LABEL( g_label_firmware_progress ) , bufferFirmwareProgress);
                }
                g_bScheduleNotification = false;
            }else{
                if ( iCurrentFirmwareDownloadProgress == 100) {   
                    sprintf(bufferFirmwareProgress, "Done!");
                    gtk_label_set_text( GTK_LABEL( g_label_firmware_progress ), bufferFirmwareProgress);
                    g_bScheduleNotification = false;
                }
                g_bScheduleNotification = false;
            }
            
            if (configuration_update_in_progress_) {                                
                if ( SCANNER_UC_PROGRESS == currentNotification.iNotificationType )
                {    
                    std::string progress_string;
                    std::ostringstream string_stream_int_to_string;                    
                    int progress =((currentNotification.iCurrentRecord)*100) / (g_iMaxCountNumberConfiguration);
                    string_stream_int_to_string.clear(); 
                    string_stream_int_to_string.str("");                   
                    string_stream_int_to_string << progress;
                    progress_string = string_stream_int_to_string.str();
                    progress_string=progress_string+"%";
                    
                    static char buffer_configuration_progress[1024];                  
                     
                    if (progress == 100) {
                        sprintf(buffer_configuration_progress, "Done!");
                    } else {
                        sprintf(buffer_configuration_progress, "%d%%" , progress);
                    }
                    gtk_label_set_text( GTK_LABEL( g_label_configuration_progress ) , buffer_configuration_progress);
                }
            }
        }
    }
      
    return true;
}

/**
 * Method to display relevant error message during the update firmware,
 * in the sample program
 */
void write_scanner_status_to_status_bar(int errorId) {
    switch(errorId) {
        case ERROR_FW_INVALID_DATFILE:
            write_status_bar("ERROR : FIRMWARE INVALID DAT FILE");
            break;
        case ERROR_FW_READ_FAILED_DATFILE:
            write_status_bar("ERROR : FIRMWARE DAT FILE READ FAILED");
            break;
        case ERROR_FW_UPDATE_FAILED_IN_SCN:
            write_status_bar("ERROR : FIRMWARE UPDATE FAILED IN SCANNER");
            break;
        case ERROR_FW_UPDATE_ABORTED:
            write_status_bar("ERROR : FIRMWARE UPDATE ABORTED");
            break;
        case ERROR_FW_SCN_DETTACHED:
            write_status_bar("ERROR : SCANNER DETTACHED");            
            break;
        case STATUS_ERROR_INVALID_CONFIG_FILE:
            write_status_bar("ERROR : INVALID CONFIGURATION FILE");            
            break;
        case STATUS_ERROR_INCOMPATIBLE_CONFIG_FILE:
            write_status_bar("ERROR :INCOMPATIBLE CONFIGURATION FILE");            
            break;
        case STATUS_ERROR_CONFIG_FILE_SYNTAX_VALIDATION_FAILED:
            write_status_bar("ERROR :CONFIGURATION FILE SYNTAX IS INVALID");            
            break;
        default:
            write_status_bar("ERROR");
            break;
    }
}

void combo_box_select_scanner_changed( GtkComboBox* widget,gpointer user_data){
    debug_print(" function start ");
    debug_print("iCurrentlySelectedScannerId :%d", iCurrentlySelectedScannerId);
    gtk_combo_box_get_active(GTK_COMBO_BOX(widget));
    GtkTreeIter iter;
    GtkTreeModel * treeModel = gtk_combo_box_get_model(GTK_COMBO_BOX(widget));
    GValue value = {0,};
    bool bRet = gtk_combo_box_get_active_iter(GTK_COMBO_BOX(widget),&iter);
    if ( ! bRet )
    {
        GtkTreeIter iter;
        GtkTreeModel* treeModel= gtk_combo_box_get_model( widget);
        bool bRet = gtk_tree_model_get_iter_first(treeModel , &iter);
        if ( ! bRet )
        {
            debug_print("list is empty");
            iCurrentlySelectedScannerId =0;
        }
    }
    
    int iSelectedScannerid ;
    if ( bRet ){
        gtk_tree_model_get_value(treeModel,&iter, 0, &value);
        iSelectedScannerid = g_value_get_int(&value);
        if ( iCurrentlySelectedScannerId == iSelectedScannerid){
            debug_print(" nothing to do ");
            return ; // nothing to do //   
        }
        iCurrentlySelectedScannerId = iSelectedScannerid;
    }
    
    // schedule a update scanner call //
    {
        boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex);
        g_bScheduleUpdateScannerList = true;
    }
    update_status_check_button_enable_view_finder();    
    debug_print(" function end ");
}

void tree_view_scanners_row_activated( GtkTreeView * tree_view, GtkTreePath *path, \
                                        GtkTreeViewColumn * column, gpointer user_data)
{
    
    debug_print(" function start ");

    GtkTreeModel* treeModel = gtk_tree_view_get_model(tree_view);
    GtkTreeIter treeIter ;
    bool bRet = gtk_tree_model_get_iter(treeModel,&treeIter, path);
    if (!  bRet ){
        iCurrentlySelectedScannerId = 0;
    }else{
        GValue value = {0,};
        gtk_tree_model_get_value(treeModel,&treeIter, 0,&value);
        int iNewScannerId = atoi(g_value_get_string(&value));
        debug_print("new scanner id:%d ", iNewScannerId );
        if ( iNewScannerId == iCurrentlySelectedScannerId)
            return; // nothing to do //
    
        iCurrentlySelectedScannerId  = iNewScannerId;
    }
    // schedule a update scanner call //
    {
        boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex);
        g_bScheduleUpdateScannerList = true;
    }    
    
    debug_print(" function end ");
}

static char buffer_status_bar [1024];
static void update_status_bar()
{
   debug_print("function start");
    boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex );
    if ( g_bScheduleUpdateStatusbar )
    {
        std::vector<std::string>::iterator itr ;
        std::string strLastMessage ="" ;
        
        if( g_vecStringStatusBarMessages.size() > 0 )
        {
            itr = g_vecStringStatusBarMessages.end() -1;
            strLastMessage = *itr;
        }
        
        
        sprintf( buffer_status_bar ,"%s\t :SNAPI:%d\t IBMHID:%d\t IBMTT:%d\t HIDKB:%d\t ",\
                strLastMessage.c_str(),    \
                g_iSNAPIScannerCount ,     \
                g_iIBMHIDScannerCount ,    \
                g_iIBMTTScannerCount ,     \
                g_iHIDKBScannerCount);
        
        gtk_statusbar_push(GTK_STATUSBAR(g_status_bar_main),0,(gchar*)buffer_status_bar);
        g_bScheduleUpdateStatusbar = false; 
    }
    debug_print("function end");
}

static void write_status_bar(std::string strMessage)
{
    debug_print("function start");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    g_bScheduleUpdateStatusbar = true ;
    g_vecStringStatusBarMessages.push_back(strMessage);
    debug_print("function end");
}


static int  g_iEventLogCount;
char bufferEventLogMsg [ 1024 ];


static void append_new_event_log_msg(const char *fmt,...){
    debug_print("function start append_new_event_log_msg");
    
    char buffer[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);
    
    boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex);
    sprintf(bufferEventLogMsg, "%d:%s" , ++g_iEventLogCount , buffer);
    g_vecStringNewLogMsg.push_back(bufferEventLogMsg);
    g_bScheduleNewLogMessage = true;
    debug_print("function end append_new_event_log_msg");
}

char bufferXmlLogMsg[1024*1024] ; // Maximum 1Meg of xml data//
static void append_new_xml_log(std::string strMessage){
    debug_print("function start");
    boost::unique_lock<boost::recursive_mutex> lock( g_access_mutex );
    
    // format it //
    strMessage = format_xml(strMessage);
    
    sprintf(bufferXmlLogMsg,"%d:\n%s", g_iEventLogCount,strMessage.c_str());
    g_vecStringNewXmlMsg.push_back( bufferXmlLogMsg);
    g_bScheduleNewXmlMessage=true;
    debug_print("function end");
}

static void update_event_log()
{
    debug_print("function start");
    GtkTextBuffer * textBuffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(g_text_view_event_log));

    std::vector<std::string>::iterator itr = g_vecStringNewLogMsg.begin();
    for ( ; itr != g_vecStringNewLogMsg.end() ; itr++ ){
        std::string strCurrentLogMsg = *itr;
        strCurrentLogMsg.append("\n");        
        GtkTextIter textIter;
        gtk_text_buffer_get_end_iter(textBuffer, &textIter);
        int iLength = strlen( strCurrentLogMsg.c_str());
        gtk_text_buffer_insert(textBuffer,&textIter, strCurrentLogMsg.c_str(),iLength);
    }
    
    g_vecStringNewLogMsg.clear();
    
    GtkTextIter textIter;
    gtk_text_buffer_get_end_iter(textBuffer, &textIter);
    gtk_text_view_scroll_to_iter( GTK_TEXT_VIEW(g_text_view_event_log),&textIter,0.0,false, 0,0);
    
    {
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        g_bScheduleScrollDown = true;
    }
    
    debug_print("function end");
}



static void update_xml_log()
{
    debug_print("function start");
    GtkTextBuffer* textBuffer = gtk_text_view_get_buffer( GTK_TEXT_VIEW(g_text_view_xml_log));
    
    if ( g_vecStringNewXmlMsg.size() == 0)
        return; 
    
    
    std::vector<std::string>::iterator itr = g_vecStringNewXmlMsg.begin();
    for ( ; itr != g_vecStringNewXmlMsg.end() ; itr++){
        
        std::string strCurrentLogMsg = *itr;
        strCurrentLogMsg.append("\n");
        GtkTextIter textIter;
        gtk_text_buffer_get_end_iter( textBuffer, &textIter  );
        int iLength = strlen( strCurrentLogMsg.c_str());
        gtk_text_buffer_insert( textBuffer, &textIter, strCurrentLogMsg.c_str(), iLength);   
    }
    g_vecStringNewXmlMsg.clear();
    gtk_widget_queue_draw(g_text_view_xml_log);
    g_bScheduleScrollDown = true;           
    debug_print("function end");
}


static void button_clear_event_log_clicked(GtkWidget* button, gpointer data)
{
    debug_print("function start");
    GtkTextBuffer* textViewTextBuffer = gtk_text_view_get_buffer( GTK_TEXT_VIEW(\
            g_text_view_event_log));
    GtkTextIter iterStart, iterEnd;
    gtk_text_buffer_get_start_iter( textViewTextBuffer, &iterStart);
    gtk_text_buffer_get_end_iter( textViewTextBuffer, &iterEnd);
    gtk_text_buffer_delete( textViewTextBuffer,&iterStart, &iterEnd );
    write_status_bar("event log cleared");       
    debug_print("function end");
}
static void button_clear_xml_log_clicked(GtkWidget* button, gpointer data)
{
    debug_print("function start");
    GtkTextBuffer* textViewTextBuffer = gtk_text_view_get_buffer( GTK_TEXT_VIEW(\
            g_text_view_xml_log));
    GtkTextIter iterStart, iterEnd;
    gtk_text_buffer_get_start_iter( textViewTextBuffer, &iterStart);
    gtk_text_buffer_get_end_iter(textViewTextBuffer, &iterEnd);
    gtk_text_buffer_delete( textViewTextBuffer,&iterStart,&iterEnd);
    write_status_bar("xml log cleared");
    debug_print("function end");
}

static void main_window_close_button_clicked()
{
    debug_print("function start");
    // deinit application //
    app_deinitialize();
    
    gtk_main_quit();
    debug_print("function end");
}

static void app_deinitialize()
{
    debug_print("function start");
    
    // close the connectipn to the corescanner //
    StatusID eStatus ;
    
    Close(0,&eStatus);
    if ( eStatus != STATUS_OK )
    {
        debug_print("Close function failed");
        write_status_bar("Close failed");
        append_new_event_log_msg("Close failed");
    }
    else{
        debug_print("Close call success.");
        write_status_bar("Close success");
        append_new_event_log_msg("Close success");
    }
    
    debug_print("function end");
}


static char buffer_barcode_text_view[1024*256] ; // hope we don't have barcodes larger than 256KB
static void update_barcode_data()
{
    debug_print("function start");
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    
    GtkTextBuffer* textBuffer = gtk_text_view_get_buffer( GTK_TEXT_VIEW(g_text_view_barcode_data));
    
    
    GtkTextIter iterStart;
    GtkTextIter iterEnd;
    
    // clear the buffer first //
    gtk_text_buffer_get_start_iter(textBuffer,&iterStart);
    gtk_text_buffer_get_end_iter(textBuffer,&iterEnd);
    gtk_text_buffer_delete( textBuffer,&iterStart,&iterEnd );

    // set the buffer //
    
    std::string strFormattedOutXml = format_xml(g_strBarcodeOutXml);

    
    sprintf( buffer_barcode_text_view,"%s",strFormattedOutXml.c_str() );
    int iLength  = strlen( buffer_barcode_text_view);
    gtk_text_buffer_insert(textBuffer, &iterStart, buffer_barcode_text_view, iLength);
    
    std::string strDecodeData = get_decode_data(g_strBarcodeOutXml);
    debug_print("Decode data: %s" , strDecodeData.c_str());
    
    int iSymbologyType = get_symbology_type(g_strBarcodeOutXml);
    debug_print("Symbology type: %d ", iSymbologyType);
    
    // std::string strSymboogy = symbologyTypeToStr(i)
    int iScannerId = getScannerIdFromBarcodeData(g_strBarcodeOutXml);
    ScannerType scannerType =  getScaannerTypeFromId(g_vecScanners,iScannerId);
    
    std::string strSymbology = symbologyTypeToStr(iSymbologyType,scannerType);
    
    gtk_entry_set_text(GTK_ENTRY(g_entry_symbology), strSymbology.c_str());
    
    gtk_entry_set_text(GTK_ENTRY(g_entry_decode_barcode), strDecodeData.c_str());
    
    debug_print("function end");
    
}

static void tree_view_scanners_cursor_changed( GtkTreeView* tree_view, \
        GtkTreePath *path, GtkTreeViewColumn* column ,\
        gpointer user_data)
{
    debug_print("function start");
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(\
            g_tree_view_scanners));
    GtkTreeIter iter;
    
    GtkTreeModel* treeModel ;
    gtk_tree_selection_get_selected(treeSelection,&treeModel  ,&iter);
    
    
    GtkTreePath* selected_path = gtk_tree_model_get_path(treeModel,&iter);
    GtkTreeViewColumn* selectedColumn = gtk_tree_view_get_column(GTK_TREE_VIEW(g_tree_view_scanners),\
                                            0);
    
    gtk_tree_view_row_activated(GTK_TREE_VIEW(g_tree_view_scanners),selected_path,selectedColumn);
    
    debug_print("function end");
    
}

static void button_clear_barcode_clicked(GtkWidget* widget, gpointer data)
{
    debug_print("function start");
    // clear entry decode barcode //
    gtk_entry_set_text(GTK_ENTRY(g_entry_decode_barcode), "");
    
    
    // claer barcode text view //
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(g_text_view_barcode_data));
    gtk_text_buffer_set_text(buffer, "", strlen(""));
    
    // clear entry symbol type //
    gtk_entry_set_text(GTK_ENTRY(g_entry_symbology),"");
    
    debug_print("function end");
}


static void valid_scanner_selected( )
{
    debug_print("function start");
    gtk_widget_set_sensitive(g_checkbutton_disable_scanner,true);
    gtk_widget_set_sensitive(g_button_reboot_scanner,true);
    gtk_widget_set_sensitive(g_button_pager_motor_start,true);
    
    // only enable when there is an SNAPI scanner //
    ScannerType scannerType = getScaannerTypeFromId(g_vecScanners,iCurrentlySelectedScannerId);
    bool bIsSnapiScanner = (  scannerType == SCANNER_TYPE_SNAPI)? true: false;
    gtk_widget_set_sensitive(g_button_pull_trigger,bIsSnapiScanner);
    gtk_widget_set_sensitive(g_button_release_trigger, bIsSnapiScanner);
    gtk_widget_set_sensitive(g_button_image_mode , bIsSnapiScanner);
    gtk_widget_set_sensitive(g_button_video_mode , bIsSnapiScanner);
    gtk_widget_set_sensitive(g_button_barcode_mode, bIsSnapiScanner);

    //enable when a scanner is selected //
    bool Scanner = (iCurrentlySelectedScannerId>0)? true: false;
    gtk_widget_set_sensitive(g_button_read_weight , Scanner);
    gtk_widget_set_sensitive(g_button_zero_scale , Scanner);
    gtk_widget_set_sensitive(g_button_reset_scale ,Scanner);

    // Determines whether the selected device is a scale measuring device or not. //
    std::string strInXml;
    std::string strOutXml;
    std::ostringstream oss;
    StatusID eStatus;
    std::string arr_node_value[2];

    oss << "<inArgs>"<< std::endl;
    oss << "    <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-xml>" << std::endl;
    oss << "            <attrib_list>965,1197</attrib_list>" << std::endl;
    oss << "        </arg-xml>" << std::endl;
    oss << "     </cmdArgs>" << std::endl;
    oss << "</inArgs>"<< std::endl;

    strInXml = oss.str();

    ExecCommand (CMD_RSM_ATTR_GET , strInXml , strOutXml , &eStatus);

    pugi::xml_document doc ;
    pugi::xml_parse_result result = doc.load(strOutXml.c_str());

    if ( result.status != pugi::status_ok)
    {
        debug_print("Can't parse outXml from CMD_RSM_ATTR_GET.");
        return ;
    }
    
    if (doc.child("outArgs").child("arg-xml").child("response").child("attrib_list").child("attribute").child("id"))
    {
        pugi::xml_node node_attrib_list = doc.child("outArgs").child("arg-xml").child("response").child("attrib_list");
        pugi::xml_node node_attribute;
        int element = 0;
         for( node_attribute = node_attrib_list.first_child(); node_attribute; node_attribute = node_attribute.next_sibling() )
         {       
            pugi::xml_node node_value = node_attribute.child("value");
            std::string str_node_value = node_value.child_value();

            arr_node_value[element] = str_node_value;
            element++;       
         }

         if (arr_node_value[0] == "1" && arr_node_value[1] == "1")
         {
            gtk_widget_set_sensitive(g_frame_scale_tab_buttons, true);
            gtk_widget_set_sensitive(g_frame_scale_tab_entries, true);
         }
         else
         {
            gtk_widget_set_sensitive(g_frame_scale_tab_buttons, false);
            gtk_widget_set_sensitive(g_frame_scale_tab_entries, false);
         }

    }
    else
    {
        gtk_widget_set_sensitive(g_frame_scale_tab_buttons, false);
        gtk_widget_set_sensitive(g_frame_scale_tab_entries, false);
    }
   
    debug_print("function end");
}

static void scanners_unselected()
{
    debug_print("function start");
    gtk_widget_set_sensitive(g_checkbutton_disable_scanner,false);
    gtk_widget_set_sensitive(g_button_reboot_scanner, false);
    gtk_widget_set_sensitive(g_button_pager_motor_start,false);
    gtk_widget_set_sensitive (g_button_pull_trigger, false);
    gtk_widget_set_sensitive (g_button_release_trigger,false);    
    gtk_widget_set_sensitive ( g_button_image_mode, false);
    gtk_widget_set_sensitive ( g_button_video_mode, false);
    gtk_widget_set_sensitive ( g_button_barcode_mode, false);
    gtk_widget_set_sensitive ( g_button_read_weight, false);
    gtk_widget_set_sensitive ( g_button_zero_scale, false);
    gtk_widget_set_sensitive ( g_button_reset_scale, false);

    gtk_entry_set_text(GTK_ENTRY(g_entry_duration), str_default_value.c_str());
    
    debug_print("function end");
}

static void button_release_trigger_clicked(GtkWidget* widget, gpointer data)
{
    debug_print("function start");
    std::string inXml;
    std::string outXml;
    std::ostringstream oss;
    
    StatusID eStatus ;
    oss << "<inArgs>" << std::endl;
    oss << "   <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "</inArgs>" << std::endl;
    inXml=oss.str();
    
    ExecCommand( CMD_DEVICE_RELEASE_TRIGGER, inXml,outXml, &eStatus);
    if ( eStatus != STATUS_OK)
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_RELEASE_TRIGGER failed: %d", eStatus);
        append_new_event_log_msg("Command CMD_DEVICE_RELEASE_TRIGGER failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Release Trigger failed: " + status_message);
        
    }else{
        debug_print("CMD_DEVICE_RELEASE_TRIGGER success");
        append_new_event_log_msg("Command CMD_DEVICE_RELEASE_TRIGGER success");
        // append_new_xml_log(outXml);
        write_status_bar("Command Release Trigger success");
    }
    
    debug_print("function end");
}


static void button_pull_trigger_clicked(GtkWidget* widget,gpointer data)
{
    debug_print("function start");
    std::string inXml;
    std::string outXml;
    std::ostringstream oss;
    
    StatusID eStatus ;
    oss << "<inArgs>" << std::endl;
    oss << "   <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "</inArgs>" << std::endl;
    inXml = oss.str();
    ExecCommand( CMD_DEVICE_PULL_TRIGGER, inXml,outXml, &eStatus);
    if ( eStatus != STATUS_OK)
    {        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_PULL_TRIGGER failed: %d", eStatus);
        append_new_event_log_msg("Command CMD_DEVICE_PULL_TRIGGER failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Pull Trigger failed: " + status_message);
    }else{
        debug_print("CMD_DEVICE_PULL_TRIGGER success");
        append_new_event_log_msg("Command Pull Trigger success");
        //append_new_xml_log(outXml);
        write_status_bar("Command Pull Trigger success");
    }    
    
    debug_print("function end");
}

static void button_video_mode_clicked(GtkWidget* , gpointer)
{
    std::string inXml ;
    std::string outXml ;
    StatusID eStatus ;
    
    if( iCurrentlySelectedScannerId == 0){
        debug_print("can't come here.Something is wrong");
        return ;
    }
    
    std::ostringstream oss;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<<iCurrentlySelectedScannerId<< "</scannerID>";
    oss << "</inArgs>";
    
    inXml = oss.str();
    
    ExecCommand(CMD_DEVICE_CAPTURE_VIDEO,inXml,outXml, &eStatus);
    if ( eStatus != STATUS_OK )
    {        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_CAPTURE_VIDEO failed: %d", eStatus);
        append_new_event_log_msg("Command CMD_DEVICE_CAPTURE_VIDEO failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Capture Video failed: " + status_message);
        
    }else {
        debug_print("Command success.");
        append_new_event_log_msg("Command Capture Video success");
        write_status_bar("Command Capture Video success");
    }
    debug_print("function end");
}


static void button_image_mode_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    std::string inXml ;
    std::string outXml ;
    StatusID eStatus ;
    
    if( iCurrentlySelectedScannerId == 0){
        debug_print("can't come here.Something is wrong");
        return ;
    }
    
    std::ostringstream oss ;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<<iCurrentlySelectedScannerId<< "</scannerID>";
    oss << "</inArgs>";
    
    inXml = oss.str();
    
    ExecCommand(CMD_DEVICE_CAPTURE_IMAGE,inXml,outXml, &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_CAPTURE_IMAGE failed: %d", eStatus);
        append_new_event_log_msg("Command Capture Image failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Capture Image failed: " + status_message);
        
    }else {
        debug_print("Command success.");
        append_new_event_log_msg("Command Capture Image success");
        write_status_bar("Command Capture Image success");
    }
    
    debug_print("function end');");
}

static void button_barcode_mode_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    std::string inXml ;
    std::string outXml ;
    StatusID eStatus ;
    
    if( iCurrentlySelectedScannerId == 0){
        debug_print("can't come here.Something is wrong");
        return ;
    }
    
    std::ostringstream oss ;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<<iCurrentlySelectedScannerId<< "</scannerID>";
    oss << "</inArgs>";
    
    inXml = oss.str();
    
    ExecCommand(CMD_DEVICE_CAPTURE_BARCODE,inXml,outXml, &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_CAPTURE_BARCODE failed: %d", eStatus);
        append_new_event_log_msg("Command Capture Barcode failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Capture Barcode failed: " + status_message);
        
    }else {
        debug_print("Command success.");
        append_new_event_log_msg("Command Capture Barcode success");
        write_status_bar("Command Capture Barcode success");
    }
    debug_print("function end");
}

static void set_image_empty(){
    debug_print("function start");
    std::string path = strBinaryDirectory +"/../images/empty.png";
    gtk_image_set_from_file(GTK_IMAGE(g_image),path.c_str());
    debug_print("function end");
}

GdkPixbuf* pixbuf;
GdkPixbuf* scalled_pix_buf;
GdkPixbufLoader* loader;
static void set_new_image_from_data()
{
    debug_print("function start");
     
    GError *error = NULL ;

    
    if ( loader != NULL ){
        
        g_object_unref(G_OBJECT(pixbuf));
        g_object_unref(G_OBJECT(scalled_pix_buf));
    }
    
    if ( g_isImageJpeg )
    {
        loader=gdk_pixbuf_loader_new_with_type("jpeg",&error);
    }else if ( g_isImageTiff){
        loader=gdk_pixbuf_loader_new_with_type("tiff",&error);
    }
    else{
        loader=gdk_pixbuf_loader_new();
    }
    
    if ( loader == NULL )
        std::cout << " can't create valid gdk pixbuf " << std::endl;

    gboolean ret = gdk_pixbuf_loader_write(loader,(guchar*) g_ImageVideoData, g_iImageSize , &error);
    if (!  ret )
    {
        debug_print("Error reading the image.");
        return ;
    }
    gdk_pixbuf_loader_close(loader,&error);
            
    pixbuf = gdk_pixbuf_loader_get_pixbuf(loader);
    
    gint iWidth,iHeight; 
    
    gtk_widget_get_size_request(g_image,&iWidth,&iHeight);
    
    int iScalledHeight , iScalledWidth;
    int iActualHeight , iActualWidth;
    iActualHeight = gdk_pixbuf_get_height(pixbuf);
    iActualWidth = gdk_pixbuf_get_width(pixbuf);
    
    double iScallingFactorFitIntoWidth =(double)iWidth / (double)iActualWidth;
    double iScallingFactorFitIntoHeight = (double)iHeight / (double)iActualHeight;
    
    if ( iScallingFactorFitIntoWidth > iScallingFactorFitIntoHeight )
    {
        debug_print("scaling image for fit into width");
        iScalledHeight = iScallingFactorFitIntoWidth * iActualHeight ;
        iScalledWidth = iWidth;
        
    }else{
        debug_print("scalling image for fit into height.");
        iScalledWidth = iScallingFactorFitIntoHeight * iActualWidth;
        iScalledHeight = iHeight;
    }
    
    scalled_pix_buf = gdk_pixbuf_scale_simple(pixbuf,iScalledWidth,iScalledHeight,GDK_INTERP_NEAREST);
    
    gtk_image_set_from_pixbuf(GTK_IMAGE(g_image),scalled_pix_buf);
    
    
    debug_print("function end");
}

static void scroll_log_text_view()
{
    debug_print("function start");
    GtkTextBuffer * event_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(g_text_view_event_log));
    GtkTextBuffer * xml_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(g_text_view_xml_log));
    GtkTextIter iterEndEventBuffer;
    GtkTextIter iterEndXmlBuffer;
    gtk_text_buffer_get_end_iter(event_buffer,&iterEndEventBuffer);
    gtk_text_buffer_get_end_iter(xml_buffer,&iterEndXmlBuffer);
    gtk_text_view_scroll_to_iter( GTK_TEXT_VIEW(g_text_view_event_log),&iterEndEventBuffer,0.0,false, 0,0);
    gtk_text_view_scroll_to_iter( GTK_TEXT_VIEW(g_text_view_xml_log),&iterEndXmlBuffer,0.0 , false, 0,0);
    debug_print("function end");
}

static void disable_scanner_check_button_toggled(GtkToggleButton* togglebutton,
        gpointer user_data)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("Please select a valid scanner.");
        return ;
    }
    StatusID eStatus;
    std::string inXml,outXml;
    std::ostringstream oss ;
    
    oss << "<inArgs>" ;
    oss <<     "<scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>";
    oss << "</inArgs>";
    
    inXml = oss.str();
    
    int iCommand ;
    bool bEnable = gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(g_checkbutton_disable_scanner));
    if ( bEnable){
        iCommand = CMD_DEVICE_SCAN_DISABLE;
        debug_print("device disabling");
    }else{
        debug_print("device enabling");
        iCommand = CMD_DEVICE_SCAN_ENABLE;
    }
    
    ExecCommand( iCommand, inXml ,outXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command SCAN ENABLE/DISABLE failed: %d", eStatus);
        append_new_event_log_msg("Command Scan Enable/Disable failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Scan Enable/Disable failed: " + status_message);
        
        return ;
    }
    
    write_status_bar("Command Scan Enable/Disable success.");
    append_new_event_log_msg("Command Scan Enable/Disable success");
    debug_print("function end");
}
static void button_reboot_scanner_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");

    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("never reach here.");
        return ;
    }
    
    StatusID eStatus ;
    std::string inXml;
    std::string outXml;
    
    std::ostringstream oss ;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>";
    oss << "</inArgs>";
    inXml = oss.str();
    
    ExecCommand(CMD_REBOOT_SCANNER,inXml ,outXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_REBOOT_SCANNER failed: %d", eStatus);
        append_new_event_log_msg("Command Reboot Scanner failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Reboot Scanner failed: " + status_message);
        
        return;
    }
    
    write_status_bar("Command Reboot Scanner success.");
    append_new_event_log_msg("Command Reboot Scanner success.")  ;  
    debug_print("function end");
}


std::vector<RTAEvent> parseXMLForRTAEventConfiguration(const std::string &xmlContent) {
    std::vector<RTAEvent> events;

    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_string(xmlContent.c_str());

    if (!result) {
        std::cerr << "XML parsing failed: " << result.description() << std::endl;
        return events;
    }

    pugi::xml_node rtaeventList = doc.child("outArgs").child("arg-xml").child("response").child("rtaevent_list");
    for (pugi::xml_node rtaevent = rtaeventList.child("rtaevent"); rtaevent; rtaevent = rtaevent.next_sibling("rtaevent")) {
        RTAEvent event;
        event.id = rtaevent.child("id").text().as_string();
        event.stat = rtaevent.child("stat").text().as_string();
        event.onlimit = rtaevent.child("onlimit").text().as_string();
        event.offlimit = rtaevent.child("offlimit").text().as_string();
        events.push_back(event);
    }

    return events;
}

std::vector<RTAEventStatus> parseXMLForRTAEventStatus(const std::string &xmlString) {
    std::vector<RTAEventStatus> events;

    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_string(xmlString.c_str());
    if (!result) {
        std::cerr << "Failed to parse XML: " << result.description() << std::endl;
        return events;
    }

    pugi::xml_node rtaevent_list = doc.child("outArgs").child("arg-xml").child("response").child("rtaevent_list");
    if (!rtaevent_list) {
        std::cerr << "Missing <rtaevent_list> node in XML." << std::endl;
        return events;
    }

    for (pugi::xml_node rtaevent = rtaevent_list.child("rtaevent"); rtaevent; rtaevent = rtaevent.next_sibling("rtaevent")) {
        RTAEventStatus event;

      
        event.id = rtaevent.child("id").text().as_int();
        event.stat = rtaevent.child("stat").text().as_int();
        event.scope = rtaevent.child("scope").text().as_int();
        event.registered = rtaevent.child("registered").text().as_bool();
        event.reported = rtaevent.child("reported").text().as_bool();
        event.initialized = rtaevent.child("initialized").text().as_bool();
        event.measuring = rtaevent.child("measuring").text().as_bool();

        events.push_back(event);
    }

    return events;
}
GtkWidget* createTreeViewForRTAEventStatus(const std::vector<RTAEventStatus> &events) {
   
    GtkListStore *store = gtk_list_store_new(8,
                                             G_TYPE_INT,     // No
                                             G_TYPE_INT,     // Event ID
                                             G_TYPE_INT,     // Stat
                                             G_TYPE_INT,     // Scope
                                             G_TYPE_BOOLEAN, // Registered
                                             G_TYPE_BOOLEAN, // Reported
                                             G_TYPE_BOOLEAN, // Initialized
                                             G_TYPE_BOOLEAN  // Measuring
    );
 
    for (size_t i = 0; i < events.size(); ++i) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, static_cast<int>(i + 1),   // No
                           1, events[i].id,             // Event ID
                           2, events[i].stat,           // Stat
                           3, events[i].scope,          // Scope
                           4, events[i].registered,     // Registered
                           5, events[i].reported,       // Reported
                           6, events[i].initialized,    // Initialized
                           7, events[i].measuring,      // Measuring
                           -1);
    }
 
 
    GtkWidget *treeView = gtk_tree_view_new_with_model(GTK_TREE_MODEL(store));
    g_object_unref(store);
 
 
    GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
    GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes("No", renderer, "text", 0, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Event ID", renderer, "text", 1, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Stat", renderer, "text", 2, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Scope", renderer, "text", 3, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_toggle_new();
    column = gtk_tree_view_column_new_with_attributes("Registered", renderer, "active", 4, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_toggle_new();
    column = gtk_tree_view_column_new_with_attributes("Reported", renderer, "active", 5, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_toggle_new();
    column = gtk_tree_view_column_new_with_attributes("Initialized", renderer, "active", 6, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    renderer = gtk_cell_renderer_toggle_new();
    column = gtk_tree_view_column_new_with_attributes("Measuring", renderer, "active", 7, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);
 
    return treeView;
}

GtkWidget* createTreeViewForRTAEventConfiguration(const std::vector<RTAEvent> &events) {
    
   GtkListStore *store = gtk_list_store_new(6, 
                                             G_TYPE_INT,     // No
                                             G_TYPE_BOOLEAN, // Registered (checkbox)
                                             G_TYPE_STRING,  // Event
                                             G_TYPE_STRING,  // Stat
                                             G_TYPE_STRING,  // On-Limit
                                             G_TYPE_STRING   // Off-Limit
                                             );

    for (size_t i = 0; i < events.size(); ++i) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, static_cast<int>(i + 1),       // No
                           1, FALSE,                        // Registered (checkbox initially unchecked)
                           2, events[i].id.c_str(),         // Event
                           3, events[i].stat.c_str(),       // Stat
                           4, events[i].onlimit.c_str(),    // On-Limit
                           5, events[i].offlimit.c_str(),   // Off-Limit
                           -1);
    }


    current_store = store;

    GtkWidget *treeView = gtk_tree_view_new_with_model(GTK_TREE_MODEL(store));
    g_object_unref(store); 

   
    GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
    GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes("No", renderer, "text", 0, NULL);
    gtk_tree_view_column_set_expand(column, TRUE); 
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

    
    renderer = gtk_cell_renderer_toggle_new();
    column = gtk_tree_view_column_new_with_attributes("Registered", renderer, "active", 1, NULL);
    gtk_tree_view_column_set_expand(column, TRUE); 
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

    
    g_signal_connect(renderer, "toggled", G_CALLBACK(on_checkbox_toggled), store);

  
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Event", renderer, "text", 2, NULL);
    gtk_tree_view_column_set_expand(column, TRUE); 
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Stat", renderer, "text", 3, NULL);
    gtk_tree_view_column_set_expand(column, TRUE); 
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

  
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("On-Limit", renderer, "text", 4, NULL);
    gtk_tree_view_column_set_expand(column, TRUE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Off-Limit", renderer, "text", 5, NULL);
    gtk_tree_view_column_set_expand(column, TRUE); 
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeView), column);

    return treeView;
}


void on_checkbox_toggled(GtkCellRendererToggle *cell_renderer, gchar *path, gpointer user_data) {
    
    GtkListStore *store = GTK_LIST_STORE(user_data); 
    GtkTreeIter iter;

    GtkTreePath *tree_path = gtk_tree_path_new_from_string(path);
    if (!gtk_tree_model_get_iter(GTK_TREE_MODEL(store), &iter, tree_path)) {
  
        gtk_tree_path_free(tree_path);
        return;
    }

   
    gboolean is_checked;
    gtk_tree_model_get(GTK_TREE_MODEL(store), &iter, 1, &is_checked, -1);

  
    is_checked = !is_checked;
    gtk_list_store_set(store, &iter, 1, is_checked, -1);

    
    gtk_tree_path_free(tree_path);

    
}

static void button_supported_rta_events_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");

    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("never reach here.");
        return ;
    }
    
    StatusID eStatus ;
    std::string inXml;
    std::string outXml;
    
    std::ostringstream oss ;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>";
    oss << "</inArgs>";
    inXml = oss.str();
    

    ::ExecCommand(CMD_RTA_GET_SUPPORTED_EVENTS, inXml, outXml, &eStatus);       
   
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RTA_GET_SUPPORTED_EVENTS failed: %d", eStatus);
        append_new_event_log_msg("GetSupportedRtaEvents command failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("GetSupportedRtaEvents command failed: " + status_message);
        
        return;
    }

    GtkWidget *treeView = createTreeViewForRTAEventConfiguration(parseXMLForRTAEventConfiguration(outXml));

    
    GtkWidget *parent = gtk_widget_get_parent(g_rta_config_settings);
    gtk_container_remove(GTK_CONTAINER(parent), g_rta_config_settings);
    gtk_container_add(GTK_CONTAINER(parent), treeView);
    gtk_widget_show_all(parent);

    g_rta_config_settings = treeView;

    write_status_bar("Command GetSupportedRtaEvents success.");
    append_new_event_log_msg("Command GetSupportedRtaEvents success.")  ;  
    debug_print("function end");
}
static void button_get_rta_event_status_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");

    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("never reach here.");
        return ;
    }
    
    StatusID eStatus ;
    std::string inXml;
    std::string outXml;
    
    std::ostringstream oss ;
    oss << "<inArgs>";
    oss <<    "<scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>";
    oss << "</inArgs>";
    inXml = oss.str();
    

    ::ExecCommand(CMD_RTA_GET_EVENT_STATUS, inXml, outXml, &eStatus);       
   
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RTA_GET_EVENT_STATUS failed: %d", eStatus);
        append_new_event_log_msg("GetRtaEventStatus command failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("GetRtaEventStatus command failed: " + status_message);
        
        return;
    }

    GtkWidget *treeView = createTreeViewForRTAEventStatus(parseXMLForRTAEventStatus(outXml));

    GtkWidget *parent = gtk_widget_get_parent(g_rta_config_settings);
    gtk_container_remove(GTK_CONTAINER(parent), g_rta_config_settings);
    gtk_container_add(GTK_CONTAINER(parent), treeView);
    gtk_widget_show_all(parent);

    g_rta_config_settings = treeView;

    write_status_bar("Command GetRtaEventStatus success.");
    append_new_event_log_msg("Command GetRtaEventStatus success.")  ;  
    debug_print("function end");
}


static void button_clear_all_rta_clicked(GtkWidget* widget, gpointer user_data) {
    
    if (current_store == NULL) {
        g_print("No table to clear.\n");
        return;
    }

    gtk_list_store_clear(current_store);

}



static void initialize_led_on_off_combo_box(){
    debug_print("function start");
    GtkListStore* list_store = gtk_list_store_new(1, G_TYPE_STRING);
    GtkCellRenderer* cell_renderer = gtk_cell_renderer_text_new();
    gtk_cell_layout_pack_start(GTK_CELL_LAYOUT(g_combo_box_led_on_off),cell_renderer, TRUE);
    gtk_cell_layout_set_attributes( GTK_CELL_LAYOUT(g_combo_box_led_on_off),cell_renderer,\
                                    "text",0,NULL);
    gtk_combo_box_set_model( GTK_COMBO_BOX(g_combo_box_led_on_off),GTK_TREE_MODEL(list_store));
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_led_on_off), "Green LED");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_led_on_off), "Red LED");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_led_on_off), "Yellow LED");
    debug_print("function end");
}

static void button_led_on_clicked( GtkWidget* , gpointer )
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 ){
        write_status_bar("Please select a scanner before invoking this command");
        return;
    }
    
    char * strActiveText =gtk_combo_box_get_active_text(GTK_COMBO_BOX(g_combo_box_led_on_off));
    if ( strActiveText == NULL )
    {
        run_modal_message_box("Please select an LED to turn off.","Info:");
        return ;
    }
    
      
    int iUifCode = 0;
    
    if ( strcmp(strActiveText,"Green LED")== 0 ){
        debug_print("turning on Green LED");
        iUifCode = 0x2B;        
    }else if ( strcmp( strActiveText, "Red LED")==0 ){
        debug_print("Turning on Red LED");
        iUifCode = 0x2f;        
    }else if ( strcmp( strActiveText, "Yellow LED")== 0){
        debug_print("Turning on Yellow LED");    
        iUifCode = 0x2D;       
    }else { 
        write_status_bar("Please select LED to turn on");
        return ;
    }
    
    std::string strOutXml ;
    std::string strInXml ;
    std::ostringstream oss ;
    StatusID eStatusId;
    
    oss << "<inArgs>" ;
    oss << "     <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "     <cmdArgs>" <<std::endl;
    oss << "         <arg-xml>"<< std::endl;
    oss << "             <attrib_list>"<< std::endl;
    oss << "                 <attribute>"<< std::endl;
    oss << "                      <id>6000</id>"<< std::endl;
    oss << "                      <datatype>X</datatype>"<< std::endl;
    oss << "                      <value>"<< iUifCode << "</value>" << std::endl;
    oss << "                 </attribute>"<< std::endl;
    oss << "             </attrib_list>" << std::endl;
    oss << "          </arg-xml>" << std::endl;
    oss << "     </cmdArgs>"<< std::endl;
    oss << "</inArgs>" ;
    
    strInXml = oss.str();
    
    g_free((void*)strActiveText);
    
    ExecCommand(CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatusId);
    if ( eStatusId != STATUS_OK ){
        
        std::string status_message = GetErrorMessage(eStatusId);
        debug_print("Command CMD_RSM_ATTR_SET failed: %d", eStatusId);
        append_new_event_log_msg("Command Attribute Set failed: %d - %s", eStatusId, status_message.c_str());
        write_status_bar("Command Attribute Set failed: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_RSM_ATTR_SET success");
    append_new_event_log_msg("Command Attribute Set success");
    write_status_bar("Command Attribute Set success");
    debug_print("function end");
}
static void button_led_off_clicked( GtkWidget* , gpointer )
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 ){
        write_status_bar("Please select a scanner before invoking this command");
        return;
    }
    
    char * strActiveText =gtk_combo_box_get_active_text(GTK_COMBO_BOX(g_combo_box_led_on_off));
    if ( strActiveText == NULL )
    {
        run_modal_message_box("Please select an LED to switch off", "Info:");
        return;
    }
    
    
    int iUifCode = 0;
    
    if ( strcmp(strActiveText,"Green LED")== 0 ){
        debug_print("turning on Green LED");
        iUifCode = 0x2A;
       
    }else if ( strcmp( strActiveText, "Red LED")==0 ){
        debug_print("Turning on Red LED");
        iUifCode = 0x30;
        
    }else if ( strcmp( strActiveText, "Yellow LED")== 0){
        debug_print("Turning on Yellow LED");    
        iUifCode = 0x2E;
            
    }else { 
        write_status_bar("Please select LED to turn on");
        return ;
    }
    
    std::string strOutXml ;
    std::string strInXml ;
    std::ostringstream oss ;
    StatusID eStatusId;
    
    oss << "<inArgs>" ;
    oss << "     <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "     <cmdArgs>" <<std::endl;
    oss << "         <arg-xml>"<< std::endl;
    oss << "             <attrib_list>"<< std::endl;
    oss << "                 <attribute>"<< std::endl;
    oss << "                      <id>6000</id>"<< std::endl;
    oss << "                      <datatype>X</datatype>"<< std::endl;
    oss << "                      <value>"<< iUifCode << "</value>" << std::endl;
    oss << "                 </attribute>"<< std::endl;
    oss << "             </attrib_list>" << std::endl;
    oss << "          </arg-xml>" << std::endl;
    oss << "     </cmdArgs>"<< std::endl;
    oss << "</inArgs>" ;
    
    strInXml = oss.str();
    
    g_free((void*)strActiveText);
    
    ExecCommand(CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatusId);
    if ( eStatusId != STATUS_OK ){
                
        std::string status_message = GetErrorMessage(eStatusId);
        debug_print("Command CMD_RSM_ATTR_SET failed: %d", eStatusId);
        append_new_event_log_msg("Command Attribute Set failed: %d - %s", eStatusId, status_message.c_str());
        write_status_bar("Command Attribute Set failed: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_RSM_ATTR_SET success");
    append_new_event_log_msg("Command Attribute Set success");
    write_status_bar("Command Attribute Set success");    
    
    debug_print("function end");
}

static void button_pager_motor_start_clicked(GtkWidget*, gpointer)
{
    debug_print("function start.");

    if ( iCurrentlySelectedScannerId == 0 ){
        write_status_bar("Please select a scanner before invoking this command.");
        return;
    }
    
    std::string str_duration = "";
    str_duration = gtk_entry_get_text (GTK_ENTRY(g_entry_duration));
    
    if ( str_duration == "" )
    {
        write_status_bar("Please enter a duration in milliseconds.");
        run_modal_message_box("Please enter a duration in milliseconds.","ERROR");
        return ;
    } 
    else
    {
        std::string strOutXml;
        std::string strInXml;
        std::ostringstream oss;
        StatusID eStatusId;

        oss << "<inArgs>" ;
        oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
        oss << "    <cmdArgs>" << std::endl;
        oss << "        <arg-xml>" << std::endl;
        oss << "            <attrib_list>" << std::endl;
        oss << "                <attribute>" << std::endl;
        oss << "                    <id>6033</id>" << std::endl;
        oss << "                    <datatype>X</datatype>" << std::endl;
        oss << "                    <value>" << str_duration << "</value>" << std::endl;
        oss << "                </attribute>" << std::endl;
        oss << "            </attrib_list>" << std::endl;
        oss << "        </arg-xml>" << std::endl;
        oss << "    </cmdArgs>" << std::endl;
        oss << "</inArgs>" ;

        strInXml = oss.str();          
        ExecCommand(CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatusId);

        if ( eStatusId != STATUS_OK )
        {       
            std::string status_message = GetErrorMessage(eStatusId);
            debug_print("Command CMD_RSM_ATTR_SET failed: %d", eStatusId);
            append_new_event_log_msg("Command Attribute Set failed: %d - %s", eStatusId, status_message.c_str());
            write_status_bar("Command Attribute Set failed: " + status_message);            
            return ;
        }          
            debug_print("Command CMD_RSM_ATTR_SET success.");
            append_new_event_log_msg("Command Attribute Set success.");
            write_status_bar("Command Attribute Set success.");
            debug_print("function end.");
     }  
}

static void button_aim_off_clicked(GtkWidget*, gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("invalid scanner ID was selected.");
        write_status_bar("Please select a scanner first.");
        return ;
    }
    
    
    std::string strInXml;
    std::string strOutXml;
    std::ostringstream oss;
    StatusID eStatus;
    
    oss << "<inArgs>" <<std::endl;
    oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "</inArgs>"<< std::endl;
    
    strInXml = oss.str();
    
    ExecCommand( CMD_DEVICE_AIM_OFF, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_AIM_OFF failed: %d", eStatus);
        append_new_event_log_msg("Command AIM Off failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command AIM Off failed: " + status_message);
        
        return ;
    }
    
    append_new_event_log_msg("Command AIM Off success.");
    write_status_bar("Command AIM Off success");
    debug_print("function end");
}

static void button_aim_on_clicked( GtkWidget* , gpointer )
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a scanner before invoking this command");
        write_status_bar("Please select a scanner first from the list.");
        return ;
    }
    
    std::string strInXml ;
    std::string strOutXml;
    std::ostringstream oss ;
    
    oss << "<inArgs>" << std::endl;
    oss << "    <scannerID>" <<  iCurrentlySelectedScannerId << "</scannerID>" <<std::endl;
    oss << "</inArgs>" ;
    
    strInXml = oss.str();
    StatusID eStatus;
    
    
    ExecCommand( CMD_DEVICE_AIM_ON, strInXml, strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_AIM_ON failed: %d", eStatus);
        append_new_event_log_msg("Command AIM On failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command AIM On failed: " + status_message);
        return;
    }
    
    debug_print("Command CMD_DEVICE_AIM_ON success");
    append_new_event_log_msg("Command AIM On success");
    write_status_bar("Command AIM On success.");
    debug_print("function end");
}

static void initialize_combo_box_beep()
{
    debug_print("function start");
    GtkListStore* list_store = gtk_list_store_new(1, G_TYPE_STRING);
    GtkCellRenderer* cell_renderer = gtk_cell_renderer_text_new();
    gtk_cell_layout_pack_start(GTK_CELL_LAYOUT(g_combo_box_select_beep),cell_renderer, TRUE);
    gtk_cell_layout_set_attributes( GTK_CELL_LAYOUT(g_combo_box_select_beep),cell_renderer,\
                                    "text",0,NULL);
    gtk_combo_box_set_model( GTK_COMBO_BOX(g_combo_box_select_beep),GTK_TREE_MODEL(list_store));
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "ONE SHORT HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "TWO SHORT HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "THREE SHORT HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FOUR SHORT HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FIVE SHORT HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "ONE SHORT LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "TWO SHORT LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "THREE SHORT LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FOUR SHORT LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FIVE SHORT LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "ONE LONG HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "TWO LONG HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "THREE LONG HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FOUR LONG HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FIVE LONG HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "ONE LONG LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "TWO LONG LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "THREE LONG LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FOUR LONG LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FIVE LONG LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "FAST HIGH LOW HIGH LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "SLOW HIGH LOW HIGH LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "HIGH LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "HIGH HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "HIGH LOW HIGH");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "LOW HIGH LOW");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_select_beep), "HIGH HIGH LOW LOW");    
    debug_print("function end");
}

static void button_beep_clicked( GtkWidget* , gpointer )
{
    debug_print("function start");
    
    char * strActiveText = gtk_combo_box_get_active_text( GTK_COMBO_BOX(g_combo_box_select_beep));
    
    if ( strActiveText == NULL )
    {
        run_modal_message_box("Please select a beep pattern first", "Info:");
        return;
    }
    
    int iUicCode = 0;
    
    if ( iCurrentlySelectedScannerId == 0 ){
        debug_print("Please select a scanner before invoking this command.");
        write_status_bar("Please select a scanner before invoking this command.");
        return ;
    }
    
    if ( strcmp (strActiveText, "ONE SHORT HIGH")== 0){
        debug_print("Executing ONE SHROT HIGH");
        iUicCode = 0x00;
    } else if ( strcmp ( strActiveText, "TWO SHORT HIGH")== 0)
    {
        debug_print("Executing TWO SHORT HIGH") ;
        iUicCode = 0x01;
    }else if ( strcmp ( strActiveText, "THREE SHORT HIGH") == 0)
    {
        debug_print("Executing THREE SHORT HIGH");
        iUicCode = 0x02;
    }else if ( strcmp ( strActiveText , "FOUR SHORT HIGH") == 0 ){
        debug_print("Executing FOUR SHORT HIGH");
        iUicCode =0x03 ;
    }else if ( strcmp ( strActiveText, "FIVE SHORT HIGH") == 0)
    {
        debug_print("Executing FIVE SHORT HIGH");
        iUicCode = 0x04 ;
    }else if ( strcmp ( strActiveText, "ONE SHORT LOW")== 0)
    {
        debug_print("Executing ONE SHORT LOW");
        iUicCode = 0x05;
    }else if ( strcmp ( strActiveText, "TWO SHORT LOW") == 0)
    {
        debug_print("Executing TWO SHORT LOW");
        iUicCode =0x06;
    }else if ( strcmp (strActiveText , "THREE SHORT LOW") == 0 )
    {
        debug_print("Executing THREE SHORT LOW");
        iUicCode =0x07;
    }else if ( strcmp ( strActiveText , "FOUR SHORT LOW") == 0 ){  
        debug_print("Executing FOUR SHORT LOW");
        iUicCode = 0x08;
    }else if ( strcmp (strActiveText, "FIVE SHORT LOW") == 0 ){
        debug_print("Executing FIVE SHORT LOW");
        iUicCode = 0x09;
    }else if ( strcmp ( strActiveText, "ONE LONG HIGH") == 0 )
    {
        debug_print("Executing ONE LONG HIGH");
        iUicCode =0x0A;
    }else if ( strcmp ( strActiveText, "TWO LONG HIGH") == 0 ){
        debug_print("Executing TWO LONG HIGH");
        iUicCode =0x0B;
    }else if ( strcmp ( strActiveText, "THREE LONG HIGH") == 0)
    {
        debug_print("Executing THREE LONG HIGH");
        iUicCode =0x0C;
    }else if ( strcmp( strActiveText, "FOUR LONG HIGH") == 0)
    {
        debug_print("Executing FOUR LONG HIGH");
        iUicCode = 0x0D;
    }else if ( strcmp( strActiveText, "FIVE LONG HIGH")== 0)
    {
        debug_print ( "Executing FIVE LONG HIGH");
        iUicCode =0x0E;
    }else if ( strcmp ( strActiveText, "ONE LONG LOW")==0)
    {
        debug_print("Executing ONE LONG LOW");
        iUicCode = 0x0F;
    }else if ( strcmp( strActiveText, "TWO LONG LOW") == 0)
    {
        debug_print("Executing TWO LONG LOW");
        iUicCode = 0x10;
    }else if ( strcmp ( strActiveText, "THREE LONG LOW") == 0)
    {
        debug_print("Executing THREE LONG LOW");
        iUicCode = 0x11;
    }else if ( strcmp ( strActiveText, "FOUR LONG LOW") == 0 )
    {
        debug_print("Executing FOUR LONG LOW");
        iUicCode = 0x12;
    }else if ( strcmp ( strActiveText , "FIVE LONG LOW") == 0)
    {
        debug_print("Executing FIVE LONG LOW");
        iUicCode = 0x13;
    }else if ( strcmp ( strActiveText, "FAST HIGH LOW HIGH LOW") == 0)
    {
        debug_print ("Executing FAST HIGH LOW HIGH LOW");
        iUicCode =0x14;
    }else if ( strcmp ( strActiveText, "SLOW HIGH LOW HIGH LOW")== 0)
    {
        debug_print("Executing SLOW HIGH LOW HIGH LOW");
        iUicCode = 0x15;
    }else if ( strcmp ( strActiveText, "HIGH LOW") == 0)
    {
        debug_print("Executing HIGH LOW");
        iUicCode =0x16;
    }else if ( strcmp (strActiveText,"HIGH HIGH")== 0)
    {
        debug_print("Executing HIGH HIGH");
        iUicCode =0x17;
    }else if ( strcmp( strActiveText,"HIGH LOW HIGH")== 0)
    {
        debug_print("Executing HIGH LOW HIGH");
        iUicCode =0x18;
    }else if ( strcmp ( strActiveText, "LOW HIGH LOW") == 0 )
    {
        debug_print("Executing LOW HIGH LOW");
        iUicCode = 0x19;
    }else if ( strcmp ( strActiveText, "HIGH HIGH LOW LOW") == 0)
    {
        debug_print("HIGH HIGH LOW LOW");
        iUicCode = 0x1A;
    }else {
        debug_print("please select valid beep tone");
        write_status_bar("Please select valid beep tone from the list.");
        return ;
    }
    
    std::string strInXml ;
    std::string strOutXml ;
    std::ostringstream oss ;
    StatusID eStatus ;
    
    oss << "<inArgs>"<< std::endl;
    oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" <<std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-xml>"<< std::endl;
    oss << "             <attrib_list>"<< std::endl;
    oss << "                 <attribute>"<< std::endl;
    oss << "                     <id>6000</id>"<< std::endl;
    oss << "                     <datatype>X</datatype>" << std::endl;
    oss << "                     <value>" << iUicCode <<"</value>" << std::endl;
    oss << "                  </attribute>" << std::endl;
    oss << "               </attrib_list>" << std::endl;
    oss << "         </arg-xml>" << std::endl;
    oss << "      </cmdArgs>" << std::endl;
    oss << " </inArgs>" << std::endl;
    
    strInXml = oss.str();
    
    ExecCommand ( CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK ){
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_SET failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Set failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Set failed: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_RSM_ATTR_SET success.");
    write_status_bar("Command Attribute Set success.");
    append_new_event_log_msg("Command Attribute Set success.");
    
    debug_print("function end");
}


static void button_switch_host_mode_clicked( GtkWidget* , gpointer )
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("Please select a scanner before invoking this operation");
        
        write_status_bar("Please select a scanner before executing switch host mode.");
        return;
    }
    
    
    std::string strInXml;
    std::string strOutXml ;
    std::ostringstream oss;
    StatusID eStatus ;
    
    oss << "<inArgs>" << std::endl;
    oss << "    <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    
    std::string strStringCode = "" ;
    
    char* strActiveComboBoxText = gtk_combo_box_get_active_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant));
    if ( strActiveComboBoxText == NULL)
    {
        run_modal_message_box("Please select target host mode first", "Info:");
        return ;
    }
    
    
    if ( strcmp (strActiveComboBoxText, "USB-HIDKB") == 0 )
    {
        debug_print("Request to USB-HIDKB");
        strStringCode = "XUA-45001-3";
    }else if ( strcmp (strActiveComboBoxText, "USB-SNAPI with Imaging") == 0) {
        debug_print("Request to change to USB-SNAPI with Imaging.");
        strStringCode = "XUA-45001-9" ;
    }else if ( strcmp ( strActiveComboBoxText, "USB-SNAPI without Imaging") == 0)
    {
        debug_print("Request to change to USB-SNAPI without Imaging.");
        strStringCode = "XUA-45001-10" ;
    }else if ( strcmp ( strActiveComboBoxText, "USB-IBMHID")== 0)
    {
        debug_print("Request to change to USB-IBMHID.");
        strStringCode = "XUA-45001-1" ;
    }
    else if ( strcmp (strActiveComboBoxText, "USB-IBMTT") == 0)
    {
        debug_print("Request to change to USB-IBMTT");
        strStringCode = "XUA-45001-2";
    }else {
        debug_print("Request to change to other mode.");
        write_status_bar("unsupported mode selected.");
        return ;
    }
    
    
    oss << "    <arg-string>"<< strStringCode << "</arg-string>" << std::endl;
    
    bool bSilient = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(g_check_button_silent_switch_host_mode));
    bool bPermanent = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(g_check_button_permanent_switch_host_mode));
    
    oss << "     <arg-bool>" << ((bSilient)? "TRUE":"FALSE") << "</arg-bool>" << std::endl;
    oss << "     <arg-bool>" << ((bPermanent)?"TRUE":"FALSE") <<"</arg-bool>" << std::endl;
    oss << "    </cmdArgs>" << std::endl;
    oss << "</inArgs>" ;
    strInXml = oss.str();
    
    ExecCommand ( CMD_DEVICE_SWITCH_HOST_MODE, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_SWITCH_HOST_MODE failed: %d", eStatus);
        append_new_event_log_msg("Command Switch Host Mode failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Switch Host Mode failed: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_DEVICE_SWITCH_HOST_MODE success");
    write_status_bar("Command Switch Host Mode success.");
    append_new_event_log_msg("Command Switch Host Mode success.");
    debug_print("function end");
}

static void initialize_combo_box_switch_host_mode()
{
    debug_print("function start");
        GtkListStore* list_store = gtk_list_store_new(1, G_TYPE_STRING);
    GtkCellRenderer* cell_renderer = gtk_cell_renderer_text_new();
    gtk_cell_layout_pack_start(GTK_CELL_LAYOUT(g_combo_box_switch_host_variant),cell_renderer, TRUE);
    gtk_cell_layout_set_attributes( GTK_CELL_LAYOUT(g_combo_box_switch_host_variant),cell_renderer,\
                                    "text",0,NULL);
    gtk_combo_box_set_model(GTK_COMBO_BOX(g_combo_box_switch_host_variant),GTK_TREE_MODEL(list_store));
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant), "USB-HIDKB");    
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant), "USB-SNAPI with Imaging");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant), "USB-SNAPI without Imaging");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant), "USB-IBMHID");
    gtk_combo_box_append_text(GTK_COMBO_BOX(g_combo_box_switch_host_variant), "USB-IBMTT");
    debug_print("function end");
}

static void button_get_all_ids_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 ){
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid Scanner from the list");
        return ;
    }
    
    std::string strInXml ;
    std::string strOutXml;
    StatusID eStatus ;
    
    std::ostringstream oss ;
    oss << "<inArgs>" << std::endl;
    oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "</inArgs>" << std::endl;
    
    strInXml = oss.str();
    
    ExecCommand(CMD_RSM_ATTR_GETALL, strInXml, strOutXml , &eStatus);
    if ( eStatus != STATUS_OK)
    {        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_GETALL failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Get All failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Get All failed: " + status_message);
        return ;
    }
    
    debug_print("CMD_RSM_ATTR_GETALL command success");
    write_status_bar("Command Attribute Get All command success");
    
    append_new_event_log_msg("Command Attribute Get All success");
    append_new_xml_log(strOutXml);
    
    // parse the command //
    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_string(strOutXml.c_str());
    if ( result.status != pugi::status_ok) {
        debug_print("XML parsing error");
        write_status_bar("XML parsing error for Command Attribute Get All");
        return ;
    }
    
    pugi::xml_node node_attrib_list = doc.child("outArgs").child("arg-xml").child("response").child("attrib_list");
    
    GtkTreeModel* treeModel = gtk_tree_view_get_model(GTK_TREE_VIEW(g_tree_view_rsm));
    GtkListStore* list_store = GTK_LIST_STORE(treeModel);
    gtk_list_store_clear(list_store);
    
    pugi::xml_node node;
    for ( node = node_attrib_list.first_child() ; \
              node ;
              node = node.next_sibling()) {
        std::string strCurrentId =node.child_value();
        GtkTreeIter iter;
        gtk_list_store_insert(list_store,&iter, 10000000);
        gtk_list_store_set(list_store,&iter, 0, strCurrentId.c_str() ,\
                                1,"", 2,"", 3,"" ,-1);
    }

    debug_print("function end");
}

static void button_next_value_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    if ( iCurrentlySelectedScannerId == 0) 
    {
        debug_print("Please select a scanner from list before invoking this command");
        write_status_bar("Please select a scanner from the list before invoking this command.");
        return  ;
    }
    
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(g_tree_view_rsm));
    GtkTreeModel* treeModel ;
    GtkListStore* listStore ;
    
    int iCountSelected = gtk_tree_selection_count_selected_rows(treeSelection);
    
    if (iCountSelected == 0)
    {
        debug_print("Please select one or more rows before invoking this command.");
        write_status_bar("Please select one or more rows before invoking this command.");
        run_modal_message_box("Error", "Please select one or more rows before invoking this command");
        return ;
    }

    GList* selectedRows = gtk_tree_selection_get_selected_rows(treeSelection,&treeModel);
    
    listStore = GTK_LIST_STORE(treeModel);
    GList* currentRow = g_list_first( selectedRows);
    std::vector<GtkTreePath*> vecTreePaths;
    for ( ; currentRow ; currentRow = g_list_next(currentRow)) 
    {
        vecTreePaths.push_back((GtkTreePath*)( currentRow->data));
        //std::cout << gtk_tree_path_to_string((GtkTreePath*)(currentRow->data));
    }    


    // get the last tree path //
    GtkTreeIter iterNext;
    GtkTreePath * treePathLast = vecTreePaths.back();
    char* strTreePath = gtk_tree_path_to_string(treePathLast);
    gtk_tree_model_get_iter_from_string(treeModel,&iterNext, strTreePath);
    bool bHasNextIterator = gtk_tree_model_iter_next(treeModel, &iterNext);
    if ( !bHasNextIterator) {
        debug_print("Next Iterator not found in the RSM tree view");
        write_status_bar("Invalid next RSM attribute");
        run_modal_message_box("Error!","Invalid next RSM attribute");
        return ;
    }
    
    GValue value = {0,};
    gtk_tree_model_get_value(treeModel,\
                            &iterNext, \
                            0,\
                            &value);
    std::string strNextAttrId ;
    strNextAttrId = g_value_get_string(&value);
    
    // invoke CMD_RSM_ATTR_GET for that strNextAttrId //.
    std::string strInXml;
    std::string strOutXml;
    std::ostringstream oss;
    StatusID eStatus;
    
    oss << "<inArgs>"<< std::endl;
    oss << "  <scannerID>" << iCurrentlySelectedScannerId<< "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "      <arg-xml>" << std::endl;
    oss << "        <attrib_list>"<< strNextAttrId << "</attrib_list>" << std::endl;
    oss << "      </arg-xml>" << std::endl;
    oss << "    </cmdArgs>"<< std::endl;
    oss << "</inArgs>"<< std::endl;
    
    strInXml = oss.str();
    
    ExecCommand( CMD_RSM_ATTR_GET , strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_GET failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Get failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Get failed: " + status_message);
        
        return ;
    }
    
    debug_print("CMD_RSM_ATTR_GET successful.");
    write_status_bar("Command Attribute Get successful");
    append_new_event_log_msg("Command Attribute Get successful");
    append_new_xml_log(strOutXml);
    
    
    // process the strOutXml //
    pugi::xml_document doc ;
    pugi::xml_parse_result result = doc.load_string(strOutXml.c_str());
    if ( result.status != pugi::status_ok){
        debug_print("Invalid outXML received when after calling CMD_RSM_ATTR_GET.");
        write_status_bar("Invalid outXML received after calling CMD_RSM_ATTR_GET");
        return;
    }
    
    pugi::xml_node node_attribute = doc.child("outArgs").child("arg-xml").child("response").
            child("attrib_list").child("attribute");
    
    std::string strId = node_attribute.child("id").child_value();
    std::string strDataType = node_attribute.child("datatype").child_value();
    std::string strValue = node_attribute.child("value").child_value();
    
    
    
    gtk_list_store_set(listStore, &iterNext,0, strId.c_str() , 1, strDataType.c_str() , \
                                    3, strValue.c_str() , -1);
    debug_print("function end");
}

static void button_store_clicked(GtkWidget*,gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a scanner from the list before invoking this command");
        write_status_bar("Please select a scanner from the list before invoking this command");
        return;
    }
    
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(g_tree_view_rsm));
    GtkTreeModel* treeModel ;
     
    int iCountSelected = gtk_tree_selection_count_selected_rows(treeSelection);
    
    if (iCountSelected == 0)
    {
        debug_print("Please select one or more rows before invoking this command.");
        write_status_bar("Please select one or more rows before invoking this command.");
        run_modal_message_box( "Please select one or more rows before invoking this command","ERROR");
        return ;
    }

    GList* selectedRows = gtk_tree_selection_get_selected_rows(treeSelection,&treeModel);    

    GList* currentRow = g_list_first( selectedRows);
    std::vector<GtkTreePath*> vecTreePaths;
    for ( ; currentRow ; currentRow = g_list_next(currentRow)) 
    {
        vecTreePaths.push_back((GtkTreePath*)( currentRow->data));
        //std::cout << gtk_tree_path_to_string((GtkTreePath*)(currentRow->data));
    }    
    
    // execute CMD_RSM_ATTR_SET command //
    std::string strInXml ;
    std::string strOutXml ;
    std::ostringstream oss ;
    StatusID eStatus ;
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "  <cmdArgs>"<< std::endl;
    oss << "    <arg-xml>" << std::endl;
    oss << "      <attrib_list>"<< std::endl;
    
    // :TODO: write the end enclosure of xml that we started //
    
    std::vector<GtkTreePath*>::iterator itr = vecTreePaths.begin();
    for(; itr != vecTreePaths.end() ; itr++)
    {
        GtkTreePath* currentTreePath = *itr;
        GtkTreeIter treeIter ;
        const char* strTreePath = gtk_tree_path_to_string(currentTreePath);
        gtk_tree_model_get_iter_from_string(treeModel, &treeIter, strTreePath);
        
        GValue valueId = {0,} ;
        GValue valueDataType = {0,} ;
        GValue valueValue = {0,} ;
        gtk_tree_model_get_value(treeModel,&treeIter, 0, &valueId);
        gtk_tree_model_get_value(treeModel,&treeIter, 1, &valueDataType);
        gtk_tree_model_get_value(treeModel,&treeIter, 3, &valueValue);
        
        std::string strId = g_value_get_string(&valueId);
        std::string strDataType = g_value_get_string(&valueDataType);
        std::string strValue = g_value_get_string(&valueValue);
        oss << "        <attribute>" << std::endl;
        oss << "          <id>" << strId << "</id>" << std::endl;
        oss << "          <datatype>" << strDataType << "</datatype>" << std::endl;
        oss << "          <value>" << strValue << "</value>" << std::endl;
        oss << "        </attribute>"<< std::endl;
        
    }
    
    oss << "      </attrib_list>"<<std::endl;
    oss << "    </arg-xml>"<< std::endl;
    oss << "  </cmdArgs>"<< std::endl;
    oss << "</inArgs>" << std::endl;
    
    strInXml = oss.str();
    
    
    ExecCommand(CMD_RSM_ATTR_STORE, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        debug_print("Command CMD_RSM_ATTR_STORE failed.");
        write_status_bar("Command Attribute Set Store failed.");
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_STORE failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Set Store failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Set Store: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_RSM_ATTR_STORE succcess");
    write_status_bar("Command Attribute Set Store success");
    append_new_event_log_msg("Command Attribute Set Store passed");    
    debug_print("function end");
}

static void button_get_value_clicked(GtkWidget*,gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0)
    {
        debug_print("Please select a scanner from the list before invoking this command");
        write_status_bar("Please select a scanner from the list before invoking this command");
        return ;
    }
    
    
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(\
            g_tree_view_rsm));
    GtkTreeModel* treeModel ;
    GtkListStore* list_store;
    
    int iCountSelected = gtk_tree_selection_count_selected_rows(treeSelection);
    if ( iCountSelected == 0){
        debug_print("Please select more than one row before executing this command");
        write_status_bar("Please select more than one row before executing this command");
        run_modal_message_box("Please select one or more row before executing this command" , "ERROR");
        return; 
    }
    
    GList* selectedRows = gtk_tree_selection_get_selected_rows(treeSelection,&treeModel);
    list_store = GTK_LIST_STORE(treeModel);
    GList* currentRow = g_list_first( selectedRows);
    std::vector<GtkTreePath*> vecTreePaths;
    for ( ; currentRow ; currentRow = g_list_next(currentRow)) 
    {
        vecTreePaths.push_back((GtkTreePath*)( currentRow->data));
    }
    
    // execute RMS_GET command //
    std::string strInXml;
    std::string strOutXml;
    StatusID eStatus;
    
    std::ostringstream oss;
    oss << "<inArgs>"<< std::endl;
    oss << "    <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-xml>" << std::endl;
    oss << "            <attrib_list>" ;
    
    std::vector<GtkTreePath*>::iterator itr;
    for ( itr = vecTreePaths.begin(); itr != vecTreePaths.end() ; itr++ )
    {
        GtkTreePath* currentPath = *itr;
        std::string strCurrentPath = gtk_tree_path_to_string(currentPath);
        // :TODO: // modification :TODO: 
        GValue value = {0,} ;
        GtkTreeIter treeIter;
        gtk_tree_model_get_iter_from_string(treeModel, &treeIter, strCurrentPath.c_str());
        
        gtk_tree_model_get_value(treeModel,&treeIter, 0, &value);
        std::string strCurrentId = g_value_get_string(&value);
        
        oss << strCurrentId ;
        
        if ( itr +1 != vecTreePaths.end())
            oss << ",";
    }
    
    oss << "</attrib_list>" << std::endl;
    oss << "        </arg-xml>" << std::endl;
    oss << "     </cmdArgs>" << std::endl;
    oss << "</inArgs>"<< std::endl;
    
    strInXml = oss.str();
    
    ExecCommand(CMD_RSM_ATTR_GET, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK ){
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_GET failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Get failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Get failed: " + status_message);
        return;
    }
    
    debug_print("Command CMD_RSM_ATTR_GET success");
    append_new_event_log_msg("Command Attribute Get success");
    write_status_bar("Command Attribute Get success");
    append_new_xml_log(strOutXml);
    
    // parse the outxml and update the rows //
    pugi::xml_document doc ;
    pugi::xml_parse_result result = doc.load_string(strOutXml.c_str());
    
    if ( result.status != pugi::status_ok)
    {
        debug_print("Can't parse outXml from CMD_RSM_ATTR_GET.");
        return ;
    }
    
    pugi::xml_node node_attrib_list = doc.child("outArgs").child("arg-xml").child("response").child("attrib_list");
    pugi::xml_node node_attribute ;
    for( node_attribute= node_attrib_list.first_child() ; \
            node_attribute ;\
            node_attribute = node_attribute.next_sibling() )
    {
        pugi::xml_node node_id = node_attribute.child("id");
        pugi::xml_node node_data_type = node_attribute.child("datatype");
        pugi::xml_node node_value = node_attribute.child("value");
        pugi::xml_node node_property = node_attribute.child("permission");
        
        std::string strId = node_id.child_value();
        const char * strDataType = node_data_type.child_value();
        const char * strNodeValue = node_value.child_value();
        std::string strProperty;
        unsigned char ucPropertyValue = (unsigned char)atoi(node_property.child_value());
        
        switch(ucPropertyValue) {
            case ATT_UM_RO:
                strProperty.append("R");
                break;
            case ATT_UM_RW:
                 strProperty.append("RW");
                break;
            case ATT_UM_PRW: 
                strProperty.append("PRW");
                break;
            case ATT_UM_WO: 
                strProperty.append("W");
                break;
            default:
                break;
        }                
        
        GtkTreeIter iter;  
        bool bIsFound = false; 
        gtk_tree_model_get_iter_first(treeModel,&iter);
        while ( ! bIsFound)
        {
            GValue value = {0,} ;
            gtk_tree_model_get_value(treeModel,&iter,0,&value);
            std::string strCurrentId = g_value_get_string(&value);
            if ( strcmp( strCurrentId.c_str()  ,strId.c_str()) == 0  ){
                bIsFound = true ;
                break;
            }
            
            bool isNextIter = gtk_tree_model_iter_next(treeModel,&iter);
            if (!isNextIter){
                break;
            }
        }
        
        if (!  bIsFound )
        {
            return ;
        }
        
        gtk_list_store_set(list_store, &iter, 0,strId.c_str() , \
                                1, strDataType , \
                                2, strProperty.c_str() , \
                                3, strNodeValue, -1);
        
    }
    debug_print("function end");
}

static void button_set_value_clicked(GtkWidget* , gpointer){
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a scanner from the list before invoking this command");
        write_status_bar("Please select a scanner from the list before invoking this command");
        return;
    }
    
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(g_tree_view_rsm));
    GtkTreeModel* treeModel ;
        
    int iCountSelected = gtk_tree_selection_count_selected_rows(treeSelection);
    
    if (iCountSelected == 0)
    {
        debug_print("Please select one or more rows before invoking this command.");
        write_status_bar("Please select one or more rows before invoking this command.");
        run_modal_message_box("Please select one or more rows before invoking this command","ERROR");
        return ;
    }

    GList* selectedRows = gtk_tree_selection_get_selected_rows(treeSelection,&treeModel);
    
    GTK_LIST_STORE(treeModel);
    GList* currentRow = g_list_first( selectedRows);
    std::vector<GtkTreePath*> vecTreePaths;
    for ( ; currentRow ; currentRow = g_list_next(currentRow)) 
    {
        vecTreePaths.push_back((GtkTreePath*)( currentRow->data));
        //std::cout << gtk_tree_path_to_string((GtkTreePath*)(currentRow->data));
    }    
    
    // execute CMD_RSM_ATTR_SET command //
    std::string strInXml ;
    std::string strOutXml ;
    std::ostringstream oss ;
    StatusID eStatus ;
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "  <cmdArgs>"<< std::endl;
    oss << "    <arg-xml>" << std::endl;
    oss << "      <attrib_list>"<< std::endl;   
    std::vector<GtkTreePath*>::iterator itr = vecTreePaths.begin();
    for(; itr != vecTreePaths.end() ; itr++)
    {
        GtkTreePath* currentTreePath = *itr;
        GtkTreeIter treeIter ;
        const char* strTreePath = gtk_tree_path_to_string(currentTreePath);
        gtk_tree_model_get_iter_from_string(treeModel, &treeIter, strTreePath);
        
        GValue valueId = {0,} ;
        GValue valueDataType = {0,} ;
        GValue valueValue = {0,} ;
        gtk_tree_model_get_value(treeModel,&treeIter, 0, &valueId);
        gtk_tree_model_get_value(treeModel,&treeIter, 1, &valueDataType);
        gtk_tree_model_get_value(treeModel,&treeIter, 3, &valueValue);
        
        std::string strId; 
        const char *cstr_id = g_value_get_string(&valueId);
        if ( strcmp(cstr_id,"") == 0)
            continue ;
        
        if (cstr_id != NULL){
            strId = cstr_id ;
        }else{
            continue;            
        }
        
        std::string strDataType;
        const char *cstr_data_type = g_value_get_string(&valueDataType);
        if ( strcmp (cstr_data_type ,"" ) == 0)
            continue ;
        
        if ( cstr_data_type )
        {
            strDataType = cstr_data_type;
        }
        else {
            continue ;           
        }
        
        std::string strValue; 
        const char * cstr_value = g_value_get_string(&valueValue);
        if( strcmp ( cstr_value, "") == 0 )
            continue ;
        
        if ( cstr_value ){
            strValue = cstr_value;
        }else {
            continue;           
        }
                
        
        oss << "        <attribute>" << std::endl;
        oss << "          <id>" << strId << "</id>" << std::endl;
        oss << "          <datatype>" << strDataType << "</datatype>" << std::endl;
        oss << "          <value>" << strValue << "</value>" << std::endl;
        oss << "        </attribute>"<< std::endl;
        
    }
    
    oss << "      </attrib_list>"<<std::endl;
    oss << "    </arg-xml>"<< std::endl;
    oss << "  </cmdArgs>"<< std::endl;
    oss << "</inArgs>" << std::endl;
    
    strInXml = oss.str();
    
    
    ExecCommand(CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_SET failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Set failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("RSM attribute get failed: " + status_message);
        
        return ;
    }
    
    debug_print("Command CMD_RSM_ATTR_SET success");
    write_status_bar("Command Attribute Set success");
    append_new_event_log_msg("Command Attribute Set passed");
    
    debug_print("function end");
}
static void button_select_all_clicked(GtkWidget*, gpointer)
{
    debug_print("function start");
    GtkTreeSelection * treeSelection = gtk_tree_view_get_selection(\
            GTK_TREE_VIEW(g_tree_view_rsm)) ;
    gtk_tree_selection_select_all(treeSelection);   
    debug_print("function end");
}

static void button_clear_all_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    GtkListStore* listStore = GTK_LIST_STORE(\
            gtk_tree_view_get_model(\
                GTK_TREE_VIEW(g_tree_view_rsm)));
    gtk_list_store_clear(listStore);
    debug_print("function end");
}

static void initialize_tree_view_rsm()
{
    debug_print("function start");
    GtkListStore* list_store = gtk_list_store_new(4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,\
                                                     G_TYPE_STRING);
    gtk_tree_view_set_model( GTK_TREE_VIEW (g_tree_view_rsm) ,\
                             GTK_TREE_MODEL(list_store) );

    GtkCellRenderer* cell_renderer_column_1 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_2 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_3 = gtk_cell_renderer_text_new();
    GtkCellRenderer* cell_renderer_column_4 = gtk_cell_renderer_text_new();
    
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_rsm),\
            -1, "#id" , cell_renderer_column_1 , "text", 0,NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_rsm),\
            -1, "Type", cell_renderer_column_2, "text", 1, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_rsm),\
            -1, "Property", cell_renderer_column_3, "text", 2, NULL);
    gtk_tree_view_insert_column_with_attributes( GTK_TREE_VIEW( g_tree_view_rsm),\
            -1, "Value", cell_renderer_column_4 , "text", 3, NULL);
  
    g_object_set(cell_renderer_column_4,"editable", TRUE, NULL);
    g_signal_connect(cell_renderer_column_4, "edited", (GCallback) rsm_tree_view_cell_edited_callback,NULL);
    
    GtkTreeSelection* treeSelection = gtk_tree_view_get_selection(GTK_TREE_VIEW(g_tree_view_rsm));
    gtk_tree_selection_set_mode(treeSelection, GTK_SELECTION_MULTIPLE);
    debug_print("function end");
}


void rsm_tree_view_cell_edited_callback(GtkCellRendererText * cell,\
        gchar *path_string,\
        gchar *new_text ,\
        gpointer user_data)
{
    debug_print("function start");
    
    GtkTreeModel* treeModel = gtk_tree_view_get_model(GTK_TREE_VIEW(g_tree_view_rsm));
    GtkTreeIter iter;
    gtk_tree_model_get_iter_from_string(treeModel,&iter, path_string);
    GtkListStore* list = GTK_LIST_STORE(treeModel);
    gtk_list_store_set(list, &iter, 3 , new_text, -1);
    debug_print("function end");
}


static void button_firmware_browse_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    std::string strFilePath="";
    
    GtkWidget* fileChooserDialog = gtk_file_chooser_dialog_new("Open Firmware File" , \
        GTK_WINDOW(g_main_window) , \
        GTK_FILE_CHOOSER_ACTION_OPEN , \
        "Cancel" , \
        GTK_RESPONSE_CANCEL, \
        "Open", \
        GTK_RESPONSE_ACCEPT, \
        NULL);
    int iResult = gtk_dialog_run( GTK_DIALOG(fileChooserDialog));
    if (iResult == GTK_RESPONSE_ACCEPT )
    {
        strFilePath = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(fileChooserDialog));
    }else {
        // just return //
        gtk_widget_destroy(fileChooserDialog);
        return ;
    }
    
    gtk_widget_destroy(fileChooserDialog);
    

    gtk_entry_set_text(GTK_ENTRY(g_text_entry_firmware), strFilePath.c_str());

    debug_print("function end");
}

static void button_configuration_browse_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    std::string strFilePath="";
    const char* configuration_progress= "";

    gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),\
                          0);

    gtk_label_set_text( GTK_LABEL( g_label_configuration_progress ) , configuration_progress);

    GtkWidget* fileChooserDialog = gtk_file_chooser_dialog_new("Open configuration File" , \
        GTK_WINDOW(g_main_window) , \
        GTK_FILE_CHOOSER_ACTION_OPEN , \
        "Cancel" , \
        GTK_RESPONSE_CANCEL, \
        "Open", \
        GTK_RESPONSE_ACCEPT, \
        NULL);
    int iResult = gtk_dialog_run( GTK_DIALOG(fileChooserDialog));
    if (iResult == GTK_RESPONSE_ACCEPT )
    {
        strFilePath = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(fileChooserDialog));
    }else {
        // just return //
        gtk_widget_destroy(fileChooserDialog);
        return ;
    }
    
    gtk_widget_destroy(fileChooserDialog);
    

    gtk_entry_set_text(GTK_ENTRY(g_text_entry_configuration), strFilePath.c_str());

    debug_print("function end");
}




static void button_firmware_update_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid scanner from the list");
        return ;
    }
    
    // check whether there is a firmware update ongoing //
    {
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        if( g_bUpdateInProgress )
        {
            write_status_bar("firmware update is in already progress");
            run_modal_message_box("Firmware update is already in progress", "ERROR");
           return;   
        }
        g_bUpdateInProgress = true;
    
    }    
    
    std::string strFilePath = "" ;
    strFilePath = gtk_entry_get_text(GTK_ENTRY(g_text_entry_firmware));
    if ( strFilePath == "" )
	{
        debug_print("Firmware file was not choosen");
        write_status_bar("Please choose a file to update firmware");
        run_modal_message_box("Please choose a file to update firmware", "ERROR");
		
		boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
		g_bUpdateInProgress = false;
        return ;
    }
    
    // invoke the firmware update command //
    bool isFirmwareUpdateFromPlugin = false;
    bool isFirmwareUpdateFromBulkChannel = false;
    
    isFirmwareUpdateFromBulkChannel = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(g_checkbutton_firmware_bulk_update));
    
    std::string strFileExtension = strFilePath.substr( \
            strFilePath.find_last_of(".")+1,\
            strFilePath.npos);
    if ( strFileExtension == "SCNPLG"){
        isFirmwareUpdateFromPlugin=true;
    }
    
    std::string strInXml;
    std::string strOutXml;
    std::ostringstream oss;
    StatusID eStatus;
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "   <cmdArgs>" << std::endl;
    oss << "     <arg-string>" << strFilePath << "</arg-string>"<< std::endl;
    oss << "     <arg-int>" << (isFirmwareUpdateFromBulkChannel?"2":"1") << "</arg-int>" << std::endl;
    oss << "    </cmdArgs>"<< std::endl;
    oss << "</inArgs>";
    
    strInXml = oss.str();
    
    
    if ( isFirmwareUpdateFromPlugin )
    {
        ExecCommand( CMD_DEVICE_UPDATE_FIRMWARE_FROM_PLUGIN, strInXml , strOutXml , &eStatus);
       
    }else {
        ExecCommand ( CMD_DEVICE_UPDATE_FIRMWARE, strInXml, strOutXml, &eStatus);
    }
    
    if ( eStatus != STATUS_OK )
    {        
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_UPDATE_FIRMWARE failed: %d", eStatus);
        append_new_event_log_msg("Command Firmware Download failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Firmware download failed: " + status_message);
        
        {
            boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
            g_bUpdateInProgress = false;
        }
        return;
    }

    write_status_bar("Command Firmware Download success");
    append_new_event_log_msg("Command Firmware Download success");
    
    debug_print("function end");
}

void UpdateConfguration() {
    
    debug_print("function start");

    std::string strInXml;
    std::string strOutXml;
    std::ostringstream oss;
    StatusID eStatus;
    
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "   <cmdArgs>" << std::endl;
    oss << "     <arg-string>" << configuration_file_path_ << "</arg-string>"<< std::endl;    
    oss << "    </cmdArgs>"<< std::endl;
    oss << "</inArgs>";
    
    strInXml = oss.str();

    ExecCommand (CMD_LOAD_CONFIGURATION, strInXml, strOutXml, &eStatus);

    if ( eStatus != STATUS_OK )
    {        
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_LOAD_CONFIGURATION failed: %d", eStatus);
        append_new_event_log_msg("Command configuration update failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Configuration update failed: " + status_message);  
        
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        configuration_update_in_progress_ = false;
        gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),0);      
        gtk_label_set_text( GTK_LABEL(g_label_configuration_progress), "");
        
        return ;
    }

    write_status_bar("Command Configuration update success");
    append_new_event_log_msg("Command configuration Download success");
   
    debug_print("function end");
}

static void button_configuration_update_clicked(GtkWidget* , gpointer)
{   
    debug_print("function start");
    
    if (g_bUpdateInProgress) {
        write_status_bar("Firmware update is in progress");
        run_modal_message_box("Firmware update is in progress", "ERROR");
        return;  
    }
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid scanner from the list");
        return;        
    }
    
    configuration_file_path_ = gtk_entry_get_text(GTK_ENTRY(g_text_entry_configuration));
    if ( configuration_file_path_.empty() || configuration_file_path_.compare("")==0)
    {
        debug_print("Configuration file was not chosen");
        write_status_bar("Please choose a file to update configuration");
        run_modal_message_box("Please choose a file to update configuration", "ERROR");
        return;
    }
    
    // check whether there is a configuration update ongoing //
    boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
    if( configuration_update_in_progress_ )
    {
        write_status_bar("Configuration update is in already progress");
        run_modal_message_box("Configuration update is already in progress", "ERROR");
        return;   
    } else {
        gtk_progress_bar_update(GTK_PROGRESS_BAR(g_progressbar_configuration),0);
        gtk_label_set_text( GTK_LABEL(g_label_configuration_progress), "");
    }
    configuration_update_in_progress_ = true;
    
    configuration_update_thread_ = new boost::thread(boost::bind(UpdateConfguration));

    debug_print("function end");
}


static void button_firmware_launch_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
   
    {
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        gtk_progress_bar_update( GTK_PROGRESS_BAR(g_progressbar_firmware),\
                                     0.0);
        gtk_label_set_text( GTK_LABEL(g_label_firmware_progress), "");
    }

    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid scanner from the list");
        return ;
    }

    std::string strInXml ;
    std::string strOutXml ;
    StatusID eStatus ;
    std::ostringstream oss ;
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>"<< iCurrentlySelectedScannerId << "</scannerID>"<< std::endl;
    oss << "</inArgs>" ;
    strInXml = oss.str();
    
    ExecCommand (CMD_START_NEW_FIRMWARE, strInXml , strOutXml , &eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_START_NEW_FIRMWARE failed: %d", eStatus);
        append_new_event_log_msg("Command Start New Firmware failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Start New Firmware: " + status_message);
        
        return ;
    }
    
    debug_print("command CMD_START_NEW_FIRMWARE Success.");
    append_new_event_log_msg("Command Start New Firmware success");
    write_status_bar("Command Start New Firmware success");
    
    {
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        g_bUpdateInProgress = false;
    }    
    
    debug_print("function end");
}

static void button_save_image_clicked( GtkWidget* , gpointer)
{
    debug_print("function start");
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid scanner from the list");
        return;
    }

    if ( g_iImageSize == 0){
        debug_print("image was not received");
        write_status_bar("Image should be recieved before saving it.");
        return;
    }
    
    std::string strFileExtension;
    if( g_isImageJpeg )
        strFileExtension = "image.jpg";
    if ( g_isImageTiff)
        strFileExtension = "image.tiff";
    if ( g_isImageBmp )
        strFileExtension = "image.bmp";

    bool bRunDialog = true;
    GtkWidget * dialog;

    dialog = gtk_file_chooser_dialog_new( "Save File" ,\
                 GTK_WINDOW(g_main_window), \
                 GTK_FILE_CHOOSER_ACTION_SAVE,\
                 GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,\
                 GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,\
                 NULL);


    while( bRunDialog)
    {
        gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dialog),\
                     strFileExtension.c_str());
        gtk_window_set_modal( GTK_WINDOW(dialog),true) ;
        int iDialogResponse = gtk_dialog_run(GTK_DIALOG(dialog));
        if ( iDialogResponse == GTK_RESPONSE_ACCEPT) 
        {
            
            char *strFileName ;
            strFileName = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
            FILE *fp = fopen ( strFileName,"w");
            if ( fp == NULL){
                run_modal_message_box("Error saving file" , "Error" ); 
            }else{
                bRunDialog=false;
                fwrite(g_ImageVideoData,1, g_iImageSize ,fp); 
                fclose(fp);
            }
        }else if(iDialogResponse==GTK_RESPONSE_CANCEL){
                bRunDialog = false;
        }else {

          std::cout << "Uknown response" << std::endl;
          bRunDialog =false;
        }
    }   
    gtk_widget_destroy(dialog);
    debug_print("function end");
}


static void button_firmware_abort_clicked(GtkWidget* , gpointer)
{
    debug_print("function start");
    
    if ( iCurrentlySelectedScannerId == 0 )
    {
        debug_print("Please select a valid scanner from the list");
        write_status_bar("Please select a valid scanner from the list");
        return ;
    }

    std::string strInXml;
    std::string strOutXml;
    StatusID eStatus;
    std::ostringstream oss;
    
    oss << "<inArgs>" << std::endl;
    oss << "  <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "</inArgs>" ;
    
    strInXml = oss.str();
    
    ExecCommand ( CMD_DEVICE_ABORT_UPDATE_FIRMWARE, strInXml , strOutXml, \
            &eStatus);
    if ( eStatus != STATUS_OK )
    {        
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_DEVICE_ABORT_UPDATE_FIRMWARE failed: %d", eStatus);
        append_new_event_log_msg("Command Abort Update Firmware failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Abort Update Firmware: " + status_message);
        return ;
    }
    
    debug_print("Command CMD_DEVICE_ABORT_UPDATE_FIRMWARE success");
    append_new_event_log_msg("Command Abort Update Firmware success");
    write_status_bar("Command Abort Update Firmware Success.");
    
    {
        boost::unique_lock<boost::recursive_mutex> lock(g_access_mutex);
        g_bUpdateInProgress = false;
    }      
    
    debug_print("function end");
}

static void set_image_type_toggle_button_clicked( GtkToggleButton *togglebutton , gpointer userData)
{
    debug_print("function start");
    int iNewImageType = 0;
    
    // first remove the signal by function //
    g_signal_handlers_disconnect_by_func(G_OBJECT(g_check_button_image_bmp),\
        (void*)set_image_type_toggle_button_clicked, NULL);
    g_signal_handlers_disconnect_by_func(G_OBJECT(g_check_button_image_jpg),\
        (void*) set_image_type_toggle_button_clicked,NULL);
    g_signal_handlers_disconnect_by_func(G_OBJECT(g_check_button_image_tiff),\
        (void*)set_image_type_toggle_button_clicked,NULL);
    
    
    GtkWidget * widget = GTK_WIDGET(togglebutton);
    if ( widget == g_check_button_image_bmp  ){
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_bmp),\
                true);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_jpg),\
                false);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_tiff),\
                false);
        iNewImageType = 3;
        
    }else if ( widget == g_check_button_image_tiff ) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_bmp),\
                false);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_jpg),\
                false);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_tiff),\
                true);        
        iNewImageType = 4;
    }else {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_bmp),\
                false);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_jpg),\
                true);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_image_tiff),\
                false);
        iNewImageType = 1;
    }
    
    // then add the handler back //
    g_signal_connect(G_OBJECT(g_check_button_image_bmp), "toggled", \
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_image_tiff),"toggled",\
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    g_signal_connect(G_OBJECT(g_check_button_image_jpg),"toggled",\
        G_CALLBACK(set_image_type_toggle_button_clicked),NULL);
    
    // now set the image type for the scanner //
    if ( iCurrentlySelectedScannerId ==  0 )
    {
        run_modal_message_box("Please select a scanner before invoking this operation",\
                "Info:");
        return ;
    }

    StatusID eStatus ;
    std::string strInXml ;
    std::string strOutXml;
    std::ostringstream oss ;
    
    oss << "<inArgs>" << std::endl;
    oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-xml>" << std::endl;
    oss << "            <attrib_list>" << std::endl;
    oss << "                <attribute>" << std::endl;
    oss << "                    <id>304</id>" << std::endl;
    oss << "                    <datatype>B</datatype>" << std::endl;
    oss << "                    <value>" << iNewImageType << "</value>" << std::endl;
    oss << "                </attribute>" << std::endl;
    oss << "            </attrib_list>" << std::endl;
    oss << "        </arg-xml>" << std::endl;
    oss << "     </cmdArgs>" << std::endl;
    oss << "</inArgs>" << std::endl; 
    
    strInXml = oss.str();
    
    
    ExecCommand (CMD_RSM_ATTR_SET,strInXml , strOutXml,&eStatus);
    if ( eStatus != STATUS_OK )
    {
        
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Changing image type failed: %d", eStatus);
        append_new_event_log_msg("Changing image type failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Changing image type failed: " + status_message);
        
        return ;
    }
    
    append_new_event_log_msg("Changing image type Success");
    write_status_bar("Changing image type Success");
    debug_print("function end");
}

void check_button_enable_view_finder_toggled( GtkToggleButton* togglebutton , gpointer user_data)
{
    debug_print("function start");
 
    if ( iCurrentlySelectedScannerId == 0)
    {
         write_status_bar("Please select a scanner");
         return  ;
    }

    bool isEnable = gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(togglebutton));
   
    
    StatusID eStatus ;
    std::string strInXml ;
    std::string strOutXml ;
    std::ostringstream oss ;

    oss << "<inArgs>" << std::endl;
    oss << "    <scannerID>" << iCurrentlySelectedScannerId << "</scannerID>" << std::endl;
    oss << "    <cmdArgs>" << std::endl;
    oss << "        <arg-xml>" << std::endl;
    oss << "            <attrib_list>" << std::endl;
    oss << "                <attribute>"<< std::endl ;
    oss << "                    <id>324</id>" << std::endl;
    oss << "                    <datatype>F</datatype>" << std::endl;
   
    if ( isEnable) 
       oss << "<value>True</value>" << std::endl;
    else 
       oss << "<value>False</value>" << std::endl;


    oss << "                </attribute>" << std::endl;
    oss << "            </attrib_list>"<< std::endl;
    oss << "        </arg-xml>" << std::endl;
    oss << "     </cmdArgs>" << std::endl;
    oss << "</inArgs>" << std::endl;
    strInXml = oss.str();

    ExecCommand( CMD_RSM_ATTR_SET, strInXml , strOutXml , &eStatus);
    
	if ( eStatus != STATUS_OK) 
    {

        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Enabling/disabling view finder failed: %d", eStatus);
        append_new_event_log_msg("Enabling/disabling view finder failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Enabling/disabling view finder failed: " + status_message);
        
        return ;
    }
	
    append_new_event_log_msg("Enabling/Disabling view finder success");
    write_status_bar("Enabling/Disabling view finder success");
     
    debug_print("function end");
}


static void update_status_check_button_enable_view_finder()
{
    debug_print("function start");
    if ( iCurrentlySelectedScannerId == 0 )
        return ;

    // :TODO: not implemented. //    




    debug_print("function end");
}

static void button_read_weight_clicked(GtkWidget* , gpointer)
{ 
    debug_print("function start");

    std::string inXml;
    std::string outXml;
    StatusID eStatus;  
    std::ostringstream oss;
    std::string attributeNumber = "6017";

    oss << "<inArgs>"<<std::endl;
    oss << "    <scannerID>"<<iCurrentlySelectedScannerId<< "</scannerID>"<<std::endl;
    oss << "    <cmdArgs>"<<std::endl;
    oss << "        <arg-xml>"<<std::endl;
    oss << "            <attrib_list>"<<attributeNumber<<"</attrib_list>"<<std::endl;
    oss << "        </arg-xml>"<<std::endl;
    oss << "    </cmdArgs>"<<std::endl;
    oss << "</inArgs>"<<std::endl;
 
    inXml = oss.str();
    ::ExecCommand(CMD_RSM_ATTR_GET, inXml ,outXml , &eStatus);

    if ( eStatus != STATUS_OK ){
        std::string status_message = GetErrorMessage(eStatus);
        debug_print("Command CMD_RSM_ATTR_GET failed: %d", eStatus);
        append_new_event_log_msg("Command Attribute Get failed: %d - %s", eStatus, status_message.c_str());
        write_status_bar("Command Attribute Get failed: " + status_message);
        return;
    }
    
    debug_print("Command success.");
    write_status_bar("READ_WEIGHT success");
    append_new_event_log_msg("Read Weight call success");
    append_new_xml_log(outXml);

    pugi::xml_document doc ;
    pugi::xml_parse_result result = doc.load_string(outXml.c_str());
    if ( result.status != pugi::status_ok)
    {
        debug_print("Invalid outXML received when after calling CMD_RSM_ATTR_GET.");
        write_status_bar("Invalid outXML received after calling CMD_RSM_ATTR_GET");
        return;
    }

    pugi::xml_node node_attribute = doc.child("outArgs").child("arg-xml").child("response").child("attrib_list").child("attribute");

    std::string strId = node_attribute.child("id").child_value();
    std::string strDataType = node_attribute.child("datatype").child_value();
    std::string strValue = node_attribute.child("value").child_value();
      
    int scaleStatus;
    int weightUnit;
    char hexWeight[RETURN_WEIGHT_LEN];
    const char *strPointer = strValue.c_str();
    std::string strScaleStatus = "";   

    // Get scale status as an interger //
    sscanf(strPointer, "%02x", &scaleStatus);  
    strPointer = strPointer + 3;
     
    // clear scale status message /
    gtk_label_set_text((GtkLabel*)g_label_scale_status," ");

    
    // Get weight unit //
    sscanf(strPointer, "%02x", &weightUnit);  
    strPointer = strPointer + 2;


    // Check weight unit //
    if(weightUnit==0)
    {
        gtk_entry_set_text(GTK_ENTRY(g_entry_weight_unit)," ");
        gtk_entry_set_text(GTK_ENTRY(g_entry_weight_unit),"kg");
    }
    else if(weightUnit==1)
    {
        gtk_entry_set_text(GTK_ENTRY(g_entry_weight_unit),"");
        gtk_entry_set_text(GTK_ENTRY(g_entry_weight_unit),"lbs");
    }

    switch (scaleStatus)
    {
    case 0:
            debug_print("can't read weight. ");       
            strScaleStatus = "Scale Not Enabled";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 1:
            debug_print("can't read weight. ");       
            strScaleStatus = "Scale Not Ready";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 2:
            debug_print("can't read weight. ");       
            strScaleStatus = "Weight Over Limit";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 3:
            debug_print("can't read weight. ");       
            strScaleStatus = "Weight Under Limit";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 4:
            debug_print("can't read weight. ");       
            strScaleStatus = "Not a Stable Weight";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 5:
            debug_print("Read Stable Zero Weight");  
            strScaleStatus = "Stable Zero Weight";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
            gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured), "0.00");  
            return;
    case 6:
            debug_print("Read Stable Non Zero Weight");  
            strScaleStatus = "Stable Non Zero Weight";
            gtk_label_set_text((GtkLabel*)g_label_scale_status,strScaleStatus.c_str());
            break;
    default:
        break;
    }

    // Extract hexa decimal weight from attribute return value //
    for(int index=0; index<RETURN_WEIGHT_LEN-1; index++)
    {
        if(*strPointer == ' ')
        {
            strPointer = strPointer + 1;
        }
        sscanf(strPointer, "%c", &hexWeight[index]);
        strPointer = strPointer +1;
    }

   // Hexadecimal weight to decimal weight conversion //
   int base = 1;
   int tempWeight = 0;

    for (int index=READ_WEIGHT_LEN-1; index>=0; index--)
    {
      if (hexWeight[index]>='0' && hexWeight[index]<='9')
       {
         tempWeight += (hexWeight[index] - 48)*base;
         base = base * 16;
       }
      else if (hexWeight[index]>='A' && hexWeight[index]<='F') 
       {
         tempWeight += (hexWeight[index] - 55)*base;
         base = base*16;
       }
      else if (hexWeight[index]>='a' && hexWeight[index]<='f')
       {
         tempWeight += (hexWeight[index] - 87)*base;
         base = base*16;
       }
    }

    float decimalWeight = tempWeight;
    decimalWeight = decimalWeight/1000;

    std::stringstream stream;
    stream << decimalWeight;
    std::string weightRead = stream.str();
    debug_print("Weight : "+decimalWeight);

    gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured)," ");
    gtk_entry_set_text(GTK_ENTRY(g_entry_weight_measured),weightRead.c_str());
    
    debug_print("function end");
}

static void button_zero_scale_clicked(GtkWidget* , gpointer)
{
    std::ostringstream oss;
  
    oss << "<inArgs>";
    oss <<    "<scannerID>"<<iCurrentlySelectedScannerId<<"</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>6018</id><datatype>X</datatype><value>0</value></attribute></attrib_list></arg-xml></cmdArgs>";
    oss << "</inArgs>";
    
    std::string inXml = oss.str();
    StatusID sId;
    std::string outXml;
    ::ExecCommand(CMD_RSM_ATTR_SET, inXml, outXml, &sId);
         
    if(sId == STATUS_OK)
    {
        debug_print("Set Zero Scale call success.");
        write_status_bar("ZERO_SCALE command success"); 
        append_new_event_log_msg("Set Zero Scale call success");
        append_new_xml_log(outXml);
    }
    else
    {
         debug_print("Set Zero Scale call failed.");
         write_status_bar("ZERO_SCALE command failed.");    
    } 

    
    debug_print("function end");
}
static void button_reset_scale_clicked(GtkWidget* , gpointer)
{
    std::ostringstream oss;

    oss << "<inArgs>";
    oss <<    "<scannerID>"<<iCurrentlySelectedScannerId<<"</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>6019</id><datatype>X</datatype><value>0</value></attribute></attrib_list></arg-xml></cmdArgs>";
    oss << "</inArgs>";
    
    std::string inXml = oss.str();
    StatusID statusId;
    std::string outXml;
    ::ExecCommand(CMD_RSM_ATTR_SET, inXml, outXml, &statusId);
         
    if(statusId == STATUS_OK)
    {
        debug_print("Reset Scale call success.");
        write_status_bar("RESET_SCALE command success"); 
        append_new_event_log_msg("Reset Scale call success");
        append_new_xml_log(outXml);  
    }
    else
    {
         debug_print("ResetScale command failed.");
         write_status_bar("RESET_SCALE command failed.");    
    } 
    
    debug_print("function end");
}

void check_button_enable_keyboard_emulation_toggled(GtkWidget* , gpointer)
{
    debug_print("function start");
    bool isEnable = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(g_check_button_enable_keyboard_emulation));
    std::string hidkb_user_setting = "false";
    if (isEnable) {
        hidkb_user_setting = "true";
    } 
    std::string inXml = "<inArgs><cmdArgs><arg-bool>" + hidkb_user_setting + "</arg-bool></cmdArgs></inArgs>";
    StatusID statusId;
    std::string outXml;
    ::ExecCommand(CMD_KEYBOARD_EMULATOR_ENABLE, inXml, outXml, &statusId);
    
    if(statusId == STATUS_OK)
    {
        debug_print("HIDKB emulation call success.");
        write_status_bar("HIDKB_EMULATION command success"); 
        append_new_event_log_msg("HIDKB emulation call success");
        append_new_xml_log(outXml);  
    }
    else
    {
         debug_print("HIDKB emulation command failed.");
         write_status_bar("HIDKB_EMULATION command failed.");    
    } 
    
    debug_print("function end");
}

void update_hidkb_emulation_setting()
{
    std::string inXml = "<inArgs></inArgs>";   
    StatusID statusId;
    std::string outXml;
    ::ExecCommand(CMD_KEYBOARD_EMULATOR_GET_XML, inXml, outXml, &statusId);
        
    if(statusId == STATUS_OK)
    {
        debug_print("HIDKB emulation get setting call success.");        
        pugi::xml_document doc ;
        pugi::xml_parse_result result = doc.load_string( outXml.c_str() );
        if ( result.status != pugi::status_ok )
        {
            debug_print("invalid outxml found");      
            return ;
        }           
        pugi::xml_node node_enum_status = doc.child("outArgs").child("arg-xml");
        std::string current_state = node_enum_status.child("KeyEnumState").child_value();  
        
        if(current_state.compare("1") == 0)
        {                        
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_enable_keyboard_emulation),TRUE);            
        }
        else
        {
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_check_button_enable_keyboard_emulation),FALSE);
        }
    }
    else
    {
         debug_print("HIDKB emulation get setting command failed.");        
    }           
}

